#!/bin/bash

# 脚本用法：./do_plot.sh <序号>，如：./do_plot.sh 71 或 ./do_plot.sh 1-9
# 功能：从 smiles_summary.xlsx 读取 Amine_SMILE → 计算分子量 → 读取 viscosity_results_summary.txt → 换算 loading (mol/kg 混合物), wt%, 和 mol/kg (新鲜胺) → 生成作图
# 假设当前目录为 /work/home/xuwenhao/Viscosity_cal/
# 依赖：pandas, openpyxl, rdkit (用于计算分子量), numpy, matplotlib, scipy

# 设置路径
EXCEL_FILE="smiles_summary.xlsx"
BASE_DIR="/work/home/xuwenhao/Viscosity_cal"

# 检查 Excel 文件
if [ ! -f "$EXCEL_FILE" ]; then
    echo "错误: 未找到 $EXCEL_FILE" >&2
    exit 1
fi

# 解析输入序号（支持 1,3,5-7）
parse_sequence() {
    local input="$1"
    local result=()
    IFS=',' read -ra parts <<< "$input"
    for part in "${parts[@]}"; do
        if [[ "$part" =~ ^[0-9]+-[0-9]+$ ]]; then
            local start="${part%-*}"
            local end="${part#*-}"
            for ((i=start; i<=end; i++)); do
                result+=("$i")
            done
        elif [[ "$part" =~ ^[0-9]+$ ]]; then
            result+=("$part")
        else
            echo "警告: 忽略无效格式 '$part'" >&2
        fi
    done
    echo "${result[@]}"
}

# 安全读取 SMILES（仅输出 SMILES）
get_smiles() {
    local index="$1"
    local column="$2"
    python3 - << EOF
import pandas as pd
import sys
try:
    df = pd.read_excel("$EXCEL_FILE", engine='openpyxl')
    df.columns = [col.strip() for col in df.columns]
    if '吸收剂序号' in df.columns:
        df['吸收剂序号'] = pd.to_numeric(df['吸收剂序号'], errors='coerce')
    else:
        print("错误: 列 '吸收剂序号' 不存在", file=sys.stderr)
        print("")
        sys.exit(1)
  
    row = df[df['吸收剂序号'] == $index]
    if not row.empty and pd.notna(row['$column'].iloc[0]):
        smiles = str(row['$column'].iloc[0]).strip()
        print(smiles)
    else:
        print("")
except Exception as e:
    print(f"Python 读取错误: {e}", file=sys.stderr)
    print("")
EOF
}

# 计算分子量从 SMILES
get_molecular_weight() {
    local smiles="$1"
    python3 - << EOF
from rdkit import Chem
from rdkit.Chem import Descriptors
try:
    mol = Chem.MolFromSmiles("$smiles")
    if mol is not None:
        mw = Descriptors.MolWt(mol)
        print(f"{mw:.4f}")
    else:
        print("")
except Exception as e:
    print("")
EOF
}

# ========= 主逻辑 =========
if [ $# -ne 1 ]; then
    echo "用法: $0 <序号，例如 71 或 1,3 或 5-7>" >&2
    exit 1
fi

sequence="$1"
indices=($(parse_sequence "$sequence"))
if [ ${#indices[@]} -eq 0 ]; then
    echo "错误: 未解析到有效序号！" >&2
    exit 1
fi

echo "开始处理序号: ${indices[@]}"

for index in "${indices[@]}"; do
    echo "=== 处理序号 $index ==="
    
    # 读取 Amine_SMILE
    amine_smile=$(get_smiles "$index" "Amine_SMILE")
    if [ -z "$amine_smile" ]; then
        echo "警告: 序号 $index 在 Excel 中无有效 Amine_SMILE，跳过。"
        continue
    fi
    
    # 计算分子量 M
    M=$(get_molecular_weight "$amine_smile")
    if [ -z "$M" ]; then
        echo "错误: 无法计算序号 $index 的分子量，跳过。"
        continue
    fi
    echo "分子量 M: $M g/mol"
    
    # 设置目录
    dir="$BASE_DIR/$index/gromacs_results"
    if [ ! -d "$dir" ]; then
        echo "错误: 目录 $dir 不存在，跳过。"
        continue
    fi
    cd "$dir" || { echo "无法进入 $dir"; exit 1; }
    
    # 检查 summary 文件
    summary_path="viscosity_results_summary.txt"
    if [ ! -f "$summary_path" ]; then
        echo "错误: 未找到 $summary_path，跳过。"
        cd - >/dev/null
        continue
    fi
    
    # 内置 Python 作图脚本
    python3 - << EOF
import os
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

# 读取数据
data = np.loadtxt('$summary_path', skiprows=1)
loadings_mol_mol = data[:, 0]
viscosities = data[:, 1]

# 分子量 M
M = $M

# 换算到 mol/kg (混合物), wt%, 和 mol/kg (新鲜胺)
loadings_mol_kg_mixture = 1000 * loadings_mol_mol / (M + 44 * loadings_mol_mol)
loadings_wt = 4400 * loadings_mol_mol / (M + 44 * loadings_mol_mol)
loadings_mol_kg_fresh = 1000 * loadings_mol_mol / M

# 过滤有效数据
valid_indices = ~np.isnan(viscosities)
valid_loadings_mol_mol = loadings_mol_mol[valid_indices]
valid_loadings_mol_kg_mixture = loadings_mol_kg_mixture[valid_indices]
valid_loadings_wt = loadings_wt[valid_indices]
valid_loadings_mol_kg_fresh = loadings_mol_kg_fresh[valid_indices]
valid_viscosities = viscosities[valid_indices]

# 函数：作图和拟合
def plot_and_fit(x, y, valid_loadings_mol_mol, xlabel, title, filename):
    log_y = np.log(y)
    slope, intercept, r_value, p_value, std_err = stats.linregress(x, log_y)
    fit_x = np.linspace(min(x), max(x), 100)
    fit_log_y = slope * fit_x + intercept
    fit_y = np.exp(fit_log_y)
    
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.semilogy(x, y, 'o', markersize=8, label='Data points')
    ax.semilogy(fit_x, fit_y, 'r-', label=f'Linear fit (ln(η) = {intercept:.3f} + {slope:.3f}·Λ)\nR² = {r_value**2:.4f}')
    
    # 标注每个点的 mol/mol 值
    for i, (xi, yi) in enumerate(zip(x, y)):
        ax.text(xi, yi * 1.1, f'{valid_loadings_mol_mol[i]:.2f}', fontsize=8, ha='center', va='bottom')
    
    ax.set_xlim(min(x) - 0.01 * (max(x) - min(x)), max(x) + 0.01 * (max(x) - min(x)))
    ax.set_ylim(1, 400)
    ax.set_xlabel(xlabel)
    ax.set_ylabel('Viscosity (cP)')
    ax.set_title(title)
    ax.legend()
    ax.grid(True, which="both", linestyle='--', alpha=0.5)
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()

# 生成 mol/kg (混合物) 图
plot_and_fit(valid_loadings_mol_kg_mixture, valid_viscosities, valid_loadings_mol_mol, 'Loading (mol/kg mixture)', 'Viscosity vs CO2 Loading (mol/kg mixture, semilog plot)', 'viscosity_vs_loading_num${index}_kg_mixture.png')

# 生成 wt% 图
plot_and_fit(valid_loadings_wt, valid_viscosities, valid_loadings_mol_mol, 'Loading (wt%)', 'Viscosity vs CO2 Loading (wt%, semilog plot)', 'viscosity_vs_loading_num${index}_wt.png')

# 生成 mol/kg (新鲜胺) 图
plot_and_fit(valid_loadings_mol_kg_fresh, valid_viscosities, valid_loadings_mol_mol, 'Loading (mol/kg fresh amine)', 'Viscosity vs CO2 Loading (mol/kg fresh amine, semilog plot)', 'viscosity_vs_loading_num${index}_kg_fresh.png')

print("图已生成: viscosity_vs_loading_num${index}_kg_mixture.png, viscosity_vs_loading_num${index}_wt.png 和 viscosity_vs_loading_num${index}_kg_fresh.png")
EOF
    
    cd - >/dev/null
done