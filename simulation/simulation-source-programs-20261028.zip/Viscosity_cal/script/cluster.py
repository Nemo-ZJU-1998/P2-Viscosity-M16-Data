import numpy as np
import networkx as nx
from collections import defaultdict, Counter
import re
import logging
import argparse
import matplotlib.pyplot as plt
from typing import List, Tuple, Dict, Set
import os
import random
import shutil

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def parse_gro_file(gro_filename: str) -> Tuple[Dict[int, int], List[int]]:
    """Parse .gro file and return atom to molecule mapping and all molecules list"""
    atom_to_mol = {}
    all_molecules = set()
    
    try:
        with open(gro_filename, 'r') as f:
            lines = f.readlines()
        
        # Skip first two lines (title and total atoms)
        total_atoms = int(lines[1].strip())
        atom_lines = lines[2:2+total_atoms]
        
        for line in atom_lines:
            # Parse fixed format: residue_number(5digits), residue_name(5chars), atom_name(5chars), atom_number(5digits)
            resid = int(line[0:5].strip())  # Residue number, treated as molecule ID
            atom_id = int(line[15:20].strip())  # Global atom number
            
            atom_to_mol[atom_id] = resid
            all_molecules.add(resid)
            
        logger.info(f"Successfully parsed {len(atom_to_mol)} atom mappings from {gro_filename}")
        logger.info(f"Found {len(all_molecules)} unique molecules in the system")
        
        return atom_to_mol, list(all_molecules)
    
    except Exception as e:
        logger.error(f"Error parsing GRO file: {str(e)}")
        raise

def parse_hbond_ndx_section(ndx_filename: str, target_section: str = "hbonds_System") -> List[Tuple[int, int]]:
    """Parse hydrogen bond NDX file and return hydrogen bond atom pairs"""
    hbond_atom_pairs = []
    found_target_section = False
    
    try:
        with open(ndx_filename, 'r') as f:
            for line in f:
                line = line.strip()
                
                # Check if target section is found
                if line.startswith('[') and line.endswith(']'):
                    current_section = line[1:-1].strip()
                    if current_section == target_section:
                        found_target_section = True
                        logger.info(f"Found target section: [{current_section}]")
                        continue
                    elif found_target_section:
                        # Stop reading if we already found target section but encountered new section
                        break
                
                # If in target section, parse hydrogen bond data lines
                if found_target_section and line and not line.startswith(';'):
                    parts = re.split(r'\s+', line)
                    if len(parts) >= 3:
                        try:
                            donor_atom = int(parts[0])
                            acceptor_atom = int(parts[2])
                            hbond_atom_pairs.append((donor_atom, acceptor_atom))
                        except ValueError:
                            continue
        
        logger.info(f"Extracted {len(hbond_atom_pairs)} hydrogen bond atom pairs from [{target_section}] section")
        return hbond_atom_pairs
    
    except Exception as e:
        logger.error(f"Error parsing NDX file: {str(e)}")
        raise

def build_hbond_network(atom_to_mol_dict: Dict[int, int], 
                       hbond_atom_pairs: List[Tuple[int, int]], 
                       all_molecules: List[int],
                       loading: float) -> nx.Graph:
    """Build hydrogen bond network and return graph"""
    G = nx.Graph()
    
    # Add all molecules as nodes first
    for molecule in all_molecules:
        G.add_node(molecule)
    
    # Calculate molecule type ranges based on loading
    Y_COUNT = int(2000 * loading + 0.5)
    X_COUNT = 2000 - 2 * Y_COUNT
    
    AMINE_END = X_COUNT  # Fresh amine: 1 to AMINE_END
    AMINECOO_START = X_COUNT + 1  # Carbamate: AMINECOO_START to AMINECOO_END
    AMINECOO_END = 2000 - Y_COUNT
    AMINENH2_START = 2001 - Y_COUNT  # Protonated amine: AMINENH2_START to 2000
    
    logger.info(f"Loading value: {loading}")
    logger.info(f"Fresh amine molecules: 1-{AMINE_END}")
    logger.info(f"Carbamate molecules: {AMINECOO_START}-{AMINECOO_END}")
    logger.info(f"Protonated amine molecules: {AMINENH2_START}-2000")
    
    # Process hydrogen bonds
    for donor_atom, acceptor_atom in hbond_atom_pairs:
        donor_mol = atom_to_mol_dict.get(donor_atom)
        acceptor_mol = atom_to_mol_dict.get(acceptor_atom)
        
        if donor_mol is None or acceptor_mol is None:
            continue
        
        # Skip intramolecular hydrogen bonds
        if donor_mol == acceptor_mol:
            continue
        
        # Sort molecule pair to avoid duplicate edges
        sorted_mol_pair = tuple(sorted((donor_mol, acceptor_mol)))
        
        # Add molecule pair as edge to the network
        G.add_edge(sorted_mol_pair[0], sorted_mol_pair[1])
    
    logger.info(f"Built hydrogen bond network: {G.number_of_nodes()} molecule nodes, {G.number_of_edges()} edges (intermolecular hydrogen bonds)")
    return G

def get_molecule_type(mol_id: int, loading: float) -> str:
    """Get molecule type based on molecule ID and loading value"""
    Y_COUNT = int(2000 * loading + 0.5)
    X_COUNT = 2000 - 2 * Y_COUNT
    
    if 1 <= mol_id <= X_COUNT:
        return "fresh_amine"
    elif X_COUNT + 1 <= mol_id <= 2000 - Y_COUNT:
        return "carbamate"
    elif 2001 - Y_COUNT <= mol_id <= 2000:
        return "protonated_amine"
    return "unknown"

def analyze_clusters(G: nx.Graph, loading: float) -> Tuple[List[Set[int]], Dict[str, List[int]]]:
    """Analyze clusters in the network and return cluster list and classification"""
    # Find all connected components (clusters)
    clusters = list(nx.connected_components(G))
    
    # Filter out single-molecule clusters
    clusters = [cluster for cluster in clusters if len(cluster) > 1]
    
    logger.info(f"Found {len(clusters)} clusters (excluding single-molecule clusters)")
    
    # Classify clusters
    cluster_types = {}
    
    for i, cluster in enumerate(clusters):
        # Count molecule types in cluster
        type_count = {
            "fresh_amine": 0,
            "carbamate": 0,
            "protonated_amine": 0
        }
        
        for mol_id in cluster:
            mol_type = get_molecule_type(mol_id, loading)
            if mol_type in type_count:
                type_count[mol_type] += 1
        
        # Create cluster type identifier
        cluster_type_id = f"F{type_count['fresh_amine']}_C{type_count['carbamate']}_P{type_count['protonated_amine']}"
        
        if cluster_type_id not in cluster_types:
            cluster_types[cluster_type_id] = []
        
        cluster_types[cluster_type_id].append(i)
    
    return clusters, cluster_types

def visualize_cluster_size_distribution(clusters: List[Set[int]], loading: float) -> None:
    """Create bar plot of cluster sizes where each bar represents an exact integer size"""
    if not clusters:
        logger.warning("No clusters found for size distribution plot")
        return
    
    # Get cluster sizes and counts
    size_counts = Counter(len(cluster) for cluster in clusters)
    sizes = sorted(size_counts.keys())
    counts = [size_counts[size] for size in sizes]
    
    plt.figure(figsize=(10, 6))
    bars = plt.bar(sizes, counts, width=0.8, edgecolor='black', 
                   color='skyblue', alpha=0.7)
    
    # Add value labels
    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2., height,
                f'{int(height)}', ha='center', va='bottom')
    
    plt.xlabel('Cluster Size (Number of Molecules)', fontsize=12)
    plt.ylabel('Number of Clusters', fontsize=12)
    plt.title(f'Cluster Size Distribution (Loading: {loading})', fontsize=14)
    plt.xticks(sizes)
    plt.grid(True, axis='y', alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(f'cluster_size_distribution_loading_{loading:.2f}.png', 
                dpi=300, bbox_inches='tight')
    logger.info(f"Saved cluster_size_distribution_loading_{loading:.2f}.png")
    plt.close()

def visualize_cluster_type_distribution(cluster_types: Dict[str, List[int]], 
                                      loading: float) -> None:
    """Create bar plot showing frequency of each cluster type"""
    if not cluster_types:
        logger.warning("No cluster types found for distribution plot")
        return
    
    # Prepare data
    types = []
    counts = []
    for cluster_type, cluster_indices in cluster_types.items():
        types.append(cluster_type)
        counts.append(len(cluster_indices))
    
    # Sort by count (descending)
    sorted_types = [t for _, t in sorted(zip(counts, types), reverse=True)]
    sorted_counts = sorted(counts, reverse=True)
    
    plt.figure(figsize=(12, 6))
    bars = plt.bar(sorted_types, sorted_counts, edgecolor='black',
                  color='lightgreen', alpha=0.7)
    
    # Add value labels
    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2., height,
                f'{int(height)}', ha='center', va='bottom')
    
    plt.xlabel('Cluster Type (F=fresh_amine, C=carbamate, P=protonated_amine)', 
              fontsize=12)
    plt.ylabel('Number of Clusters', fontsize=12)
    plt.title(f'Cluster Type Distribution (Loading: {loading})', fontsize=14)
    plt.xticks(rotation=45, ha='right')
    plt.grid(True, axis='y', alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(f'cluster_type_distribution_loading_{loading:.2f}.png', 
                dpi=300, bbox_inches='tight')
    logger.info(f"Saved cluster_type_distribution_loading_{loading:.2f}.png")
    plt.close()

def visualize_cluster_composition(clusters: List[Set[int]], 
                                loading: float) -> None:
    """Create stacked bar plot showing molecule type composition in clusters"""
    if not clusters:
        logger.warning("No clusters found for composition plot")
        return
    
    # Prepare data
    fresh_amine = []
    carbamate = []
    protonated_amine = []
    
    for cluster in clusters:
        counts = Counter(get_molecule_type(mol_id, loading) for mol_id in cluster)
        fresh_amine.append(counts.get('fresh_amine', 0))
        carbamate.append(counts.get('carbamate', 0))
        protonated_amine.append(counts.get('protonated_amine', 0))
    
    # Sort clusters by size
    cluster_sizes = [f+c+p for f,c,p in zip(fresh_amine, carbamate, protonated_amine)]
    sorted_indices = np.argsort(cluster_sizes)[::-1]
    
    # Only show top 30 clusters if there are many
    if len(clusters) > 30:
        sorted_indices = sorted_indices[:30]
    
    # Create plot
    fig, ax = plt.subplots(figsize=(14, 6))
    
    # Create stacked bars
    ax.bar(range(len(sorted_indices)), 
           [fresh_amine[i] for i in sorted_indices], 
           label='Fresh Amine', color='lightblue', edgecolor='black')
    
    ax.bar(range(len(sorted_indices)), 
           [carbamate[i] for i in sorted_indices],
           bottom=[fresh_amine[i] for i in sorted_indices],
           label='Carbamate', color='lightgreen', edgecolor='black')
    
    ax.bar(range(len(sorted_indices)), 
           [protonated_amine[i] for i in sorted_indices],
           bottom=[fresh_amine[i]+carbamate[i] for i in sorted_indices],
           label='Protonated Amine', color='lightcoral', edgecolor='black')
    
    ax.set_xlabel('Cluster Index (sorted by size)', fontsize=12)
    ax.set_ylabel('Number of Molecules', fontsize=12)
    ax.set_title(f'Cluster Composition (Loading: {loading})', fontsize=14)
    ax.legend()
    ax.grid(True, axis='y', alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(f'cluster_composition_loading_{loading:.2f}.png', 
                dpi=300, bbox_inches='tight')
    logger.info(f"Saved cluster_composition_loading_{loading:.2f}.png")
    plt.close()

def visualize_combined_distributions(clusters: List[Set[int]], 
                                   cluster_types: Dict[str, List[int]],
                                   loading: float) -> None:
    """Create a combined figure with size distribution and type distribution"""
    if not clusters or not cluster_types:
        logger.warning("No data for combined distributions plot")
        return
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
    
    # Plot 1: Cluster size distribution
    size_counts = Counter(len(cluster) for cluster in clusters)
    sizes = sorted(size_counts.keys())
    counts = [size_counts[size] for size in sizes]
    
    bars1 = ax1.bar(sizes, counts, width=0.8, edgecolor='black', 
                   color='skyblue', alpha=0.7)
    
    for bar in bars1:
        height = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width()/2., height,
                f'{int(height)}', ha='center', va='bottom')
    
    ax1.set_xlabel('Cluster Size', fontsize=12)
    ax1.set_ylabel('Number of Clusters', fontsize=12)
    ax1.set_title('Cluster Size Distribution', fontsize=14)
    ax1.set_xticks(sizes)
    ax1.grid(True, axis='y', alpha=0.3)
    
    # Plot 2: Cluster type distribution
    types = []
    type_counts = []
    for cluster_type, cluster_indices in cluster_types.items():
        types.append(cluster_type)
        type_counts.append(len(cluster_indices))
    
    # Sort by count (descending)
    sorted_types = [t for _, t in sorted(zip(type_counts, types), reverse=True)]
    sorted_counts = sorted(type_counts, reverse=True)
    
    bars2 = ax2.bar(sorted_types, sorted_counts, edgecolor='black',
                    color='lightgreen', alpha=0.7)
    
    for bar in bars2:
        height = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width()/2., height,
                f'{int(height)}', ha='center', va='bottom')
    
    ax2.set_xlabel('Cluster Type', fontsize=12)
    ax2.set_ylabel('Number of Clusters', fontsize=12)
    ax2.set_title('Cluster Type Distribution', fontsize=14)
    ax2.tick_params(axis='x', rotation=45)
    ax2.grid(True, axis='y', alpha=0.3)
    
    plt.suptitle(f'Hydrogen Bond Cluster Analysis (Loading: {loading})', 
                 fontsize=16, y=1.02)
    plt.tight_layout()
    plt.savefig(f'cluster_distributions_loading_{loading:.2f}.png', 
                dpi=300, bbox_inches='tight')
    logger.info(f"Saved cluster_distributions_loading_{loading:.2f}.png")
    plt.close()

def generate_extract_cluster_scripts(clusters: List[Set[int]], 
                                   cluster_types: Dict[str, List[int]],
                                   loading: float,
                                   gro_file_path: str,
                                   tpr_file_path: str) -> str:
    """Generate shell scripts to extract cluster GRO files"""
    output_dir = f"cluster_extraction_loading_{loading:.2f}"
    os.makedirs(output_dir, exist_ok=True)
    
    # Copy required files to extraction directory
    gro_filename = os.path.basename(gro_file_path)
    tpr_filename = os.path.basename(tpr_file_path)
    shutil.copy(gro_file_path, os.path.join(output_dir, gro_filename))
    shutil.copy(tpr_file_path, os.path.join(output_dir, tpr_filename))
    logger.info(f"Copied {gro_filename} and {tpr_filename} to {output_dir}")
    
    # Create a master script to run all extraction commands
    master_script = f"""#!/bin/bash
# Master script to extract all clusters
cd "$(dirname "$0")"

# Run all extraction scripts
export GMX_MAXBACKUP=-1
for script in extract_cluster_*.sh; do
    echo "Running $script..."
    ./"$script"
    rm "$script"
done

echo "All clusters extracted to GRO files"
"""
    
    master_script_path = os.path.join(output_dir, "extract_all_clusters.sh")
    with open(master_script_path, "w") as f:
        f.write(master_script)
    os.chmod(master_script_path, 0o755)
    
    # Generate individual extraction scripts for each cluster
    for cluster_type, cluster_indices in cluster_types.items():
        for idx in cluster_indices:
            cluster = clusters[idx]
            script_filename = os.path.join(output_dir, f"extract_cluster_{idx}_{cluster_type}.sh")
            
            # Create residue selection string
            resid_list = sorted(cluster)
            select_expr = " or ".join([f"resid {resid}" for resid in resid_list])
            
            # Create output GRO filename
            gro_output = f"cluster_{idx}_{cluster_type}.gro"
            
            # Create script content
            script_content = f"""#!/bin/bash
# Extract cluster {idx} (type: {cluster_type})
# Loading value: {loading}
export GMX_MAXBACKUP=-1
# Create temporary NDX file
cat > temp.ndx <<EOF
[ cluster_{idx} ]
{select_expr}
EOF

# Extract cluster using GROMACS tools
mpirun -n 1 gmx_mpi select -f "{gro_filename}" -s "{tpr_filename}" -select '{select_expr}' -on atom_list_{idx}.ndx
mpirun -n 1 gmx_mpi trjconv -f "{gro_filename}" -s "{tpr_filename}" -n atom_list_{idx}.ndx -o "{gro_output}" -pbc mol
mpirun -n 1 gmx_mpi editconf -f "{gro_output}" -o "{gro_output}" -c -d 1.0 -bt cubic

# Clean up temporary files
rm temp.ndx
rm atom_list_{idx}.ndx

echo "Extracted cluster {idx} to {gro_output}"
"""
            
            with open(script_filename, "w") as f:
                f.write(script_content)
            os.chmod(script_filename, 0o755)
    
    logger.info(f"Generated cluster extraction scripts in {output_dir}")
    return output_dir

def generate_vmd_script_for_cluster(cluster_id: int,
                                  cluster_type: str,
                                  loading: float,
                                  output_dir: str,
                                  gro_file_path: str) -> str:
    """Generate VMD TCL script to visualize a single cluster"""
    # Create output filename without path for Tachyon command
    output_base = f"cluster_{cluster_id}_{cluster_type}"
    
    # 确保使用正确的相对路径
    gro_filename = gro_file_path.replace('\\', '/')  # 确保使用正斜杠
    
    script_content = f"""# VMD script for cluster {cluster_id} (type: {cluster_type})
# Loading value: {loading}

# Initialize
mol delete all

# Set background to white
color Display Background white

# Load cluster structure
mol new "../{gro_filename}" type gro first 0 last -1 step 1 waitfor 1

mol delrep 0 top

# Use element-based coloring for different atom types
mol representation CPK 1.0 0.3 12.0 12.0
mol color Name
mol selection all
mol material Opaque
mol addrep top

# Add hydrogen bonds representation
mol representation HBonds 3.5 30.0 5
mol selection "name N O"  # 选择氮和氧原子
mol material Transparent
mol addrep top

# Set visualization parameters
display resetview
display projection Orthographic
display depthcue off
display rendermode GLSL
display ambientocclusion on
display shadows on
display aoambient 0.8
display aodirect 0.2

# Turn off axes
axes location off

# Center and zoom
set all [atomselect top all]
set center [measure center $all]
translate to $center
scale by 1.2
$all delete

# Render with Tachyon and convert to PNG directly

render Tachyon {output_base}.dat
exec tachyon {output_base}.dat -format PNG -o {output_base}.png
file delete {output_base}.dat  ;# Delete intermediate file
quit
"""

    # Save script
    script_filename = f"{output_dir}/{output_base}.tcl"
    with open(script_filename, "w") as f:
        f.write(script_content)
    
    return script_filename
    
def generate_vmd_scripts(clusters: List[Set[int]], 
                       cluster_types: Dict[str, List[int]],
                       loading: float,
                       gro_file_path: str,
                       extraction_dir: str) -> Tuple[str, List[str]]:
    """Generate VMD scripts for all clusters and return representative scripts"""
    output_dir = f"vmd_clusters_loading_{loading:.2f}"
    os.makedirs(output_dir, exist_ok=True)
    
    # Generate TCL scripts for ALL clusters
    all_scripts = []
    for cluster_type, cluster_indices in cluster_types.items():
        for idx in cluster_indices:
            cluster = clusters[idx]
            # Use relative path to cluster GRO file
            cluster_gro_filename = f"cluster_{idx}_{cluster_type}.gro"
            cluster_gro_path = os.path.join(os.path.basename(extraction_dir), cluster_gro_filename)
            script_path = generate_vmd_script_for_cluster(
                idx, cluster_type, loading, output_dir, cluster_gro_path
            )
            all_scripts.append(script_path)
    
    # Identify representative scripts (10% of each type, min 1 max 30)
    representative_scripts = []
    for cluster_type, cluster_indices in cluster_types.items():
        sample_size = max(1, min(30, len(cluster_indices) // 10))
        sampled_indices = random.sample(cluster_indices, sample_size) if len(cluster_indices) > 10 else cluster_indices
        
        for idx in sampled_indices:
            script_path = os.path.join(output_dir, f"cluster_{idx}_{cluster_type}.tcl")
            representative_scripts.append(script_path)
    
    # Create a batch script to render only representative clusters
    batch_script = f"""#!/bin/bash
# Batch script to render representative clusters

conda activate vmd
# Render representative TCL scripts
for script in {" ".join([os.path.basename(s) for s in representative_scripts])}; do
    echo "Rendering $script..."
    vmd -dispdev text -e "$script"
    rm "$script"
done

echo "Representative clusters rendered and converted to PNG"
"""
    
    batch_script_path = os.path.join(output_dir, "render_representative_clusters.sh")
    with open(batch_script_path, "w") as f:
        f.write(batch_script)
    
    os.chmod(batch_script_path, 0o755)  # Make executable
    
    logger.info(f"Generated {len(all_scripts)} VMD scripts in {output_dir}")
    logger.info(f"Selected {len(representative_scripts)} representative clusters for rendering")
    return output_dir, representative_scripts

def main():
    """Main function"""
    parser = argparse.ArgumentParser(description='Hydrogen bond cluster analysis and visualization')
    parser.add_argument('loading', type=float, 
                       help='Molecule loading value (0.00-0.40)')
    args = parser.parse_args()
    
    loading = args.loading
    logger.info(f"Analyzing loading value: {loading}")
    
    try:
        # File paths
        gro_file = "NVT_313.gro"
        tpr_file = "NVT_313.tpr"
        ndx_file = "hbond_total.ndx"
        
        # Parse files and build network
        atom_to_mol, all_molecules = parse_gro_file(gro_file)
        hbond_pairs = parse_hbond_ndx_section(ndx_file)
        G = build_hbond_network(atom_to_mol, hbond_pairs, all_molecules, loading)
        
        # Analyze clusters
        clusters, cluster_types = analyze_clusters(G, loading)
        
        # Generate all visualizations
        logger.info("Generating visualizations...")
        visualize_cluster_size_distribution(clusters, loading)
        visualize_cluster_type_distribution(cluster_types, loading)
        visualize_cluster_composition(clusters, loading)
        visualize_combined_distributions(clusters, cluster_types, loading)
        
        # Generate cluster extraction scripts
        logger.info("Generating cluster extraction scripts...")
        extraction_dir = generate_extract_cluster_scripts(clusters, cluster_types, loading, gro_file, tpr_file)
        
        # Generate VMD visualization scripts
        logger.info("Generating VMD visualization scripts...")
        vmd_dir, rep_scripts = generate_vmd_scripts(clusters, cluster_types, loading, gro_file, extraction_dir)
        
        logger.info("✅ All visualizations and scripts generated:")
        logger.info(f"1. cluster_size_distribution_loading_{loading:.2f}.png")
        logger.info(f"2. cluster_type_distribution_loading_{loading:.2f}.png")
        logger.info(f"3. cluster_composition_loading_{loading:.2f}.png")
        logger.info(f"4. cluster_distributions_loading_{loading:.2f}.png")
        logger.info(f"Cluster extraction scripts saved in: {extraction_dir}")
        logger.info(f"VMD scripts saved in: {vmd_dir}")
        logger.info(f"To extract clusters, run: cd {extraction_dir} && ./extract_all_clusters.sh")
        logger.info(f"To render representative clusters, run: cd {vmd_dir} && ./render_representative_clusters.sh")
        
        # 将代表性团簇信息写入文本文件
        rep_clusters_file = os.path.join(vmd_dir, "representative_clusters.txt")
        with open(rep_clusters_file, "w") as f:
            f.write(f"Representative clusters selected for rendering (Loading: {loading})\n")
            f.write("="*60 + "\n\n")
            for script in rep_scripts:
                script_name = os.path.basename(script)
                # 从脚本名中提取团簇信息
                cluster_id = script_name.split("_")[1]
                cluster_type = script_name.split("_", 2)[2].replace(".tcl", "")
                f.write(f"Cluster ID: {cluster_id}\n")
                f.write(f"Cluster Type: {cluster_type}\n")
                f.write(f"Script: {script_name}\n")
                f.write("-"*60 + "\n")
        
        logger.info(f"Representative clusters list saved to: {rep_clusters_file}")
        
    except Exception as e:
        logger.error(f"Error during execution: {str(e)}", exc_info=True)

if __name__ == "__main__":
    main()