#!/bin/bash

# 初始化变量
INPUT_GRO="$1"     # 输入的 .gro 文件路径
INPUT_TOP="$2"     # 输入的 .top 文件路径
OUTPUT_DIR="$3"    # 输出结果目录
LOG_DIR="$OUTPUT_DIR/logs"
mkdir -p "$OUTPUT_DIR" "$LOG_DIR"
PLOT_DIR="$OUTPUT_DIR/plots"
mkdir -p "$PLOT_DIR"
TEMPERATURES=(313)

# ========================================================================
# R² 状态检查（在能量最小化前）
# ========================================================================

# 检查粘度模拟是否已完成
status_file="viscosity_results/status_313.txt"
regression_file="regression_results.txt"

if [ -f "$status_file" ] && grep -q "SATISFIED" "$status_file"; then
    echo "已完成粘度的模拟"
    echo "----------------------------------------"
    
    # 打印回归结果文件内容
    if [ -f "$regression_file" ]; then
        echo "回归分析结果："
        cat "$regression_file"
        python3 /work/home/xuwenhao/dataprocess/linear_regression_analysis.py
    else
        echo "警告：未找到回归结果文件 $regression_file"
    fi
    
    echo "----------------------------------------"
    exit 0  # 正常退出
fi

# 设置OpenMP线程绑定
export MPI_PROCESSES=128   # 与Slurm中--cpus-per-task=2对应
export OMP_PLACES=cores
export OMP_PROC_BIND=spread,close
# 获取吸收剂序号（从当前路径提取）
ABSORBER_NUM=$(pwd | grep -oP 'Viscosity_cal/\K[0-9]+(?=/)')
if [ -z "$ABSORBER_NUM" ]; then
    ABSORBER_NUM="unknown"
fi

# 检查输入参数
if [ ! -f "$INPUT_GRO" ] || [ ! -f "$INPUT_TOP" ]; then
    echo "错误：输入文件缺失，请检查 $INPUT_GRO 和 $INPUT_TOP 是否存在。"  
    exit 1
fi

# 动态生成 MDP 文件记录到日志
echo "生成 MDP 文件..."  
MDP_DIR="$OUTPUT_DIR/mdp_files"
mkdir -p "$MDP_DIR"



# em.mdp
cat > "$MDP_DIR/em.mdp" <<EOF
; 能量最小化参数设置
integrator = steep
nsteps = 100000
emtol  = 10.0
emstep = 0.01
nstxout   = 100
nstlog    = 50
nstenergy = 10
pbc = xyz
cutoff-scheme = Verlet
coulombtype   = PME
rcoulomb      = 1.0
vdwtype       = Cut-off
rvdw          = 1.0
DispCorr      = EnerPres
constraints   = none
EOF

# 在脚本开头添加变量
ANNEALING_TEMP=${ANNEALING_TEMP:-650}  # 默认值为650
echo "使用退火温度: $ANNEALING_TEMP K"

# 修改md_heat_NPT.mdp生成部分
cat > "$MDP_DIR/md_heat_NPT.mdp" << EOF
; NPT模拟参数设置
integrator = md
dt         = 0.001
nsteps     = 500000
comm-grps  = system
nstxout = 0
nstvout = 0
nstfout = 0
nstlog  = 500
nstenergy = 500
annealing = periodic
annealing_npoints = 4
annealing_time = 0 60 160 400
annealing_temp = 0 $ANNEALING_TEMP $ANNEALING_TEMP 0
pbc = xyz
cutoff-scheme = Verlet
coulombtype   = PME
rcoulomb      = 1.0
vdwtype       = cut-off
rvdw          = 1.0
DispCorr      = EnerPres
Tcoupl  = V-rescale
tau_t   = 0.2
tc_grps = system
ref_t   = 298.15
Pcoupl     = berendsen
pcoupltype = isotropic
tau_p = 2.0
ref_p = 1.0
compressibility = 4.5e-5
gen_vel  = no
gen_seed = -1
;
freezegrps  = 
freezedim   = 
constraints = none
EOF

# md_NPT.mdp
cat > "$MDP_DIR/md_NPT.mdp" << EOF
; NPT2模拟参数设置
define =
integrator = md
dt         = 0.001   ; ps
nsteps     = 1000000 ; 1ns
comm-grps  = system
energygrps = 
;
nstxout = 0
nstvout = 0
nstfout = 0
nstlog  = 1000
nstenergy = 1000
nstxout-compressed = 1000
compressed-x-grps  = system
;
pbc = xyz
cutoff-scheme = Verlet
coulombtype   = PME
rcoulomb      = 1.0
vdwtype       = cut-off
rvdw          = 1.0
DispCorr      = EnerPres
;
Tcoupl  = V-rescale
tau_t   = 0.2
tc_grps = system
ref_t   = 353
;
Pcoupl     = C-rescale
pcoupltype = isotropic
tau_p = 2.0
ref_p = 1.0
compressibility = 4.5e-5
;
gen_vel  = no
gen_temp = 353
gen_seed = -1
;
constraint_algorithm = lincs
freezegrps  = 
freezedim   = 
constraints = none
EOF

# NVT.mdp
cat > "$MDP_DIR/NVT.mdp" <<EOF
; NVT模拟参数设置
integrator          = md
nsteps              = 1000000
dt                  = 0.001
nstxout             = 1000
nstvout             = 1000
nstenergy           = 1000
nstlog              = 1000
constraints         = none
cutoff-scheme       = Verlet
nstlist = 10
pbc                 = xyz
tcoupl              = V-rescale
tc-grps             = System
tau_t               = 0.2
ref_t               = 353
pcoupl              = no
EOF

# vis.mdp
cat > "$MDP_DIR/vis.mdp" <<EOF
; 粘度模拟参数
integrator          = md
nsteps              = 500000 
dt                  = 0.001
nstxout             = 100
nstvout             = 100
nstenergy           = 100
nstlog              = 1000
constraint_algorithm = Lincs
constraints         = none
lincs_iter = 1
lincs_order = 4
nstlist = 10
cutoff-scheme       = Verlet
rcoulomb = 1.4
rvdw = 1.4
coulombtype = PME
pme_order = 4
fourierspacing = 0.16
cos-acceleration    = 0.06
pbc                 = xyz
tcoupl              = nose-hoover
nh-chain-length          = 1
tc-grps             = System
tau_t               = 0.2
ref_t               = 353
pcoupl              = no
tau_p                    = 0.5
compressibility          = 4.5e-5
ref_p                    = 1.
EOF


# ========================================================================
# 函数：创建并提交Slurm作业
# 参数: $1=作业名称, $2=依赖作业ID, $3=命令
# ========================================================================
submit_slurm_job() {
    local job_name="num${ABSORBER_NUM}_$1"
    local dependency=$2
    local command=$3
        # 修复1: 正确的依赖语法
    local dependency_flag=""
    if [ -n "$dependency" ]; then
        dependency_flag="#SBATCH --dependency=afterok:$dependency"
    fi
    # 创建Slurm脚本
    local slurm_script="$OUTPUT_DIR/submit_${job_name}.slurm"
    cat > "$slurm_script" <<EOF
#!/bin/bash
#SBATCH --job-name=${job_name}
#SBATCH -N 4
#SBATCH --ntasks-per-node=32
#SBATCH -p tyhcnormal
#SBATCH --output=${OUTPUT_DIR}/${job_name}.out
#SBATCH --time=03:00:00
${dependency:+#SBATCH --dependency=afterok:${dependency}}

module purge
source /work/home/xuwenhao/software/gromacs-2024.4/scripts/env.sh
export I_MPI_PMI_LIBRARY=/opt/gridview/slurm/lib/libpmi.so

cd $OUTPUT_DIR

export GMX_MAXBACKUP=-1
# 执行命令
$command
EOF

    # 提交作业并获取ID
    local job_id=$(sbatch --parsable "$slurm_script")
    echo "${job_id}"
}

# 在脚本开头添加通用等待函数
wait_for_file() {
    local file="$1"
    local max_attempts="${2:-240}"  # 默认等待240分钟（4小时）
    local attempt=0
    
    while [ ! -f "$file" ]; do
        if [ $attempt -ge $max_attempts ]; then
            echo "错误：等待文件 $file 超时"
            exit 1
        fi
        sleep 60
        attempt=$((attempt+1))
    done
}

wait_for_pattern() {
    local file="$1"
    local pattern="$2"
    local max_attempts="${3:-240}"
    local attempt=0
    
    while [ ! -f "$file" ] || ! grep -q "$pattern" "$file"; do
        if [ $attempt -ge $max_attempts ]; then
            echo "错误：等待文件 $file 中出现 $pattern 超时"
            exit 1
        fi
        sleep 60
        attempt=$((attempt+1))
    done
}


# ========================================================================
# 函数：更新GRO文件 (需在作业脚本中重新定义)
# ========================================================================
update_gro_file() {
    # 查找最新的GRO文件 (排除备份文件)
    latest_gro=$(find "$OUTPUT_DIR" -name 'md_heat_NPT*.gro' -not -name '*prev*' \
                | sort -t. -k1V -k3n | tail -1)
    
    if [ -n "$latest_gro" ]; then
        echo "更新GRO文件: $latest_gro → $OUTPUT_DIR/md_heat_NPT.gro"
        cp -v "$latest_gro" "$OUTPUT_DIR/md_heat_NPT.gro"
        return 0
    else
        echo "错误：未找到有效的GRO文件"
        return 1
    fi
}

# ========================================================================
# 函数：检查升温退火NPT是否完成 (需在作业脚本中重新定义)
# ========================================================================
check_npt_finished() {
    # 检查所有可能的日志文件变体
    grep -q 'Finished mdrun' "$OUTPUT_DIR/md_heat_NPT.log" 2>/dev/null ||
    grep -q 'Finished mdrun' "$OUTPUT_DIR/md_heat_NPT.part"*.log 2>/dev/null ||
    grep -q 'Finished mdrun' "$OUTPUT_DIR/"md_heat_NPT*.log 2>/dev/null
}


# 初始化作业ID变量
em_jobid=""
npt_heating_jobid=""
declare -A npt_jobids
declare -A nvt_jobids
# 动态确定输入结构文件

find_input_gro() {
    # 查找任何存在的NVT_前缀文件
    if ls "$OUTPUT_DIR"/NVT_*.gro 1> /dev/null 2>&1; then
        # 找到NVT文件，返回最新生成的
        echo "$(ls -t "$OUTPUT_DIR"/NVT_*.gro | head -1)"
        return 0
    fi
    
    # 查找任何存在的md_NPT_前缀文件
    if ls "$OUTPUT_DIR"/md_NPT_*.gro 1> /dev/null 2>&1; then
        # 找到md_NPT文件，返回最新生成的
        echo "$(ls -t "$OUTPUT_DIR"/md_NPT_*.gro | head -1)"
        return 0
    fi
    
    # 检查基础模拟文件
    if [ -f "$OUTPUT_DIR/md_heat_NPT.gro" ]; then
        echo "$OUTPUT_DIR/md_heat_NPT.gro"
        return 0
    elif [ -f "$OUTPUT_DIR/em.gro" ]; then
        echo "$OUTPUT_DIR/em.gro"
        return 0
    fi
    
    # 默认返回原始输入
    echo "$1"
    return 1
}

# 在能量最小化前重新赋值 INPUT_GRO
INPUT_GRO=$(find_input_gro "$INPUT_GRO")
echo "使用结构文件: $INPUT_GRO"

# ========================================================================
# Step 1: 能量最小化
# ========================================================================
if ! grep -q 'Finished mdrun' "$OUTPUT_DIR/em.log"; then
    cmd="mpirun -n 1 gmx_mpi grompp -f \"$MDP_DIR/em.mdp\" -c \"$INPUT_GRO\" -p \"$INPUT_TOP\" -o \"$OUTPUT_DIR/em.tpr\" -maxwarn 5;
          mpirun -np 128 gmx_mpi mdrun -v -deffnm \"$OUTPUT_DIR/em\""
    submit_slurm_job "em" "" "$cmd"
    
    # 等待作业完成 - 使用文件检查
    wait_for_pattern "$OUTPUT_DIR/em.log" "Finished mdrun"
    echo "能量最小化作业已完成"
else
    echo "能量最小化已完成，跳过"
fi
# ========================================================================
# Step 2: 升温退火NPT系综 (完整版)
# ========================================================================
if ! check_npt_finished; then
    # 创建完整的升温退火NPT作业脚本
    npt_slurm_script="$OUTPUT_DIR/submit_num${ABSORBER_NUM}_md_heat_NPT.slurm"
cat > "$npt_slurm_script" <<EOF
#!/bin/bash
#SBATCH --job-name=num${ABSORBER_NUM}_md_heat_NPT
#SBATCH -N 4
#SBATCH --ntasks-per-node=32
#SBATCH -p tyhcnormal
#SBATCH --output=${OUTPUT_DIR}/md_heat_NPT.out
#SBATCH --time=03:00:00
${em_jobid:+#SBATCH --dependency=afterok:$em_jobid}  # 修复2: 正确的依赖语法


module purge
source /work/home/xuwenhao/software/gromacs-2024.4/scripts/env.sh
export I_MPI_PMI_LIBRARY=/opt/gridview/slurm/lib/libpmi.so



# 重新定义必要函数
update_gro_file() {
    latest_gro=\$(find "$OUTPUT_DIR" -name 'md_heat_NPT*.gro' -not -name '*prev*' | sort -t. -k1V -k3n | tail -1)
    if [ -n "\$latest_gro" ]; then
        cp -v "\$latest_gro" "$OUTPUT_DIR/md_heat_NPT.gro"
    fi
}

check_npt_finished() {
    grep -q 'Finished mdrun' "$OUTPUT_DIR/md_heat_NPT.log" 2>/dev/null ||
    grep -q 'Finished mdrun' "$OUTPUT_DIR/md_heat_NPT.part"*.log 2>/dev/null ||
    grep -q 'Finished mdrun' "$OUTPUT_DIR/"md_heat_NPT*.log 2>/dev/null
}

cd "$OUTPUT_DIR"

# 运行模拟
if [ -f "md_heat_NPT.cpt" ]; then
    echo "检测到检查点文件，进行续跑..."
    COORDINATE="md_heat_NPT.gro"
    if [ ! -f "\$COORDINATE" ]; then
        COORDINATE="em.gro"
        echo "警告：使用em.gro作为替代坐标文件"
    fi
    mpirun -n 1 gmx_mpi grompp -f "$MDP_DIR/md_heat_NPT.mdp" -c "\$COORDINATE" -p "$INPUT_TOP" -o "md_heat_NPT.tpr" -maxwarn 5 -t "md_heat_NPT.cpt"
    mpirun -np 128 gmx_mpi mdrun -v -s "md_heat_NPT.tpr" -cpi "md_heat_NPT.cpt" -cpt 0.5 -dd 4 4 8 -deffnm "md_heat_NPT" -noappend
else
    echo "无检查点文件，开始新运行..."
    mpirun -n 1 gmx_mpi grompp -f "$MDP_DIR/md_heat_NPT.mdp" -c "em.gro" -p "$INPUT_TOP" -o "md_heat_NPT.tpr" -maxwarn 5
    mpirun -np 128 gmx_mpi mdrun -v -cpi "md_heat_NPT.cpt" -cpt 0.5 -dd 4 4 8 -deffnm "md_heat_NPT"
fi

# 续跑逻辑
max_attempts=8
for (( attempt = 1; attempt <= max_attempts; attempt++ )); do
    if check_npt_finished; then
        echo "模拟成功完成于第 $attempt 次续跑检查。"
        update_gro_file
        exit 0 # 成功完成，退出状态0
    fi
    
    if [ -f "md_heat_NPT.cpt" ]; then
        echo "尝试续跑 #\$attempt"
        mpirun -np 128 gmx_mpi mdrun -v -s "md_heat_NPT.tpr" -cpi "md_heat_NPT.cpt" -cpt 0.5 -dd 4 4 8 -deffnm "md_heat_NPT" -noappend
    else
        echo "无检查点文件，无法续跑"
        break
    fi
done

# 最终检查
if check_npt_finished; then
  echo "NPT模拟在循环结束后确认完成。"
  update_gro_file
  exit 0
else
  echo "错误：NPT模拟在 $max_attempts 次尝试后仍未完成或失败。" >&2
  # 此处可以添加收集日志和错误信息的命令，便于调试
  exit 1
fi
EOF

    # 提交作业
    npt_heating_jobid=$(sbatch --parsable "$npt_slurm_script")
    echo "已提交升温退火NPT作业: ID=$npt_heating_jobid"

    # 等待作业完成 - 使用文件检查
    while ! check_npt_finished; do
        sleep 60
    done
    echo "升温退火NPT作业已完成"
else
    echo "升温退火NPT模拟已完成，跳过"
fi

# 确保GRO文件更新
update_gro_file


# 定义函数以动态获取编号
function get_energy_index {
    local edr_file="$1"      # Energy 文件路径
    local search_key="$2"    # 搜索的参数名称
    local index              # 保存找到的编号
    
    # 使用 gmx energy 的 ? 模式获取编号
    echo -e "0\n" | mpirun -n 1 gmx_mpi energy -f "$edr_file" >> "energy.log" 2>&1
    index=$(grep -i "$search_key" energy.log | awk -v key="$search_key" '{for(i=1; i<=NF; i++) if($i==key) print $(i-1)}')

    # 检查是否找到编号
    if [ -z "$index" ]; then
        echo "未找到参数 $search_key 的编号，请检查 energy 文件和参数名称。" >&2
        exit 1
    fi

    echo "$index"  # 返回找到的编号
}

# 确保 result 目录存在
mkdir result
rm -f energy.log


# 能量最小化 - 动态解析 Potential 的编号
POTENTIAL_INDEX=$(get_energy_index "em.edr" "Potential")
mpirun -n 1 gmx_mpi energy -f em.edr -o result/em_Potential.xvg << EOF
$POTENTIAL_INDEX
EOF
echo "能量最小化结果已保存 (Potential)。"
rm -f energy.log

# NPT1 - 动态解析 Density 的编号
DENSITY_INDEX=$(get_energy_index "md_heat_NPT.edr" "Density")
mpirun -n 1 gmx_mpi energy -f md_heat_NPT.edr -o result/md_heat_NPT_Density.xvg << EOF
$DENSITY_INDEX
EOF
echo "NPT1 结果已保存 (Density)。"
rm -f energy.log

# NPT1 - 动态解析 Temperature 的编号
Temperature_INDEX=$(get_energy_index "md_heat_NPT.edr" "Temperature")
mpirun -n 1 gmx_mpi energy -f md_heat_NPT.edr -o result/md_heat_NPT_Temperature.xvg << EOF
$Temperature_INDEX
EOF
echo "NPT 结果已保存 (Temperature)。"
rm -f energy.log

python3 /work/home/xuwenhao/dataprocess/em_Potential_plot.py result/em_Potential.xvg
python3 /work/home/xuwenhao/dataprocess/NPT_Temperature_density_plot.py result/md_heat_NPT_Density.xvg result/md_heat_NPT_Temperature.xvg


pwd


# 对不同温度进行模拟  
for TEMP in "${TEMPERATURES[@]}"; do  
    echo "当前温度: $TEMP K"    
    
    # ========================================================================
    # Step 3: NPT 平衡
    # ========================================================================
    if ! grep -q 'Finished mdrun' "$OUTPUT_DIR/md_NPT_${TEMP}.log"; then
    cmd="sed \"s|ref_t.*|ref_t = $TEMP|\" \"$MDP_DIR/md_NPT.mdp\" | sed \"s|gen_temp.*|gen_temp = $TEMP|\" > \"$OUTPUT_DIR/md_NPT_${TEMP}.mdp\"
          mpirun -n 1 gmx_mpi grompp -f \"$OUTPUT_DIR/md_NPT_${TEMP}.mdp\" -c \"$OUTPUT_DIR/md_heat_NPT.gro\" -p \"$INPUT_TOP\" -o \"$OUTPUT_DIR/md_NPT_${TEMP}.tpr\" -maxwarn 5
          mpirun -np 128 gmx_mpi mdrun -v -deffnm \"$OUTPUT_DIR/md_NPT_${TEMP}\""
    
    # 设置依赖
    npt_jobids[$TEMP]=$(submit_slurm_job "md_NPT_${TEMP}" "$npt_heating_jobid" "$cmd")
    
        # 等待作业完成 - 使用文件检查
        wait_for_pattern "$OUTPUT_DIR/md_NPT_${TEMP}.log" "Finished mdrun"
        echo "NPT作业 (${TEMP}K) 已完成"
    else
        echo "NPT平衡 (${TEMP}K) 已完成，跳过"
    fi
    
    # 密度平衡检查
    if [ -f "$OUTPUT_DIR/md_NPT_${TEMP}.edr" ]; then
        echo "检查NPT平衡状态 (${TEMP}K)..."
        
        # 提取密度数据
DENSITY_INDEX=$(get_energy_index "md_NPT_${TEMP}.edr" "Density")
mpirun -n 1 gmx_mpi energy -f "$OUTPUT_DIR/md_NPT_${TEMP}.edr" -b 400 > "$OUTPUT_DIR/density_check_${TEMP}.log" 2>&1 <<EOF
$DENSITY_INDEX
EOF

        # 使用Python脚本分析密度稳定性
        python3 /work/home/xuwenhao/dataprocess/density_check.py "$OUTPUT_DIR/density_check_${TEMP}.log" "$TEMP"
        density_check_result=$?

        if [ $density_check_result -eq 0 ]; then
            echo "密度平衡满足要求 (<2%波动)"
        else
            echo "密度平衡不满足要求 (≥2%波动)，提高退火温度并重新运行..."
            
            # 提高退火温度
            NEW_ANNEALING_TEMP=$((ANNEALING_TEMP + 50))
            echo "新的退火温度: $NEW_ANNEALING_TEMP K"
            
            # 删除关键文件以强制重新运行
            rm -f "$OUTPUT_DIR"/em.* "$OUTPUT_DIR"/md_heat*.*
            rm -f "$OUTPUT_DIR"/md_NPT_*.log          # 删除NPT日志
			rm -f "$OUTPUT_DIR"/NVT_*.log             # 删除NVT日志

            # 创建新的提交脚本
            cat > "gromacs_retry_${ABSORBER_NUM}.slurm" <<EOF
#!/bin/bash
#SBATCH -p tyhcnormal
#SBATCH -J num${ABSORBER_NUM}_gromacs_retry
#SBATCH -N 1
#SBATCH --ntasks-per-node=1
#SBATCH --output=%x.log

cd "$OUTPUT_DIR"
export ANNEALING_TEMP=$NEW_ANNEALING_TEMP
pwd
../gromacs_viscosity.sh "$OUTPUT_DIR/md_NPT_${TEMP}.gro" "$INPUT_TOP" "$OUTPUT_DIR"
EOF

            # 提交作业
            sbatch "gromacs_retry_${ABSORBER_NUM}.slurm"
            
            # 退出当前运行
            exit 1
        fi
    else
        echo "未找到NPT能量文件，跳过平衡检查"
    fi

    # ========================================================================
    # Step 4: NVT 模拟
    # ========================================================================
    if ! grep -q 'Finished mdrun' "$OUTPUT_DIR/NVT_${TEMP}.log"; then
    cmd="sed \"s|ref_t.*|ref_t = $TEMP|\" \"$MDP_DIR/NVT.mdp\" > \"$OUTPUT_DIR/NVT_${TEMP}.mdp\"
          mpirun -n 1 gmx_mpi grompp -f \"$OUTPUT_DIR/NVT_${TEMP}.mdp\" -c \"$OUTPUT_DIR/md_NPT_${TEMP}.gro\" -p \"$INPUT_TOP\" -o \"$OUTPUT_DIR/NVT_${TEMP}.tpr\" -maxwarn 5
          mpirun -np 128 gmx_mpi mdrun -v -deffnm \"$OUTPUT_DIR/NVT_${TEMP}\""
    
    # 设置依赖
    local dep_id=${npt_jobids[$TEMP]:-$npt_heating_jobid}
    nvt_jobids[$TEMP]=$(submit_slurm_job "NVT_${TEMP}" "$dep_id" "$cmd")
    
        # 等待作业完成 - 使用文件检查
        wait_for_pattern "$OUTPUT_DIR/NVT_${TEMP}.log" "Finished mdrun"
        echo "NVT作业 (${TEMP}K) 已完成"
    else
        echo "NVT模拟 (${TEMP}K) 已完成，跳过"
    fi


# Step 5: 粘度模拟 - 自动化R²验证流程
echo "执行粘度模拟（带R²验证）..."

# 初始加速度振幅列表
ACCELERATIONS=(0.045 0.040 0.035 0.030 0.025 0.020 0.015 0.010 0.005)
MIN_ACC=0.005       # 最小允许加速度振幅
MAX_EXTRA_POINTS=4  # 最大额外点数
EXTRA_COUNT=0       # 当前额外点数
SATISFIED=false     # R²满足标志

RESULT_DIR="$OUTPUT_DIR/viscosity_results"
mkdir -p "$RESULT_DIR"

# 清理可能存在的旧状态文件
rm -f "$RESULT_DIR"/status_*.txt "$RESULT_DIR"/new_acc_*.txt
# 创建提交脚本的函数
create_submit_script() {
    local TEMP="$1"
    local ACC="$2"
    local DEPENDENCY="$3"  # 可选的依赖作业ID
    
    # 基础脚本内容
    local SCRIPT_CONTENT=$(cat <<EOF
#!/bin/bash
#SBATCH --job-name=num${ABSORBER_NUM}_post_${TEMP}_${ACC}
#SBATCH --output=${OUTPUT_DIR}/post_${TEMP}_${ACC}.out
#SBATCH -N 1
#SBATCH --ntasks-per-node=1
#SBATCH -p tyhcnormal
${DEPENDENCY:+#SBATCH --dependency=afterok:$DEPENDENCY}

module purge
source /work/home/xuwenhao/software/gromacs-2024.4/scripts/env.sh
export I_MPI_PMI_LIBRARY=/opt/gridview/slurm/lib/libpmi.so

cd "$OUTPUT_DIR"

echo "开始后处理：提取轨迹并生成速度剖面..."
mpirun -n 1 gmx_mpi trjconv -f "$OUTPUT_DIR/vis_${TEMP}_${ACC}.trr" -s "$OUTPUT_DIR/vis_${TEMP}_${ACC}.tpr" -o "$OUTPUT_DIR/traj_${TEMP}_${ACC}.gro" -b 350 -e 450 << END
2
END

python3 /work/home/xuwenhao/dataprocess/velocity_profile.py -f "$OUTPUT_DIR/traj_${TEMP}_${ACC}.gro" -o "$OUTPUT_DIR/zvx_${TEMP}_${ACC}.xvg" --mode atom --dz 0.1 --plot "$OUTPUT_DIR/velocity_profile_${TEMP}_${ACC}.png"

# 清理中间文件
if [[ -s "$OUTPUT_DIR/velocity_profile_${TEMP}_${ACC}.png" ]]; then
    echo "清除中间文件..."
    rm -f "$OUTPUT_DIR/traj_${TEMP}_${ACC}.gro"
    rm -f "$OUTPUT_DIR/vis_${TEMP}_${ACC}.trr"
else
    echo "警告：未检测到图像文件，保留中间文件"
fi

echo "后处理完成！"
EOF
    )

    # 写入文件
    echo "$SCRIPT_CONTENT" > "$OUTPUT_DIR/submit_post_${TEMP}_${ACC}.slurm"
}
while [ "$SATISFIED" = false ] && [ $EXTRA_COUNT -le $MAX_EXTRA_POINTS ]; do
    declare -a job_ids
    declare -a post_job_ids
    
    # 提交当前振幅列表的作业
    for ACC in "${ACCELERATIONS[@]}"; do
        # 检查是否已运行过（避免重复计算）
        if [ -f "$OUTPUT_DIR/vis_${TEMP}_${ACC}.log" ] && grep -q 'Finished mdrun' "$OUTPUT_DIR/vis_${TEMP}_${ACC}.log"; then
            echo "跳过已完成的模拟：TEMP=${TEMP} ACC=${ACC}"
			            # +++ 新增：检查后处理是否已完成 +++
            if [ ! -f "$OUTPUT_DIR/velocity_profile_${TEMP}_${ACC}.png" ]; then
                echo "模拟已完成但后处理未完成，提交后处理作业"
                create_submit_script "$TEMP" "$ACC" ""
				post_job_id=$(sbatch --parsable "$OUTPUT_DIR/submit_post_${TEMP}_${ACC}.slurm")
                post_job_ids+=($post_job_id)
                echo "已提交后处理作业: ID=$post_job_id"
            else
                echo "后处理已完成，跳过"
            fi

            continue
        fi
        
        # ==== 修复1：确保提交脚本生成 ====
        # 1. 粘度模拟作业
cat > "$OUTPUT_DIR/submit_vis_${TEMP}_${ACC}.slurm" <<EOF
#!/bin/bash
#SBATCH --job-name=num${ABSORBER_NUM}_vis_${TEMP}_${ACC}
#SBATCH -N 4
#SBATCH --ntasks-per-node=32
#SBATCH -p tyhcnormal
#SBATCH --output=${OUTPUT_DIR}/vis_${TEMP}_${ACC}.out
#SBATCH --time=03:00:00
${nvt_jobids[$TEMP]:+#SBATCH --dependency=afterok:${nvt_jobids[$TEMP]}}   # 添加NVT作业依赖

module purge
source /work/home/xuwenhao/software/gromacs-2024.4/scripts/env.sh
export I_MPI_PMI_LIBRARY=/opt/gridview/slurm/lib/libpmi.so

cd "$OUTPUT_DIR"

# 生成MDP文件
sed "s|cos-acceleration.*|cos-acceleration = $ACC|" "$MDP_DIR/vis.mdp" | sed "s|ref_t.*|ref_t = $TEMP|" > "$OUTPUT_DIR/vis_${TEMP}_${ACC}.mdp"

# 运行模拟
mpirun -n 1 gmx_mpi grompp -f "$OUTPUT_DIR/vis_${TEMP}_${ACC}.mdp" -c "$OUTPUT_DIR/NVT_${TEMP}.gro" -p "$INPUT_TOP" -o "$OUTPUT_DIR/vis_${TEMP}_${ACC}.tpr" -maxwarn 5
mpirun -np 128 gmx_mpi mdrun -v -deffnm "$OUTPUT_DIR/vis_${TEMP}_${ACC}"

# 检查是否完成
if grep -q 'Finished mdrun' "$OUTPUT_DIR/vis_${TEMP}_${ACC}.log"; then
    echo "粘度模拟 ${TEMP}K ${ACC}nm/ps² 完成"
    exit 0
else
    echo "错误：粘度模拟 ${TEMP}K ${ACC}nm/ps² 未完成"
    exit 1
fi
EOF

        # 提交粘度模拟作业
        vis_job_id=$(sbatch --parsable "$OUTPUT_DIR/submit_vis_${TEMP}_${ACC}.slurm")
        job_ids+=($vis_job_id)
        echo "已提交粘度模拟作业: ID=$vis_job_id (TEMP=$TEMP, ACC=$ACC)"
        


        # 提交后处理作业
        create_submit_script "$TEMP" "$ACC" "$vis_job_id"
        post_job_id=$(sbatch --parsable "$OUTPUT_DIR/submit_post_${TEMP}_${ACC}.slurm")
        post_job_ids+=($post_job_id)
        echo "已提交后处理作业: ID=$post_job_id (依赖 $vis_job_id)"
    done

    # ==== 修复3：确保等待逻辑正确 ====
    # 等待所有粘度作业完成
    if [ ${#job_ids[@]} -gt 0 ]; then
        echo "等待所有粘度作业完成 (${job_ids[@]})..."
        dependency_ids=$(IFS=:; echo "${job_ids[*]}")
        
        # 创建等待作业
cat > "$OUTPUT_DIR/wait_${TEMP}.slurm" <<EOF
#!/bin/bash
#SBATCH --job-name=wait_${TEMP}
#SBATCH --dependency=afterany:$dependency_ids
#SBATCH --output=${OUTPUT_DIR}/wait_${TEMP}.out
#SBATCH -N 1
#SBATCH --ntasks-per-node=1
#SBATCH -p tyhcnormal
#SBATCH --time=00:10:00

echo "所有粘度作业已完成"
exit 0
EOF
        
        wait_job=$(sbatch --parsable "$OUTPUT_DIR/wait_${TEMP}.slurm")
        echo "等待作业已提交: ID=$wait_job"
        
        # 实际等待
        echo "实际等待作业完成..."
        while squeue -j $wait_job &>/dev/null; do
            sleep 60
        done
        echo "所有粘度作业确认完成"
    else
        echo "所有振幅点的模拟均已存在，跳过作业提交"
    fi

    # ==== 修复4：确保分析作业正确执行 ====
    # 分析步骤
echo "开始分析步骤..."
cat > "$OUTPUT_DIR/analysis_${TEMP}.slurm" <<ANALYSIS_EOF
#!/bin/bash
#SBATCH --job-name=num${ABSORBER_NUM}_analysis_${TEMP}
#SBATCH --output=${OUTPUT_DIR}/analysis_${TEMP}.out
#SBATCH -N 1
#SBATCH --ntasks-per-node=1
#SBATCH -p tyhcnormal

module purge
source /work/home/xuwenhao/software/gromacs-2024.4/scripts/env.sh
export I_MPI_PMI_LIBRARY=/opt/gridview/slurm/lib/libpmi.so

cd "$OUTPUT_DIR"

echo "开始分析步骤 (温度: $TEMP)..."

# 数据提取
/work/home/xuwenhao/dataprocess/edr_output.sh "$OUTPUT_DIR" "$TEMP" ${ACCELERATIONS[@]}

# 粘度和能量处理
python3 /work/home/xuwenhao/dataprocess/extract_energy_log.py analysis_${TEMP}.out
rm -f viscosity_summary.txt
python3 /work/home/xuwenhao/dataprocess/extract_viscosity.py analysis_${TEMP}.out "$TEMP" "${ACCELERATIONS[*]}"
python3 /work/home/xuwenhao/dataprocess/process_viscosity_data.py viscosity_summary.txt

# 回归分析
python3 /work/home/xuwenhao/dataprocess/linear_regression_analysis.py
#python3 /work/home/xuwenhao/dataprocess/plot_viscosity_acceleration.py viscosity_summary.txt "$OUTPUT_DIR/plots"
#取R2最高的5个点拟合
#python3 /work/home/xuwenhao/dataprocess/linear_regression_analysis.py viscosity_summary.txt "$OUTPUT_DIR/plots"
# ==== 新增：保存结果文件到结果目录 ====
mkdir -p "$RESULT_DIR"
cp viscosity_summary.txt "$RESULT_DIR/viscosity_summary_T${T}K.txt"

# 回归分析
# R²值校验
R2_FILE="${OUTPUT_DIR}/plots/regression_results_T${TEMP}K.txt"
if [ ! -f "\$R2_FILE" ]; then
    echo "错误：未找到回归结果文件！" >&2
    exit 1
fi

# 替换为以下内容：
R2=\$(awk '/R²/{gsub(/[^0-9.]/,"",\$NF); print \$NF}' "\$R2_FILE")
if [ -z "\$R2" ]; then
    echo "错误：未能提取R²值" >&2
    exit 1
fi
echo "R²值: \$R2"

# 浮点数比较
if awk -v r2="\$R2" 'BEGIN { exit !(r2 >= 0.95) }'; then
    echo "R²值满足要求 (\$R2 >= 0.95)"
    echo "最终粘度: \$(grep 'η₀₀₀₀₀₀₀₀₀₀₀₀₀₀₀₀' "\$R2_FILE" | awk '{print \$4}') mPa·s"
    echo "SATISFIED" > "$RESULT_DIR/status_${TEMP}.txt"
else
    echo "R²值不满足要求 (\$R2 < 0.95)，添加更小振幅..."
    
    # 获取当前最小的加速度值
    MIN_CURRENT=\$(ls $OUTPUT_DIR/zvx_${TEMP}_*.xvg 2>/dev/null | grep -oP '(?<=_)[0-9.]+(?=.xvg)' | sort -g | head -n 1)
    if [ -z "\$MIN_CURRENT" ]; then
        echo "错误：无法获取当前最小加速度值" >&2
        exit 1
    fi
    echo "当前最小加速度值: \$MIN_CURRENT"
    
    # 计算新加速度
    NEW_ACC=\$(echo "\$MIN_CURRENT - 0.0025" | bc -l | awk '{printf "%.4f", \$0}')
    echo "计算新加速度: \$NEW_ACC"
    
    # 边界检查
    if [ \$(echo "\$NEW_ACC < $MIN_ACC" | bc -l) -eq 1 ]; then
        echo "警告：新加速度 \$NEW_ACC 小于最小值 $MIN_ACC，使用最小值"
        NEW_ACC=$MIN_ACC
    fi
    
    echo "添加新振幅: \$NEW_ACC"
    echo "\$NEW_ACC" > "$RESULT_DIR/new_acc_${TEMP}.txt"
    echo "ADD_POINT" > "$RESULT_DIR/status_${TEMP}.txt"
    
    echo "已写入新加速度点: \$NEW_ACC"
fi
ANALYSIS_EOF

# 提交分析作业
sbatch "$OUTPUT_DIR/analysis_${TEMP}.slurm"
echo "分析作业已提交"
    
    # 等待分析结果
    echo "等待分析结果..."
    while [ ! -f "$RESULT_DIR/status_${TEMP}.txt" ]; do
        sleep 60
    done

    # 处理分析结果
    STATUS=$(cat "$RESULT_DIR/status_${TEMP}.txt")
    
    if [ "$STATUS" = "SATISFIED" ]; then
        SATISFIED=true
        echo "成功满足R²要求!"
    elif [ "$STATUS" = "ADD_POINT" ]; then
        # 添加新振幅到列表
        NEW_ACC=$(cat "$RESULT_DIR/new_acc_${TEMP}.txt")
        # 确保新加速度点不在当前列表中
        if [[ ! " ${ACCELERATIONS[@]} " =~ " ${NEW_ACC} " ]]; then
            ACCELERATIONS+=("$NEW_ACC")
            EXTRA_COUNT=$((EXTRA_COUNT + 1))
            echo "添加新振幅点: $NEW_ACC (当前点数: ${#ACCELERATIONS[@]})"
            continue # 立即重新开始循环
        else
            echo "新加速度点 $NEW_ACC 已在列表中，跳过添加"
        fi
    else
        echo "无法满足R²要求，终止计算"
        break
    fi
    
done

done