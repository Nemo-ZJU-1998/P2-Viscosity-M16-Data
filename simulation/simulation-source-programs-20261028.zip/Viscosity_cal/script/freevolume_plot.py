import argparse
import matplotlib.pyplot as plt
import numpy as np

# 设置字体以避免中文显示问题（使用默认英文字体）
plt.rcParams['font.sans-serif'] = ['DejaVu Sans']  # 使用默认英文字体
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

def read_data(file_path):
    """
    从文本文件读取数据
    文件格式应为两列：Loading和1/FFV，以空格或制表符分隔
    """
    loadings = []
    inverse_ffv = []
    
    try:
        with open(file_path, 'r') as file:
            # 跳过可能的标题行
            lines = file.readlines()
            for line in lines:
                # 忽略空行和注释行
                if line.strip() and not line.strip().startswith('#'):
                    # 尝试分割行数据
                    parts = line.split()
                    if len(parts) >= 2:
                        try:
                            loadings.append(float(parts[0]))
                            inverse_ffv.append(float(parts[1]))
                        except ValueError:
                            print(f"警告: 无法解析行: {line.strip()}")
                            continue
        return loadings, inverse_ffv
    except FileNotFoundError:
        print(f"错误: 文件 {file_path} 未找到")
        return [], []

def plot_data(loadings, inverse_ffv, output_file):
    """
    绘制数据并保存为图像
    """
    if not loadings or not inverse_ffv:
        print("错误: 没有有效数据可绘制")
        return False
    
    # 创建图形
    plt.figure(figsize=(10, 6))
    
    # 绘制数据点及连线
    plt.plot(loadings, inverse_ffv, 'o-', color='blue', linewidth=2, markersize=8)
    
    # 设置标题和标签
    plt.title('1/FFV vs Loading', fontsize=16)
    plt.xlabel('Loading (mol/mol)', fontsize=14)
    plt.ylabel('1/FFV', fontsize=14)
    
    # 添加网格
    plt.grid(True, linestyle='--', alpha=0.7)
    
    # 自动调整布局
    plt.tight_layout()
    
    # 保存图像
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    print(f"图像已保存为: {output_file}")
    
    # 显示图像
    plt.show()
    
    return True

def main():
    # 设置命令行参数解析
    parser = argparse.ArgumentParser(description='Plot 1/FFV vs Loading from text file')
    parser.add_argument('-i', '--input', required=True, help='Input text file path')
    parser.add_argument('-o', '--output', required=True, help='Output image file path')
    
    args = parser.parse_args()
    
    # 读取数据
    loadings, inverse_ffv = read_data(args.input)
    
    # 检查是否成功读取数据
    if not loadings or not inverse_ffv:
        print("错误: 未能从文件中读取有效数据")
        return
    
    # 绘制数据
    success = plot_data(loadings, inverse_ffv, args.output)
    
    if success:
        print("绘图完成!")
    else:
        print("绘图过程中出现错误")

if __name__ == "__main__":
    main()