import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# 设置绘图风格（无中文支持）
plt.style.use('default')
sns.set_palette("deep")
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial', 'Helvetica', 'DejaVu Sans']
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False

def plot_density_vs_loading():
    """绘制密度随加载量变化的图表"""
    # 读取数据
    try:
        data = pd.read_csv('density_results.csv')
        print("Data loaded successfully:")
        print(data.head())
    except FileNotFoundError:
        print("Error: density_results.csv file not found.")
        return
    except Exception as e:
        print(f"Error reading CSV file: {e}")
        return
    
    # 确保数据列存在
    required_cols = ['loading', 'density', 'error']
    for col in required_cols:
        if col not in data.columns:
            print(f"Error: Column '{col}' not found in the data.")
            return
    
    # 转换为数值类型
    try:
        data['loading'] = pd.to_numeric(data['loading'])
        data['density'] = pd.to_numeric(data['density'])
        data['error'] = pd.to_numeric(data['error'])
    except Exception as e:
        print(f"Error converting data to numeric: {e}")
        return
    
    # 创建图表
    fig, ax = plt.subplots(figsize=(8, 6))
    
    # 绘制误差棒和点线图
    ax.errorbar(data['loading'], data['density'], yerr=data['error'], 
                fmt='o-', linewidth=2, markersize=8, capsize=5, capthick=2)
    
    # 设置坐标轴标签
    ax.set_xlabel('CO$_2$ Loading', fontsize=14)
    ax.set_ylabel('Density (kg/m$^3$)', fontsize=14)
    
    # 设置标题
    ax.set_title('Density vs CO$_2$ Loading', fontsize=16, fontweight='bold')
    
    # 美化网格
    ax.grid(True, linestyle='--', alpha=0.7)
    
    # 调整布局
    plt.tight_layout()
    
    # 保存图像
    plt.savefig('density_vs_loading.png', dpi=300, bbox_inches='tight')
    plt.savefig('density_vs_loading.pdf', bbox_inches='tight')
    
    # 显示图像
    plt.show()
    
    print("Plot created successfully and saved as density_vs_loading.png and density_vs_loading.pdf")

def create_statistical_summary():
    """创建统计摘要"""
    try:
        data = pd.read_csv('density_results.csv')
        
        # 基本统计信息
        print("=" * 50)
        print("DENSITY ANALYSIS SUMMARY")
        print("=" * 50)
        print(f"Number of data points: {len(data)}")
        print(f"Density range: {data['density'].min():.2f} - {data['density'].max():.2f} kg/m³")
        print(f"Average density: {data['density'].mean():.2f} kg/m³")
        print(f"Average error: {data['error'].mean():.4f} kg/m³")
        print("=" * 50)
        
        # 保存详细统计信息
        stats = data.describe()
        stats.to_csv('density_statistics.csv')
        print("Detailed statistics saved to density_statistics.csv")
        
    except Exception as e:
        print(f"Error creating statistical summary: {e}")

if __name__ == "__main__":
    # 绘制主要图表
    plot_density_vs_loading()
    
    # 创建统计摘要
    create_statistical_summary()