import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# 设置 ggplot 风格（无需额外安装）
plt.style.use('ggplot')
plt.rcParams['font.family'] = 'serif'
plt.rcParams['mathtext.fontset'] = 'cm'
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 10

# 读取数据文件
data = []
with open("coordination_results.txt", "r") as f:
    lines = f.readlines()
    
    # 跳过标题行和分隔线
    for line in lines[2:]:
        if line.strip() and not line.startswith('-'):
            parts = line.split('|')
            if len(parts) >= 5:
                loading = float(parts[0].strip())
                volume = float(parts[1].strip())
                particles = float(parts[2].strip())
                first_shell_n = float(parts[3].strip())
                second_shell_n = float(parts[4].strip())
                data.append({
                    "loading": loading,
                    "volume": volume,
                    "particles": particles,
                    "first_shell_n": first_shell_n,
                    "second_shell_n": second_shell_n
                })

# 如果没有数据，打印错误并退出
if not data:
    print("Error: No valid data found in coordination_results.txt")
    exit(1)

# 创建DataFrame
df = pd.DataFrame(data)

# 按loading排序
df = df.sort_values('loading')

# 提取数据
loadings = df['loading'].values
first_shell_ns = df['first_shell_n'].values
second_shell_ns = df['second_shell_n'].values

# 创建图表
plt.figure(figsize=(8, 6))
plt.plot(loadings, first_shell_ns, marker='o', linestyle='-', linewidth=1.5, 
         label=r'First Shell $N$', color='#1f77b4', markersize=6)
plt.plot(loadings, second_shell_ns, marker='s', linestyle='--', linewidth=1.5, 
         label=r'Second Shell $N$', color='#ff7f0e', markersize=6)

# 添加标题和标签
plt.title(r'Coordination Number vs. CO₂ Loading', pad=10)
plt.xlabel(r'CO₂ Loading', labelpad=5)
plt.ylabel(r'Coordination Number ($N$)', labelpad=5)

# 添加网格
plt.grid(True, which='both', linestyle='--', linewidth=0.5, alpha=0.7)

# 设置 x 轴和 y 轴刻度
plt.xticks(loadings)
plt.yticks(np.arange(0, max(second_shell_ns) * 1.2, 0.1))

# 添加图例
plt.legend(loc='best', frameon=True, facecolor='white', edgecolor='black')

# 添加数据点标签
for i, (x, y1, y2) in enumerate(zip(loadings, first_shell_ns, second_shell_ns)):
    plt.text(x, y1 + 0.01, f'{y1:.4f}', ha='center', va='bottom', fontsize=20)
    plt.text(x, y2 - 0.01, f'{y2:.4f}', ha='center', va='top', fontsize=20)

# 调整布局，避免标签重叠
plt.tight_layout()

# 保存图表
plt.savefig("coordination_plot.png", dpi=300, bbox_inches='tight')
plt.savefig("coordination_plot.pdf", bbox_inches='tight')
plt.show()

# 打印数据摘要
print("Data used for plotting:")
print(df[['loading', 'first_shell_n', 'second_shell_n']])