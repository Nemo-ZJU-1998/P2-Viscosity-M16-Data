import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np


# 读取数据
df = pd.read_csv("hbond_results.csv")
loadings = df['Loading']
types = ['COO_NH2', 'Amine_Amine', 'Amine_COO', 'Amine_NH2']
labels = ['COO-NH₂', 'Amine-Amine', 'Amine-COO', 'Amine-NH₂']
colors = ['#4e79a7', '#f28e2c', '#e15759', '#76b7b2']

# 设置绘图样式
sns.set_theme(style="whitegrid")  # 替代 plt.style.use[5,3](@ref)
plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.size': 12,
    'figure.dpi': 300,
    'axes.spines.top': False,
    'axes.spines.right': False
})

# 创建图表
fig, ax = plt.subplots(figsize=(10, 6))
x = np.arange(len(loadings))
bar_width = 0.8  # 加宽柱状图[5,7](@ref)

# 绘制堆叠柱状图（单列对齐）
bottom = np.zeros(len(loadings))
for i, hb_type in enumerate(types):
    values = df[hb_type]
    ax.bar(
        x, values, bar_width, bottom=bottom, 
        color=colors[i], edgecolor='black', label=labels[i]
    )
    # 在柱中标注数值
    for j, val in enumerate(values):
        ax.text(
            x[j], bottom[j] + val/2, f'{val:.1f}', 
            ha='center', va='center', color='white', fontsize=9
        )
    bottom += values

# 绘制总氢键折线图
total_line = ax.plot(
    x, df['Total'], 's-', color='#2ca02c', linewidth=2.5,
    markersize=8, label='Total HBonds'
)

# 添加总氢键数值标签
for i, total in enumerate(df['Total']):
    ax.text(x[i], total + 5, f'{total:.1f}', ha='center', color='#2ca02c')

# 设置图表元素
ax.set_title('Hydrogen Bond Analysis by CO₂ Loading', fontsize=14, pad=15)
ax.set_xlabel('CO₂ Loading', fontsize=12, labelpad=10)
ax.set_ylabel('Number of Hydrogen Bonds', fontsize=12, labelpad=10)
ax.set_xticks(x)
ax.set_xticklabels([f'{l:.2f}' for l in loadings])
ax.set_ylim(0, df['Total'].max() * 1.3)
ax.legend(loc='upper left', frameon=True, ncol=2)

# 添加网格线
ax.yaxis.grid(True, linestyle='--', alpha=0.7)

plt.tight_layout()
plt.savefig('hbond_analysis.png', dpi=300)
plt.show()