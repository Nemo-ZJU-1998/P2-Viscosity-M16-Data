#!/bin/bash
#SBATCH --job-name=rdf_analysis_22
#SBATCH -N 1
#SBATCH --ntasks-per-node=1
#SBATCH -p tyhcnormal
# 创建rdf结果目录
mkdir -p rdf_results

# 定义原子位置参数 - 现在需要指定多个位置
OCOO_POS=8  # AmineCOO分子中需要重命名的氧原子位置
NH2_POS=31   # AmineNH2分子中需要重命名的氢原子位置

# 定义loading值数组
loadings=(0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40)

# 第一步：处理所有loading值，生成RDF文件
for loading in "${loadings[@]}"; do
    # 创建loading目录路径
    loading_dir="gromacs_results/CO2_loading_${loading}"
    
    # 确保目录存在
    if [ ! -d "$loading_dir" ]; then
        echo "Error: Directory $loading_dir does not exist"
        exit 1
    fi
    
    echo "=================================================="
    echo "Processing loading: $loading"
    echo "=================================================="
    
    # 进入目录
    cd "$loading_dir" || { echo "Cannot cd to $loading_dir"; exit 1; }
    
    # 复制modify.py脚本
    cp ../../modify.py .
    
    # 修改GRO文件 - 传递多个位置参数
    echo "Modifying NVT_313.gro..."
    python modify.py "$loading" --OCOO ${OCOO_POS[@]} --NH2 ${NH2_POS[@]}
    
    # 创建索引文件
    echo "Creating index file..."
    echo -e "a OCOO\nname OCOO\na H_NH2\nname H_NH2\nq\n" | \
    mpirun -n 1 gmx_mpi make_ndx -f modified_NVT_313.gro -o index.ndx

    # 检查RDF文件是否已存在
    if [ -f "rdf_${loading}.xvg" ]; then
        echo "RDF file for loading $loading already exists, skipping calculation"
    else
        # 计算RDF
        echo "Calculating RDF..."
        echo -e "5\n6\n" | \
        gmx_mpi rdf -f NVT_313.trr -s NVT_313.tpr -n index.ndx -o "RDF_${loading}.xvg"
    fi
    
    # 复制RDF结果到上级目录
    cp "RDF_${loading}.xvg" ../../rdf_results/
    
    # 返回原始目录
    cd ../..
    echo "Completed processing for loading: $loading"
    echo ""
done

echo "=================================================="
echo "All RDF files generated and saved to rdf_results/"
echo "=================================================="
echo ""

# 第二步：计算配位数
echo "Starting coordination number calculation..."
echo "=================================================="

# 创建结果文件
results_file="coordination_results.txt"
echo "Loading | Volume (nm³) | Particles | First Shell N | Second Shell N" > "$results_file"
echo "--------------------------------------------------" >> "$results_file"

# 遍历所有loading值
for loading in "${loadings[@]}"; do
    # 创建loading目录路径
    loading_dir="gromacs_results/CO2_loading_${loading}"
    
    # 进入目录
    cd "$loading_dir" || { echo "Cannot cd to $loading_dir"; exit 1; }
    
    # 计算粒子数
    y=$(echo "2000 * $loading" | bc)
    x=$(echo "2000 - 2 * $y" | bc)  # EEMPA分子数 = 2000 - 2*Y_COUNT
    
    # 运行freevolume获取盒子体积
    echo "Calculating volume for loading: $loading..."
    mpirun -n 1 gmx_mpi freevolume -f modified_NVT_313.gro -s NVT_313.tpr > freevolume_rdf.log 2>&1
    
    # 从log文件提取体积
    volume=$(grep "Total volume" freevolume_rdf.log | awk '{print $3}')
    
    if [ -z "$volume" ]; then
        echo "Error: Failed to extract volume for loading $loading"
        cd ../..
        continue
    fi
    
    echo "Volume = $volume nm³"
    echo "Total particles (H_NH2 and OCOO atoms) = $total_particles"
    
    # 获取RDF文件路径
    rdf_file="../../rdf_results/RDF_${loading}.xvg"
    
    # 使用Python计算配位数
python3 <<EOF
import numpy as np
from scipy.integrate import trapezoid
from scipy.signal import savgol_filter, argrelmin
import matplotlib.pyplot as plt
import re

# 计算模式切换变量
use_manual_boundaries = True  # True 为手动模式，False 为自动模式（默认）
manual_boundaries = [0.266, 0.401, 0.488, 0.552]  # 手动指定的壳层边界（单位：nm）

# 从 shell 传递变量并转换为浮点数
volume = float("$volume")
y = float("$y")
loading = float("$loading")

print(f"\n{'='*60}\n[计算参数]")
print(f"盒子体积: {volume:.4f} nm³ | 溶质粒子数: {y}")
print(f"数密度 ρ = {y/volume:.6f} particles/nm³")

# 加载 RDF 数据
data = np.loadtxt("$rdf_file", comments=["#", "@"])
r = data[:, 0]  # 距离（单位：nm）
g_r = data[:, 1]  # g(r) 值
print(f"RDF 数据点数量: {len(r)} | 距离范围: {r[0]:.3f}-{r[-1]:.3f} nm")
print(f"g(r) 最大值位置: r={r[np.argmax(g_r)]:.3f} nm | g(r)={np.max(g_r):.2f}")

# 改进的壳层边界检测函数
def detect_shell_boundaries(r, g_r):
    if use_manual_boundaries:
        # 使用手动指定的边界
        boundaries = []
        for b in manual_boundaries:
            if b < r.min() or b > r.max():
                print(f"警告：手动边界 {b} nm 超出范围 [{r.min()}, {r.max()}] nm")
                continue
            idx = np.argmin(np.abs(r - b))
            boundaries.append(idx)
        if len(boundaries) == 0:
            print("错误：没有手动边界在范围内，切换到自动检测")
            return detect_shell_boundaries(r, g_r)  # 递归调用自动检测
        print(f"\n{'='*60}\n[手动壳层边界]")
        for i, idx in enumerate(boundaries):
            print(f"壳层 #{i+1} 边界: r={r[idx]:.3f} nm (索引: {idx})")
        return boundaries
    else:
        # 自动检测：平滑 RDF 并寻找局部最小值
        window_length = 11  # 平滑窗口长度（可调整）
        polyorder = 2  # 多项式阶数（可调整）
        try:
            smoothed_g_r = savgol_filter(g_r, window_length, polyorder)
        except ValueError as e:
            print(f"平滑失败：{e}。请检查 window_length（{window_length}）是否小于数据长度且为奇数。")
            return []
        minima_indices = argrelmin(smoothed_g_r, order=1)[0]
        if len(minima_indices) == 0:
            print("警告：未检测到局部最小值，使用默认边界")
            return [np.argmin(np.abs(r - b)) for b in [0.22, 0.40, 0.60, 0.80]]
        print(f"\n{'='*60}\n[自动壳层边界检测]")
        print(f"检测到 {len(minima_indices)} 个局部最小值")
        for i, idx in enumerate(minima_indices[:4]):
            print(f"壳层 #{i+1} 边界: r={r[idx]:.3f} nm (索引: {idx})")
        return minima_indices.tolist()[:4]  # 最多返回 4 个边界

# 获取壳层边界
shell_boundaries = detect_shell_boundaries(r, g_r)

# 计算每个壳层的积分
shell_integrals = []
shell_ranges = []
r_start = 0
for i, idx in enumerate(shell_boundaries):
    r_end = idx
    shell_range = (r >= r[r_start]) & (r <= r[r_end])
    r_shell = r[shell_range]
    g_r_shell = g_r[shell_range]
    integrand = g_r_shell * r_shell**2
    integral = trapezoid(integrand, r_shell)
    shell_integrals.append(integral)
    shell_ranges.append((r[r_start], r[r_end]))
    print(f"\n{'='*60}\n[壳层 #{i+1} ({r[r_start]:.3f}-{r[r_end]:.3f} nm)]")
    print(f"积分范围点数: {len(r_shell)}")
    print(f"g(r)r²dr 积分值: {integral:.6f}")
    r_start = r_end + 1

# 计算配位数
rho = y / volume
shell_N = [4 * np.pi * rho * integral for integral in shell_integrals]

print(f"\n{'='*60}\n[配位数计算结果]")
for i, (N, (start, end)) in enumerate(zip(shell_N, shell_ranges)):
    print(f"壳层 #{i+1} ({start:.3f}-{end:.3f} nm): {N:.4f}")

# 写入结果文件
with open("../../coordination_results.txt", "a") as f:
    shell_N_str = " | ".join([f"{N:.4f}" for N in shell_N])
    f.write(f"{loading} | {volume:.3f} | {int(y)} | {shell_N_str}\n")

# 绘制 RDF 和壳层边界
plt.figure(figsize=(10, 6))
plt.plot(r, g_r, 'b-', linewidth=2, label='g(r)')
colors = ['red', 'green', 'purple', 'orange']
for i, idx in enumerate(shell_boundaries):
    if i < len(colors):
        plt.axvline(x=r[idx], color=colors[i], linestyle='--', label=f'Shell {i+1} Boundary: {r[idx]:.3f} nm')
    else:
        plt.axvline(x=r[idx], color='gray', linestyle='--')
plt.title(f'RDF with Shell Boundaries (Loading: {loading})', fontsize=14)
plt.xlabel('Distance (nm)', fontsize=12)
plt.ylabel('g(r)', fontsize=12)
plt.grid(True, alpha=0.3)
plt.legend()
plot_file = f"../../rdf_results/rdf_shells_{loading}.png"
plt.savefig(plot_file, dpi=300, bbox_inches='tight')
plt.close()
print(f"RDF with shell boundaries saved to {plot_file}")
EOF


    # 返回原始目录
    cd ../..
    echo ""
done

echo "=================================================="
echo "All calculations completed!"
echo "Results saved in $results_file"
echo "=================================================="

# 格式化输出结果
column -t -s "|" "$results_file"

# 第三步：生成配位数图
echo "Generating coordination number plot..."
python3 <<EOF
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import re
import seaborn as sns


# 设置绘图风格
sns.set(style="whitegrid", font_scale=1.2)
plt.figure(figsize=(8, 6))

# 读取结果文件
data = []
with open("coordination_results.txt", "r") as f:
    lines = f.readlines()
    # 跳过标题行和分隔线
    for line in lines[2:]:
        if line.strip() and not line.startswith('-'):
            # 分割数据行
            parts = line.split('|')
            if len(parts) >= 5:
                loading = float(parts[0].strip())
                volume = float(parts[1].strip())
                particles = int(parts[2].strip())
                first_shell_n = float(parts[3].strip())
                second_shell_n = float(parts[4].strip())
                data.append({
                    "loading": loading,
                    "first_shell_n": first_shell_n,
                    "second_shell_n": second_shell_n
                })

# 如果没有数据，打印错误并退出
if not data:
    print("Error: No valid data found in coordination_results.txt")
    exit(1)

# 创建DataFrame
df = pd.DataFrame(data)

# 按loading排序
df = df.sort_values('loading')

# 提取数据
loadings = df['loading'].values
first_shell_ns = df['first_shell_n'].values
second_shell_ns = df['second_shell_n'].values

# 创建图表
plt.figure(figsize=(8, 6))
plt.plot(loadings, first_shell_ns, marker='o', linestyle='-', linewidth=2, 
         label=r'First Shell', color='#1f77b4', markersize=6)
plt.plot(loadings, second_shell_ns, marker='s', linestyle='--', linewidth=2, 
         label=r'Second Shell', color='#ff7f0e', markersize=6)

# 添加标题和标签
plt.title(r'Coordination Number vs. CO₂ Loading', fontsize=14)
plt.xlabel(r'CO₂ Loading', fontsize=12)
plt.ylabel(r'Coordination Number (N)', fontsize=12)

# 添加网格
plt.grid(True, linestyle='--', alpha=0.7)

# 设置 x 轴
plt.xticks(loadings)

# 根据数据范围动态设置y轴
y_max = max(np.max(first_shell_ns), np.max(second_shell_ns)) * 1.2
plt.ylim(0, y_max)

# 添加图例
plt.legend(loc='best', frameon=True, facecolor='white', edgecolor='black')

# 在数据点上添加标签
for i, (x, y1, y2) in enumerate(zip(loadings, first_shell_ns, second_shell_ns)):
    plt.text(x, y1, f'{y1:.4f}', ha='center', va='bottom', fontsize=12)
    plt.text(x, y2, f'{y2:.4f}', ha='center', va='top', fontsize=12)

# 调整布局
plt.tight_layout()

# 保存图表
plt.savefig("coordination_plot.png", dpi=300, bbox_inches='tight')
plt.savefig("coordination_plot.pdf", bbox_inches='tight')
plt.show()

print("Coordination plot saved as coordination_plot.png and coordination_plot.pdf")
EOF


echo "=================================================="
echo "All calculations completed!"
echo "Results saved in $results_file"
echo "=================================================="

# 格式化输出结果
column -t -s "|" "$results_file"
python plot_coordination.py
cp /work/home/xuwenhao/Viscosity_cal/21_EEMPA/rdf_results/rdf_loading.py rdf_results
cd rdf_results
python rdf_loading.py
cd ..