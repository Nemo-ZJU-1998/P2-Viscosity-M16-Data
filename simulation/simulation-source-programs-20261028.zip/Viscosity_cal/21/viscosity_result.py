import os
import re
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

# 定义担载量范围
loadings = [0.00, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40]

# 初始化存储粘度的列表
viscosities = []

# 创建结果汇总文件
summary_path = './gromacs_results/viscosity_results_summary.txt'
with open(summary_path, 'w') as summary_file:
    summary_file.write("Loading (mol/mol)\tViscosity (cP)\n")
    
    # 遍历每个担载量
    for loading in loadings:
        # 构建文件路径
        file_path = f'./gromacs_results/CO2_loading_{loading:.2f}/regression_results.txt'
        
        # 检查文件是否存在
        if not os.path.exists(file_path):
            print(f"Warning: File not found: {file_path}")
            viscosities.append(np.nan)
            continue
            
        # 读取文件内容
        with open(file_path, 'r') as file:
            content = file.read()
            
        # 使用正则表达式提取Extrapolated viscosity值
        match = re.search(r'Extrapolated viscosity η₀: (\d+\.\d+) cP', content)
        if match:
            viscosity = float(match.group(1))
            viscosities.append(viscosity)
            # 将结果写入汇总文件
            summary_file.write(f"{loading:.2f}\t{viscosity:.4f}\n")
        else:
            print(f"Warning: Could not extract viscosity from {file_path}")
            viscosities.append(np.nan)

# 过滤出有效数据（非NaN值）
valid_loadings = []
valid_viscosities = []
for loading, viscosity in zip(loadings, viscosities):
    if not np.isnan(viscosity):
        valid_loadings.append(loading)
        valid_viscosities.append(viscosity)

# 转换为numpy数组以便计算
valid_loadings = np.array(valid_loadings)
valid_viscosities = np.array(valid_viscosities)

# 执行线性拟合（在半对数坐标上，所以对粘度取对数）
log_viscosities = np.log(valid_viscosities)
slope, intercept, r_value, p_value, std_err = stats.linregress(valid_loadings, log_viscosities)

# 创建拟合线数据
fit_loadings = np.linspace(min(valid_loadings), max(valid_loadings), 100)
fit_log_viscosities = slope * fit_loadings + intercept
fit_viscosities = np.exp(fit_log_viscosities)

# 创建图形
fig, ax = plt.subplots(figsize=(8, 6))

# 绘制散点图
ax.semilogy(valid_loadings, valid_viscosities, 'o', markersize=8, label='Data points')

# 绘制拟合线
ax.semilogy(fit_loadings, fit_viscosities, 'r-', label=f'Linear fit (ln(η) = {intercept:.3f} + {slope:.3f}·Λ)\nR² = {r_value**2:.4f}')

# 设置坐标轴范围
ax.set_xlim(-0.01, 0.42)
ax.set_ylim(1, 400)

# 设置标签和标题
ax.set_xlabel('Loading (mol/mol)')
ax.set_ylabel('Viscosity (cP)')
ax.set_title('Viscosity vs CO2 Loading (semilog plot)')

# 添加图例
ax.legend()

# 添加网格
ax.grid(True, which="both", linestyle='--', alpha=0.5)

# 保存图像
plot_path = './gromacs_results/viscosity_vs_loading.png'
plt.savefig(plot_path, dpi=300, bbox_inches='tight')

# 显示图像
plt.show()

print(f"Data summary saved to: {summary_path}")
print(f"Plot saved to: {plot_path}")
print(f"Linear fit equation: ln(η) = {intercept:.4f} + {slope:.4f}·Λ")
print(f"R² value: {r_value**2:.4f}")