import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl

# ========================
# 美化和字体配置
# ========================
plt.rcParams.update({
    'font.family': 'sans-serif',          # 使用专业字体
    'font.size': 13,                  # 基础字号
    'axes.labelsize': 14,              # 坐标轴标签字号
    'axes.titlesize': 16,              # 标题字号
    'xtick.labelsize': 12,             # X轴刻度字号
    'ytick.labelsize': 12,             # Y轴刻度字号
    'legend.fontsize': 12,             # 图例字号
    'legend.title_fontsize': 13,       # 图例标题字号
    'grid.color': '0.92',              # 网格线颜色
    'grid.linestyle': '--',            # 网格线样式
    'grid.linewidth': 1.2,             # 网格线宽度
    'axes.spines.top': False,          # 隐藏顶部边框
    'axes.spines.right': False         # 隐藏右侧边框
})

# ========================
# 更新文件列表和担载量标签
# ========================
file_list = [
    'RDF_0.05.xvg',
    'RDF_0.10.xvg',
    'RDF_0.15.xvg',
    'RDF_0.20.xvg',
    'RDF_0.25.xvg',
    'RDF_0.30.xvg',
    'RDF_0.35.xvg',
    'RDF_0.40.xvg'
]
loadings = ['0.05', '0.10', '0.15', '0.20', '0.25', '0.30', '0.35', '0.40'] 
colors = plt.cm.viridis(np.linspace(0.15, 0.95, len(loadings)))  # 调整颜色映射范围以适应更多数据

# ========================
# 创建专业图表（调整大小以容纳更多曲线）
# ========================
fig, ax = plt.subplots(figsize=(9, 6.5), dpi=100)

# 循环读取并绘制每个文件
for file, loading, color in zip(file_list, loadings, colors):
    # 读取数据，跳过以@开头的注释行
    data = []
    with open(file, 'r') as f:
        for line in f:
            if not line.startswith(('@', '#')) and line.strip():
                values = line.split()
                if len(values) >= 2:
                    try:
                        r_val = float(values[0])
                        g_val = float(values[1])
                        data.append([r_val, g_val])
                    except ValueError:
                        continue
    
    if not data:
        print(f"警告: 文件 {file} 无有效数据!")
        continue
    
    data = np.array(data)
    r = data[:, 0]  # 第一列：距离 (nm)
    g_r = data[:, 1]  # 第二列：g(r)
    
    # 智能曲线平滑（保留关键特征）
    from scipy.signal import savgol_filter
    if len(g_r) > 30:
        window = min(31, len(g_r))
        window = window if window % 2 == 1 else window - 1  # 确保为奇数
        if window > 3:
            g_r_smoothed = savgol_filter(g_r, window_length=window, polyorder=3)
        else:
            g_r_smoothed = g_r
    else:
        g_r_smoothed = g_r
    
    # 绘制曲线
    ax.plot(r, g_r_smoothed, lw=2.2, alpha=0.95, 
            label=f'Loading: {loading}', color=color,
            marker='', markersize=0)

# ========================
# 图表优化
# ========================
# 设置坐标轴范围
ax.set_xlim(0, 1.2)  # 扩大X轴范围
ax.set_ylim(0, None)  # 自动调整Y轴上限

# 添加专业元素
ax.grid(True, alpha=0.8)
ax.set_xlabel('r (nm)', fontweight='medium', labelpad=8)
ax.set_ylabel('g(r)', fontweight='medium', labelpad=8)
ax.set_title('Radial Distribution Functions at Different Loadings', 
             fontweight='bold', pad=14)

# 图例定位 - 使用两列避免重叠
ax.legend(title='Loadings', loc='upper right', framealpha=0.95, 
          fancybox=True, shadow=False, edgecolor='0.9', 
          borderpad=0.8, handlelength=1.8, ncol=2)

# 美学调整
ax.xaxis.set_minor_locator(mpl.ticker.AutoMinorLocator(4))
ax.yaxis.set_minor_locator(mpl.ticker.AutoMinorLocator(4))
ax.tick_params(which='both', direction='in', top=False, right=False)
ax.tick_params(which='major', length=6, width=1.2)
ax.tick_params(which='minor', length=3, width=1)

# 添加水平基线
ax.axhline(y=1, color='0.4', linestyle=':', alpha=0.7, lw=1.8)

# ========================
# 导出高质量图像
# ========================
plt.tight_layout(pad=2.5)  # 增加内边距以适应图例

# 保存专业格式
plt.savefig('RDF_optimized.png', dpi=300, bbox_inches='tight', pad_inches=0.3)
plt.savefig('RDF_optimized.pdf', dpi=300, bbox_inches='tight', pad_inches=0.3)

plt.show()