import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
import os
import re
from scipy.signal import find_peaks

# ========================
# 美化和字体配置
# ========================
plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.size': 13,
    'axes.labelsize': 14,
    'axes.titlesize': 16,
    'xtick.labelsize': 12,
    'ytick.labelsize': 12,
    'legend.fontsize': 12,
    'legend.title_fontsize': 13,
    'grid.color': '0.92',
    'grid.linestyle': '--',
    'grid.linewidth': 1.2,
    'axes.spines.top': False,
    'axes.spines.right': False
})

# ========================
# 自动获取目录中的所有xvg文件
# ========================
def get_xvg_files(directory="."):
    """获取指定目录中的所有.xvg文件"""
    xvg_files = []
    for file in os.listdir(directory):
        if file.endswith(".xvg"):
            xvg_files.append(os.path.join(directory, file))
    return sorted(xvg_files)  # 按文件名排序

# ========================
# 从文件名提取负载量
# ========================
def extract_loading_from_filename(filename):
    """从文件名中提取负载量信息"""
    match = re.search(r'(\d+\.\d+)', os.path.basename(filename))
    return match.group(1) if match else "unknown"

# ========================
# 读取xvg文件数据
# ========================
def read_xvg_data(file_path):
    """读取.xvg文件数据，跳过注释行"""
    data = []
    with open(file_path, 'r') as f:
        for line in f:
            if not line.startswith(('@', '#')) and line.strip():
                values = line.split()
                if len(values) >= 2:
                    try:
                        r_val = float(values[0])
                        g_val = float(values[1])
                        data.append([r_val, g_val])
                    except ValueError:
                        continue
    return np.array(data) if data else None

# ========================
# 平滑数据
# ========================
def smooth_data(g_r):
    """使用Savitzky-Golay滤波器平滑数据"""
    from scipy.signal import savgol_filter
    if len(g_r) > 30:
        window = min(31, len(g_r))
        window = window if window % 2 == 1 else window - 1
        if window > 3:
            return savgol_filter(g_r, window_length=window, polyorder=3)
    return g_r

# ========================
# 智能坐标轴范围调整
# ========================
def auto_adjust_axes(r, g_r):
    """智能计算坐标轴范围"""
    # x轴范围计算
    # 取数据范围的前90%（排除尾部长距离波动）
    r_valid = r[r < r[int(len(r)*0.9)]]
    x_min = 0
    x_max = max(1.2, min(2.0, r_valid.max() * 1.15))  # 自动扩展15%，但不超过2.0nm
    
    # y轴范围计算
    y_min = min(0, min(g_r) * 1.05)  # 最低点提供5%余量
    # 查找主要峰值
    peaks, _ = find_peaks(g_r, height=max(g_r)*0.1)  # 只考虑高度>10%最高峰的峰值
    if len(peaks) > 0:
        y_max = max(3, max(g_r[peaks]) * 1.25)  # 确保至少到3，并提供25%空间
    else:
        y_max = max(3, max(g_r) * 1.25)
    
    # 确保合理的y轴最大值
    if y_max > 200 and max(g_r) < 100: 
        y_max = max(g_r) * 1.3  # 避免过高设置
    elif y_max > 500: 
        y_max = max(g_r) * 1.5  # 特殊情况处理
    
    return (x_min, x_max), (y_min, y_max)

# ========================
# 创建专业图表（带自动调整）
# ========================
def create_rdf_plot(r=None, g_r=None):
    """创建并配置RDF图表的基本框架"""
    fig, ax = plt.subplots(figsize=(8, 5.5), dpi=100)
    
    # 智能坐标轴设置
    if r is not None and g_r is not None:
        x_lims, y_lims = auto_adjust_axes(r, g_r)
        ax.set_xlim(*x_lims)
        ax.set_ylim(*y_lims)
    else:
        # 默认值（当没有数据传入时）
        ax.set_xlim(0, 1.5)
        ax.set_ylim(0, 10)
    
    # 添加专业元素
    ax.grid(True, alpha=0.8)
    ax.set_xlabel('r (nm)', fontweight='medium', labelpad=8)
    ax.set_ylabel('g(r)', fontweight='medium', labelpad=8)
    
    # 美学调整
    ax.xaxis.set_minor_locator(mpl.ticker.AutoMinorLocator(4))
    ax.yaxis.set_minor_locator(mpl.ticker.AutoMinorLocator(4))
    ax.tick_params(which='both', direction='in', top=False, right=False)
    ax.tick_params(which='major', length=6, width=1.2)
    ax.tick_params(which='minor', length=3, width=1)
    
    # 添加水平基线
    ax.axhline(y=1, color='0.4', linestyle=':', alpha=0.7, lw=1.8)
    
    return fig, ax

# ========================
# 绘制单个文件的RDF图（带自动调整）
# ========================
def plot_single_rdf(file_path, output_dir="single_plots"):
    """为单个.xvg文件创建专门的RDF图"""
    # 提取负载量
    loading = extract_loading_from_filename(file_path)
    
    # 读取数据
    data = read_xvg_data(file_path)
    if data is None:
        print(f"警告: 文件 {file_path} 无有效数据!")
        return
    
    r = data[:, 0]
    g_r = data[:, 1]
    g_r_smoothed = smooth_data(g_r)
    
    # 创建图表（带自动调整）
    fig, ax = create_rdf_plot(r, g_r)
    
    # 添加数据
    ax.plot(r, g_r_smoothed, lw=2.5, color='#1f77b4', alpha=0.95, 
            label=f'Loading: {loading}', marker='', markersize=0)
    
    # 自定义标题
    ax.set_title(f'Radial Distribution Function (Loading: {loading})', 
                 fontweight='bold', pad=14)
    
    # 区域强调（0.15-0.3 nm区间）
    if max(r) > 0.15:
        ax.axvspan(0.15, 0.30, facecolor='0.93', edgecolor='none', zorder=-1)
        ax.text(0.225, ax.get_ylim()[0] + (ax.get_ylim()[1] - ax.get_ylim()[0]) * 0.01, 
                'First Solvation Shell', ha='center', va='bottom', 
                fontstyle='italic', color='0.35', fontsize=10)
    
    # 标注特征峰值
    peaks, _ = find_peaks(g_r, height=max(g_r)*0.1)  # 识别显著峰
    if len(peaks) > 0:
        # 只标注前2个显著峰
        for peak_idx in peaks[:2]:
            ax.plot(r[peak_idx], g_r[peak_idx], 'o', color='white', ms=10, alpha=0.8)
            ax.plot(r[peak_idx], g_r[peak_idx], 'o', color='#1f77b4', ms=8)
            
            # 智能标注位置（避免重叠）
            va = 'bottom' if g_r[peak_idx] < max(g_r)*0.7 else 'top'
            ha = 'left' if peak_idx < len(r)//2 else 'right'
            text_x = r[peak_idx] + 0.05 if ha == 'left' else r[peak_idx] - 0.05
            text_y = g_r[peak_idx] * 1.1 if va == 'bottom' else g_r[peak_idx] * 0.9
            
            ax.annotate(f'({r[peak_idx]:.2f} nm, {g_r[peak_idx]:.1f})',
                       xy=(r[peak_idx], g_r[peak_idx]),
                       xytext=(text_x, text_y),
                       arrowprops=dict(arrowstyle='->', lw=1.5, color='#555555'),
                       ha=ha, va=va,
                       bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#aaaaaa", lw=1, alpha=0.8))
    
    # 保存图像
    os.makedirs(output_dir, exist_ok=True)
    filename = os.path.splitext(os.path.basename(file_path))[0]
    output_path = os.path.join(output_dir, f"{filename}_plot.png")
    plt.tight_layout(pad=2.0)
    plt.savefig(output_path, dpi=300, bbox_inches='tight', pad_inches=0.2)
    plt.close()
    print(f"已保存单个图像: {output_path}")

# ========================
# 绘制所有文件的综合RDF图（带智能调整）
# ========================
def plot_composite_rdf(file_list, output_file="RDF_composite.png"):
    """创建包含所有文件的综合RDF图"""
    # 获取所有负载量
    loadings = [extract_loading_from_filename(file) for file in file_list]
    colors = plt.cm.viridis(np.linspace(0.2, 0.9, len(loadings)))
    
    # 预先收集所有数据确定全局范围
    all_r = []
    all_g_r = []
    data_dict = {}
    
    for file, loading in zip(file_list, loadings):
        data = read_xvg_data(file)
        if data is None:
            continue
        r = data[:, 0]
        g_r = data[:, 1]
        data_dict[loading] = (r, g_r)
        all_r.append(r)
        all_g_r.append(g_r)
    
    if not data_dict:
        print("错误: 没有有效数据可绘制!")
        return
    
    # 计算全局坐标轴范围
    all_r_flat = np.concatenate(all_r)
    all_g_flat = np.concatenate(all_g_r)
    x_lims, y_lims = auto_adjust_axes(all_r_flat, all_g_flat)
    
    # 创建图表
    fig, ax = create_rdf_plot()
    ax.set_xlim(*x_lims)
    ax.set_ylim(*y_lims)
    ax.set_title('Radial Distribution Functions at Different Loadings', 
                 fontweight='bold', pad=14)
    
    # 循环处理每个文件
    for (r, g_r), loading, color in zip(data_dict.values(), loadings, colors):
        g_r_smoothed = smooth_data(g_r)
        
        # 绘制曲线
        line = ax.plot(r, g_r_smoothed, lw=2.2, alpha=0.95, 
                       label=f'Loading: {loading}', color=color, 
                       marker='', markersize=0)
        
        # 标注特征峰值
        peaks, _ = find_peaks(g_r, height=max(g_r)*0.1)
        if len(peaks) > 0 and r[peaks[0]] < 0.4:  # 只标注第一个主要峰
            peak_idx = peaks[0]
            ax.plot(r[peak_idx], g_r[peak_idx], 'o', color='white', ms=8, alpha=0.8)
            ax.plot(r[peak_idx], g_r[peak_idx], 'o', color=color, ms=6)
    
    # 添加图例
    ax.legend(title='Loadings', loc='best', framealpha=0.95, 
              fancybox=True, shadow=False, edgecolor='0.9', 
              borderpad=0.8, handlelength=1.8)
    
    # 区域强调（0.15-0.3 nm区间）
    if x_lims[1] > 0.15:
        ax.axvspan(0.15, 0.30, facecolor='0.93', edgecolor='none', zorder=-1)
        ax.text(0.225, y_lims[0] + (y_lims[1] - y_lims[0]) * 0.01, 
                'First Solvation Shell', ha='center', va='bottom', 
                fontstyle='italic', color='0.35', fontsize=10)
    
    # 保存图像
    plt.tight_layout(pad=2.0)
    plt.savefig(output_file, dpi=300, bbox_inches='tight', pad_inches=0.2)
    plt.savefig('RDF_composite.pdf', dpi=300, bbox_inches='tight', pad_inches=0.2)
    print(f"已保存综合图像: {output_file}")
    plt.show()

# ========================
# 主程序
# ========================
if __name__ == "__main__":
    # 获取当前目录下所有.xvg文件
    file_list = get_xvg_files()
    
    if not file_list:
        print("找不到任何.xvg文件！请将文件放在当前目录中。")
        exit()
    
    print(f"找到 {len(file_list)} 个.xvg文件:")
    for i, file in enumerate(file_list, 1):
        print(f"{i}. {file}")
    
    # 为每个文件单独绘制图像（带智能坐标轴）
    print("\n为每个文件生成单独图像（带智能坐标轴调整）...")
    for file in file_list:
        plot_single_rdf(file)
    
    # 绘制综合图像（带全局智能坐标轴）
    print("\n生成综合图像（带全局坐标轴优化）...")
    plot_composite_rdf(file_list)

    print("\n所有处理完成！")