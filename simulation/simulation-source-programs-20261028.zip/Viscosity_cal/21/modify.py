#!/usr/bin/env python3
import sys
import argparse
import logging
import re
import pdb
from datetime import datetime

# 配置日志系统
def setup_logger(loading):
    log_file = f"modify_{str(loading).replace('.', '_')}.log"
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s [%(levelname)s] %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(sys.stdout)
        ]
    )
    return logging.getLogger()

# 核心文件处理函数
def process_gro_file(args, logger):
    # 动态生成输出文件名
    output_file = args.output or f"modified_NVT_313.gro"
    
    # 新计算逻辑
    Y_COUNT = round(2000 * args.loading)
    X_COUNT = 2000 - 2 * Y_COUNT  # 计算自担载量
    
    logger.info(f"Processing loading={args.loading}:")
    logger.info(f"  FRE molecules: {X_COUNT}")
    logger.info(f"  COO molecules: {Y_COUNT}")
    logger.info(f"  NHH molecules: {Y_COUNT}")
    
    # 初始化计数器
    modified_atoms = {"OCOO": 0, "H_NH2": 0}
    residue_counter = {}
    residue_types = {}  # 记录残基类型
    error_count = 0
    total_lines = 0
    target_molecules = set()
    molecule_ids = set()

    try:
        with open(args.input, 'r') as f:
            lines = f.readlines()
        
        # 处理文件内容
        header = lines[0]
        total_atoms_line = lines[1]
        atom_lines = lines[2:-1]
        box_line = lines[-1]
        
        # 获取原子总数
        try:
            total_atoms = int(total_atoms_line.strip())
            logger.info(f"GRO file contains {total_atoms} atoms")
        except:
            total_atoms = len(atom_lines)
            logger.warning(f"Failed to parse atom count, using line count: {total_atoms}")

        output = [header, total_atoms_line]

        # 先遍历一遍识别分子ID
        current_mol_id = None
        
        for i, line in enumerate(atom_lines):
            if not line.strip():
                continue
            
            # 解析固定列宽
            residue_number = line[0:5].strip()
            residue_name = line[5:10].strip()
            
            mol_id = int(residue_number)
            molecule_ids.add(mol_id)

        # 排序分子ID
        sorted_molecule_ids = sorted(molecule_ids)
        
        # 分配新的分子类型
        for i, mol_id in enumerate(sorted_molecule_ids):
            if i < X_COUNT:
                residue_types[mol_id] = "FRE"    # 前X_COUNT个分子为FRE
            elif i < X_COUNT + Y_COUNT:
                residue_types[mol_id] = "COO"     # 接下来Y_COUNT个分子为COO
            else:
                residue_types[mol_id] = "NHH"     # 最后Y_COUNT个分子为NHH
        
        logger.info(f"Assigned molecule types:")
        logger.info(f"  FRE: molecules {sorted_molecule_ids[0]}-{sorted_molecule_ids[X_COUNT-1]}")
        logger.info(f"  COO: molecules {sorted_molecule_ids[X_COUNT]}-{sorted_molecule_ids[X_COUNT+Y_COUNT-1]}")
        logger.info(f"  NHH: molecules {sorted_molecule_ids[X_COUNT+Y_COUNT]}-{sorted_molecule_ids[-1]}")
        
        # 主处理循环
        current_mol_id = None
        residue_atom_count = 0
        
        for i, line in enumerate(atom_lines):
            total_lines += 1
            if not line.strip():
                continue
            
            try:
                # 解析固定列宽
                residue_number = line[0:5].strip()
                residue_name = line[5:10].strip()
                atom_name = line[10:15].strip()
                atom_global_num = line[15:20].strip()
                
                # 调试断点
                if args.debug_line and i+3 == args.debug_line:
                    logger.warning(f"⚠️ DEBUG TRIGGERED AT LINE {i+3}")
                    pdb.set_trace()
                
                mol_id = int(residue_number)
                new_atom_name = atom_name
                
                # 检查是否是新分子
                if residue_number != current_mol_id:
                    current_mol_id = residue_number
                    residue_atom_count = 0
                
                # 增加分子内原子计数
                residue_atom_count += 1
                
                # 获取分子类型
                mol_type = residue_types.get(mol_id, residue_name)
                
                # 处理COO分子的氧原子
                if mol_type == "COO":  # 原AmineCOO改为COO
                    # 检查是否在指定的氧原子位置
                    if residue_atom_count in args.OCOO:
                        if re.match(r'^O\d+[A-Z]?$', atom_name):
                            new_atom_name = "OCOO".ljust(5)
                            modified_atoms["OCOO"] += 1
                            logger.debug(f"Renamed {atom_name} → OCOO at mol#{mol_id} atom#{residue_atom_count}")
                
                # 处理NHH分子的氢原子
                elif mol_type == "NHH":  # 原AmineNH2改为NHH
                    # 检查是否在指定的氢原子位置
                    if residue_atom_count in args.NH2:
                        if re.match(r'^H\d+[A-Z]?$', atom_name):
                            new_atom_name = "H_NH2".ljust(5)
                            modified_atoms["H_NH2"] += 1
                            logger.debug(f"Renamed {atom_name} → H_NH2 at mol#{mol_id} atom#{residue_atom_count}")

                # 重建行数据
                new_line = (
                    f"{residue_number:>5}"
                    f"{mol_type:<5}"  # 使用分配的类型覆盖原始残基名称
                    f"{new_atom_name:<5}"
                    f"{atom_global_num:>5}"
                    + line[20:]
                )
                output.append(new_line)
                
            except Exception as e:
                error_count += 1
                logger.error(f"🚨 LINE {i+3} ERROR: {str(e)}")
                logger.debug(f"Problematic line: {line.strip()}")
                output.append(line)  # 保留原始行

        output.append(box_line)
        
        # 写入新文件
        with open(output_file, 'w') as f:
            f.writelines(output)
            
        # 更新原子总数行（如果需要）
        new_total_atoms = len(atom_lines)
        updated_total_atoms = True
        
        return output_file, modified_atoms, error_count, len(target_molecules), total_lines, updated_total_atoms
        
    except Exception as e:
        logger.exception(f"🛑 CRITICAL ERROR: {str(e)}")
        sys.exit(1)

# 主函数
def main():
    parser = argparse.ArgumentParser(description='Modified GRO file processor with new molecule types')
    parser.add_argument('loading', type=float, help='Loading value (0.00-0.40)')
    parser.add_argument('--OCOO', type=int, nargs='+', required=True, help='Atom positions for OCOO renaming in COO molecules')
    parser.add_argument('--NH2', type=int, nargs='+', required=True, help='Atom positions for H_NH2 renaming in NHH molecules')
    parser.add_argument('-i', '--input', default='NVT_313.gro', help='Input GRO filename')
    parser.add_argument('-o', '--output', help='Output GRO filename')
    parser.add_argument('--debug', action='store_true', help='Enable debug logging level')
    parser.add_argument('--debug-line', type=int, help='Set breakpoint at specific line number')
    args = parser.parse_args()

    # 初始化日志系统
    logger = setup_logger(args.loading)
    if args.debug:
        logger.setLevel(logging.DEBUG)
    logger.info(f"🚀 Starting GRO modification at {datetime.now()}")
    logger.info(f"Params: loading={args.loading}")
    logger.info(f"  OCOO positions: {args.OCOO}")
    logger.info(f"  NH2 positions: {args.NH2}")

    # 处理文件
    result = process_gro_file(args, logger)
    if result:
        output_file, modified_atoms, error_count, target_molecules, total_lines, updated_total_atoms = result
    
        # 最终报告
        total_modified = modified_atoms["OCOO"] + modified_atoms["H_NH2"]
        logger.info("="*60)
        logger.info("🏁 PROCESSING REPORT")
        logger.info(f"  COO molecules processed: {target_molecules}")
        logger.info(f"  NHH molecules processed: {target_molecules}")
        logger.info(f"  Total lines processed: {total_lines}")
        logger.info(f"  O → OCOO: {modified_atoms['OCOO']} atoms")
        logger.info(f"  H → H_NH2: {modified_atoms['H_NH2']} atoms")
        logger.info(f"  Total modified: {total_modified} atoms")
        logger.info(f"  Errors encountered: {error_count}")
        logger.info(f"  Output file: {output_file}")
        if updated_total_atoms:
            logger.info("  Note: Atom count line was updated")
        logger.info("="*60)

if __name__ == "__main__":
    main()