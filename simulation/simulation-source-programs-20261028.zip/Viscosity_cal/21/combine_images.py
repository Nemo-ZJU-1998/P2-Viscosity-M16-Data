from PIL import Image, ImageDraw, ImageFont
import os
import glob

def create_nine_grid():
    # 设置基本参数
    base_dir = "./gromacs_results"
    image_name = "acceleration_vs_viscosity.png"
    loadings = [f"{i*0.05:.2f}" for i in range(9)]  # 0.00到0.40，步长0.05
    
    # 收集所有图片路径
    image_paths = []
    for loading in loadings:
        folder = f"CO2_loading_{loading}"
        path = os.path.join(base_dir, folder, image_name)
        if os.path.exists(path):
            image_paths.append(path)
    
    if len(image_paths) != 9:
        print(f"错误：需要9张图片，但只找到{len(image_paths)}张")
        return
    
    # 打开所有图片并获取尺寸
    images = [Image.open(path) for path in image_paths]
    widths, heights = zip(*(img.size for img in images))
    
    # 计算九宫格布局
    grid_width = max(widths) * 3
    grid_height = max(heights) * 3
    new_image = Image.new('RGB', (grid_width, grid_height + 100), (255, 255, 255))
    draw = ImageDraw.Draw(new_image)
    
    # 尝试加载字体
    try:
        font = ImageFont.truetype("arial.ttf", 20)
    except:
        font = ImageFont.load_default()
        print("警告：使用默认字体，建议安装Arial字体以获得更好效果")
    
    # 排列图片并添加标注
    for i, (img, loading) in enumerate(zip(images, loadings)):
        row = i // 3
        col = i % 3
        x_offset = col * max(widths)
        y_offset = row * max(heights)
        
        # 粘贴图片
        new_image.paste(img, (x_offset, y_offset))
        
        # 添加标注
        text = f"CO₂ loading: {loading}"
        text_width = draw.textlength(text, font=font)
        text_x = x_offset + (max(widths) - text_width) // 2
        text_y = y_offset + max(heights) + 10
        draw.text((text_x, text_y), text, fill="black", font=font)
    
    # 保存结果
    output_path = os.path.join(base_dir, "combined_nine_grid.png")
    new_image.save(output_path)
    print(f"九宫格图片已保存至: {output_path}")
    return output_path

if __name__ == "__main__":
    result = create_nine_grid()
    if result:
        print("操作成功完成！")