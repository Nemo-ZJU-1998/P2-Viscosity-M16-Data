# extract_hbonds.py
# 该脚本用于从日志文件中提取氢键的数目
import os
import re

def extract_average_hbonds(log_file):
    """从日志文件中提取平均氢键数量"""
    pattern = r"Average number of hbonds per timeframe\s+([\d.]+)"
    try:
        with open(log_file, 'r') as f:
            for line in f:
                match = re.search(pattern, line)
                if match:
                    return float(match.group(1))
    except FileNotFoundError:
        return None
    return None

# 主处理逻辑
loadings = [0.00, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40]
results = []

for loading in loadings:
    dir_path = f"gromacs_results/CO2_loading_{loading:.2f}"
    entry = {"loading": loading}
    
    # 提取五种氢键类型的平均值
    types = ["COO_NH2", "Amine_Amine", "Amine_COO", "Amine_NH2", "Total"]
    for hb_type in types:
        log_file = f"{dir_path}/{hb_type}_hbond.log"
        entry[hb_type] = extract_average_hbonds(log_file)
    
    results.append(entry)

# 输出CSV文件
with open("hbond_results.csv", "w") as f:
    f.write("Loading,COO_NH2,Amine_Amine,Amine_COO,Amine_NH2,Total\n")
    for res in results:
        f.write(f"{res['loading']},{res['COO_NH2']},{res['Amine_Amine']},")
        f.write(f"{res['Amine_COO']},{res['Amine_NH2']},{res['Total']}\n")

print("氢键数据已保存到 hbond_results.csv")