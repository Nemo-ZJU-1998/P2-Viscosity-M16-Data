import os
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import glob

print("开始数据分析...")

# 配置
base_dir = os.getcwd()
loadings = [0.00, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40]
energy_terms = {
    "Potential": "energy_potential",
    "Coulomb(SR)": "energy_coulomb_sr",
    "LJ(SR)": "energy_lj_sr",
    "Coul.-recip.": "energy_coulomb_recip",
    "Disper.-corr.": "energy_dispersion",
    "Kinetic": "energy_kinetic"
}

print(f"基础目录: {base_dir}")
print(f"分析的担载量: {loadings}")

# 存储所有数据
all_data = []
successful_loadings = []

for loading in loadings:
    loading_str = f"{loading:.2f}"
    dir_path = os.path.join(base_dir, "gromacs_results", f"CO2_loading_{loading_str}")
    energy_data = {}
    
    print(f"\n处理担载量: {loading_str}")
    print(f"目录路径: {dir_path}")
    
    if not os.path.exists(dir_path):
        print(f"警告: 目录不存在 - {dir_path}")
        continue
    
    # 检查目录内容
    print(f"目录内容: {os.listdir(dir_path)}")
    
    # 读取能量数据
    for name, file_prefix in energy_terms.items():
        file_name = f"{file_prefix}.xvg"
        file_path = os.path.join(dir_path, file_name)
        print(f"检查文件: {file_path}")
        
        if os.path.exists(file_path):
            try:
                # 读取文件并跳过注释行
                valid_lines = []
                with open(file_path, 'r') as f:
                    for line in f:
                        if not line.startswith(('#', '@')) and line.strip():
                            valid_lines.append(line)
                
                if not valid_lines:
                    print(f"文件为空: {file_path}")
                    continue
                
                # 转换为数值数组
                data = np.genfromtxt(valid_lines)
                
                # 检查数据格式
                if data.size == 0:
                    print(f"无有效数据: {file_path}")
                    continue
                if data.ndim == 1:
                    data = data.reshape(-1, 1)
                
                # 处理不同列数的数据
                if data.shape[1] >= 2:
                    times = data[:, 0]
                    values = data[:, 1]
                else:
                    print(f"数据列数不足: {file_path} (shape: {data.shape})")
                    continue
                
                energy_data[name] = {
                    "time": times,
                    "values": values,
                    "mean": np.mean(values),
                    "std": np.std(values)
                }
                print(f"已加载 {name}: {len(values)} 个数据点")
                
            except Exception as e:
                print(f"读取错误 {file_path}: {str(e)}")
        else:
            print(f"文件不存在: {file_path}")
    
    # 添加到总数据
    if energy_data:
        all_data.append({
            "loading": loading,
            "energies": energy_data
        })
        successful_loadings.append(loading)
        print(f"成功加载担载量 {loading_str} 的数据")
    else:
        print(f"警告: 担载量 {loading_str} 无有效能量数据")

# 如果没有数据，退出
if not all_data:
    print("错误: 无有效数据可分析")
    exit()

print(f"\n成功加载的担载量: {successful_loadings}")

# 1. 绘制单个担载量的能量随时间变化
for data in all_data:
    loading = data["loading"]
    loading_str = f"{loading:.2f}"
    plt.figure(figsize=(14, 8))
    
    # 绘制能量项
    for term, values in data["energies"].items():
        plt.plot(values["time"], values["values"], label=term)
    
    plt.title(f"CO2 Loading {loading_str}: Energy vs Time", fontsize=16)
    plt.xlabel("Time (ps)", fontsize=14)
    plt.ylabel("Energy (kJ/mol)", fontsize=14)
    plt.legend(fontsize=12)
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    
    output_file = f"./energy/energy_time_{loading_str}.png"
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"已保存时间图: {output_file}")

# 2. 绘制能量随担载量的变化
plt.figure(figsize=(16, 12))

# 创建子图布局
ax1 = plt.subplot2grid((3, 2), (0, 0), colspan=2)
ax2 = plt.subplot2grid((3, 2), (1, 0))
ax3 = plt.subplot2grid((3, 2), (1, 1))
ax4 = plt.subplot2grid((3, 2), (2, 0), colspan=2)

# 提取平均值数据
mean_data = []
for data in all_data:
    row = {"Loading": data["loading"]}
    for term in data["energies"].keys():
        row[term] = data["energies"][term]["mean"]
    mean_data.append(row)

df = pd.DataFrame(mean_data)
print("\n能量摘要数据:")
print(df)

# 总势能
if "Potential" in df.columns:
    ax1.plot(df["Loading"], df["Potential"], 'ko-', label="Potential Energy", markersize=8, linewidth=2)
    ax1.set_title("Total Potential Energy", fontsize=16)

# 库伦相互作用
coulomb_data = False
if "Coulomb(SR)" in df.columns and "Coul.-recip." in df.columns:
    df["Total Coulomb"] = df["Coulomb(SR)"] + df["Coul.-recip."]
    ax2.plot(df["Loading"], df["Total Coulomb"], 'bo-', label="Total Coulomb", markersize=8)
    ax2.set_title("Coulomb Interactions", fontsize=14)
    coulomb_data = True

# 范德华相互作用
vdw_data = False
if "LJ(SR)" in df.columns and "Disper.-corr." in df.columns:
    df["Total vdW"] = df["LJ(SR)"] + df["Disper.-corr."]
    ax3.plot(df["Loading"], df["Total vdW"], 'ro-', label="Total vdW", markersize=8)
    ax3.set_title("van der Waals Interactions", fontsize=14)
    vdw_data = True

# 能量比例分析
if coulomb_data and vdw_data:
    df["Coulomb/vdW Ratio"] = df["Total Coulomb"] / df["Total vdW"].abs()
    ax4.plot(df["Loading"], df["Coulomb/vdW Ratio"], 'go--', markersize=8, linewidth=2)
    ax4.set_title("Coulomb to van der Waals Energy Ratio", fontsize=16)

# 设置通用标签
for ax in [ax1, ax2, ax3, ax4]:
    ax.set_xlabel("CO2 Loading", fontsize=12)
    ax.grid(True)

ax1.set_ylabel("Energy (kJ/mol)", fontsize=14)
ax2.set_ylabel("Energy (kJ/mol)", fontsize=12)
ax3.set_ylabel("Energy (kJ/mol)", fontsize=12)
ax4.set_ylabel("Ratio", fontsize=14)

ax1.legend(fontsize=12)

plt.tight_layout()
output_file = f"./energy/energy_vs_loading.png"
plt.savefig(output_file, dpi=300, bbox_inches='tight')
plt.close()
print(f"已保存担载量变化图: {output_file}")

# 3. 保存数据为CSV
if not df.empty:
    csv_file = f"./energy/energy_summary.csv"
    df.to_csv(csv_file, index=False)
    print(f"已保存数据摘要: {csv_file}")

# 4. 验证总能量
if "Potential" in df.columns:
    calculated_potential = 0
    components = []
    
    if "LJ(SR)" in df.columns:
        calculated_potential += df["LJ(SR)"]
        components.append("LJ(SR)")
    if "Disper.-corr." in df.columns:
        calculated_potential += df["Disper.-corr."]
        components.append("Disper.-corr.")
    if "Coulomb(SR)" in df.columns:
        calculated_potential += df["Coulomb(SR)"]
        components.append("Coulomb(SR)")
    if "Coul.-recip." in df.columns:
        calculated_potential += df["Coul.-recip."]
        components.append("Coul.-recip.")
    
    if components:
        df["Calculated Potential"] = calculated_potential
        df["Potential Diff"] = df["Potential"] - df["Calculated Potential"]
        
        print("\n验证总势能一致性:")
        print(df[["Loading", "Potential", "Calculated Potential", "Potential Diff"]])
        
        # 绘制差异图
        plt.figure(figsize=(10, 6))
        plt.bar(df["Loading"].astype(str), df["Potential Diff"], color='purple')
        plt.title("Potential Energy Consistency Check", fontsize=16)
        plt.xlabel("CO2 Loading", fontsize=14)
        plt.ylabel("Difference (kJ/mol)", fontsize=14)
        plt.grid(True, axis='y', alpha=0.3)
        plt.tight_layout()
        
        output_file = "./energy/potential_consistency.png"
        plt.savefig(output_file, dpi=300)
        plt.close()
        print(f"已保存能量一致性图: {output_file}")

print("数据分析完成!")
