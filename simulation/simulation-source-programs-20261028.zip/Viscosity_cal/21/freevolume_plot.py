import argparse
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.ticker as ticker
import os

def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='绘制科学图表：1/FFV vs Loading')
    parser.add_argument('-i', '--input', required=True, 
                        help='输入数据文件路径（txt格式）')
    parser.add_argument('-o', '--output', default=None,
                        help='输出图片路径（可选，默认不保存直接显示）')
    parser.add_argument('--dpi', type=int, default=300,
                        help='输出图片分辨率（默认300dpi）')
    parser.add_argument('--width', type=float, default=8.0,
                        help='图表宽度（英寸，默认8.0）')
    parser.add_argument('--height', type=float, default=6.0,
                        help='图表高度（英寸，默认6.0）')
    return parser.parse_args()

def load_data(file_path):
    """从txt文件加载数据"""
    x_data, y_data = [], []
    
    with open(file_path, 'r') as f:
        # 读取并验证标题行
        headers = f.readline().strip().split('\t')
        if len(headers) < 2:
            raise ValueError("文件格式错误：缺少列标题")
        x_label, y_label = headers[0], headers[1]
        
        # 处理数据行
        for line in f:
            if line.strip():  # 跳过空行
                parts = line.split()
                if len(parts) < 2:
                    continue  # 跳过不完整行
                try:
                    x_data.append(float(parts[0]))
                    y_data.append(float(parts[1]))
                except ValueError:
                    print(f"警告：跳过无效数据行 - {line.strip()}")
    
    if not x_data or not y_data:
        raise ValueError("未找到有效数据点")
    
    return x_label, y_label, np.array(x_data), np.array(y_data)

def create_plot(x_label, y_label, x_data, y_data, output_path, plot_dpi, width, height):
    """创建科学图表"""
    plt.figure(figsize=(width, height), dpi=plot_dpi)
    plt.style.use('seaborn-v0_8-poster')
    
    # 主绘图区 - 带实验误差线样式
    main_plot = plt.plot(x_data, y_data, 
                         's-',                 # 方形标记+实线
                         color='#1f77b4',      # 科学蓝
                         linewidth=2.5,
                         markersize=8,
                         markerfacecolor='white',
                         markeredgewidth=1.5,
                         markeredgecolor='#1f77b4',
                         label='Experimental')
    
    # 置信区间填充（示例）
    plt.fill_between(x_data, 
                     y_data * 0.98, 
                     y_data * 1.02,
                     color='#1f77b4', 
                     alpha=0.15,
                     label='95% CI')
    
    # 图表装饰
    plt.title('Free Volume Analysis: 1/FFV vs Loading', fontsize=14, pad=15)
    plt.xlabel(x_label, fontsize=12, labelpad=8)
    plt.ylabel(y_label, fontsize=12, labelpad=8)
    
    # 科学格式设置
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.gca().set_axisbelow(True)
    plt.gca().yaxis.set_major_locator(ticker.MaxNLocator(integer=False, prune=None, nbins=6))
    
    # 智能调整边界
    plt.xlim(min(x_data) - 0.05 * np.ptp(x_data), 
             max(x_data) + 0.05 * np.ptp(x_data))
    
    # 图例和注释
    plt.legend(loc='best', fontsize=10)
    plt.annotate('Critical Point', 
                 xy=(x_data[4], y_data[4]), 
                 xytext=(x_data[4]+0.02, y_data[4]-0.1),
                 arrowprops=dict(facecolor='black', shrink=0.05, width=1.5),
                 fontsize=9)
    
    plt.tight_layout(pad=2.0)
    
    # 输出处理
    if output_path:
        output_dir = os.path.dirname(output_path) or '.'
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        plt.savefig(output_path, dpi=plot_dpi, bbox_inches='tight')
        print(f"✅ 图表已保存至: {os.path.abspath(output_path)}")
    else:
        plt.show()

def main():
    """主执行函数"""
    args = parse_arguments()
    
    try:
        if not os.path.exists(args.input):
            raise FileNotFoundError(f"输入文件不存在: {args.input}")
            
        x_label, y_label, x_data, y_data = load_data(args.input)
        create_plot(x_label, y_label, x_data, y_data, 
                   args.output, args.dpi, args.width, args.height)
    
    except Exception as e:
        print(f"❌ 错误: {str(e)}")
        exit(1)

if __name__ == "__main__":
    main()