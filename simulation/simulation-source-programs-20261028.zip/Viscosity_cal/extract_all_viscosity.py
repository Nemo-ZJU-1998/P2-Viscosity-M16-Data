#!/usr/bin/env python3
"""
批量提取所有吸收剂文件夹的粘度汇总数据
从 gromacs_results/viscosity_results_summary.txt 中提取
并生成一个综合 Excel 文件
"""
import os
import re
import glob
from pathlib import Path
from collections import defaultdict

# ---------- 路径 ----------
BASE_DIR = Path(r"D:\xuwenhao\Viscosity_cal")

# ---------- 已知文件夹编号 → 吸收剂名称映射 (从论文数据汇总.xlsx提取) ----------
FOLDER_NAME_MAP = {
    # 叔胺-仲胺-醚基类
    "21": "EEMPA",
    "22": "IBMPA",
    "23": "EEMPPA",
    "24": "EEDIPEDA",
    "25": "EEDEDA",
    "26": "EEMEDA",
    "27": "IBDIPEDA",
    # 烷醇胍基类
    "28": "IPADM2BOL",
    "29": "IPATFMM2BOL",
    "30": "IPADM3BOL",
    "31": "MEIPADM2BOL",
    # 特殊命名文件夹 → 也加入映射
    "EEMPA": "EEMPA",
    "DIP22MEEDA": "D2PMEEDA",
    "IPADM2BOL": "IPADM2BOL",
    "IPADM3BOL": "IPADM3BOL",
    "IPATFMM2BOL": "IPATFMM2BOL",
    "MEIPADM2BOL": "MEIPADM2BOL",
}

# 吸收剂分类
CATEGORY_MAP = {
    "EEMPA": "叔胺-仲胺-醚基类",
    "IBMPA": "叔胺-仲胺-醚基类",
    "EEMPPA": "叔胺-仲胺-醚基类",
    "EEDIPEDA": "叔胺-仲胺-醚基类",
    "EEDEDA": "叔胺-仲胺-醚基类",
    "EEMEDA": "叔胺-仲胺-醚基类",
    "IBDIPEDA": "叔胺-仲胺-醚基类",
    "IPADM2BOL": "烷醇胍基类",
    "IPADM3BOL": "烷醇胍基类",
    "IPATFMM2BOL": "烷醇胍基类",
    "MEIPADM2BOL": "烷醇胍基类",
    "D2PMEEDA": "叔胺-仲胺-醚基类",
}

def get_absorbent_name(folder_path):
    """从文件夹路径推断吸收剂名称"""
    folder_name = folder_path.name
    
    # 检查文件夹名是否直接在映射中
    base_name = folder_name.split("_")[0]
    if base_name in FOLDER_NAME_MAP:
        return FOLDER_NAME_MAP[base_name], folder_name
    
    # 检查命名文件夹（如 EEMPA_2000, IPADM2BOL_0218）
    for key in FOLDER_NAME_MAP:
        if folder_name.startswith(key):
            return FOLDER_NAME_MAP[key], folder_name
    
    # 提取数字编号
    num_match = re.match(r'^(\d+)', folder_name)
    if num_match:
        folder_num = num_match.group(1)
        if folder_num in FOLDER_NAME_MAP:
            return FOLDER_NAME_MAP[folder_num], folder_name
    
    # 无法识别，使用文件夹名
    return folder_name, folder_name

def parse_viscosity_file(filepath):
    """解析 viscosity_results_summary.txt 文件"""
    data = []
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        for line in lines[1:]:  # 跳过标题行
            line = line.strip()
            if not line:
                continue
            parts = line.split('\t')
            if len(parts) >= 2:
                try:
                    loading = float(parts[0])
                    viscosity = float(parts[1])
                    data.append((loading, viscosity))
                except ValueError:
                    continue
    except Exception as e:
        print(f"  [WARN] 无法解析 {filepath}: {e}")
    
    return data

def extract_folder_number(folder_name):
    """提取文件夹名称的主编号（用于排序）"""
    # 处理 "43_calculated" → 43
    match = re.match(r'^(\d+)', folder_name)
    if match:
        return int(match.group(1))
    return 99999  # 命名文件夹排在后面

def main():
    print("=" * 60)
    print("批量提取粘度汇总数据")
    print("=" * 60)
    
    # 找到所有粘度汇总文件
    all_folders = []
    for item in BASE_DIR.iterdir():
        if not item.is_dir():
            continue
        if item.name.startswith('.'):
            continue
        if item.name in ['script', 'structure', 'temp', 'png', 'result', 'in_sum', 
                         '要撰写的论文', 'Mine_molecular', 'SepPurTec', 'papercode']:
            continue
        
        vis_file = item / "gromacs_results" / "viscosity_results_summary.txt"
        if vis_file.exists():
            all_folders.append(item)
    
    print(f"\n找到 {len(all_folders)} 个含粘度数据的文件夹\n")
    
    # 提取所有数据
    all_data = []  # [(absorbent_name, folder_id, category, loading, viscosity), ...]
    empty_folders = []
    
    for folder in sorted(all_folders, key=lambda x: extract_folder_number(x.name)):
        abs_name, folder_id = get_absorbent_name(folder)
        category = CATEGORY_MAP.get(abs_name, "未分类")
        
        vis_file = folder / "gromacs_results" / "viscosity_results_summary.txt"
        vis_data = parse_viscosity_file(vis_file)
        
        if not vis_data:
            empty_folders.append(f"{abs_name} ({folder_id})")
            continue
        
        num_loadings = len(vis_data)
        max_loading = max(l[0] for l in vis_data)
        max_vis = max(l[1] for l in vis_data)
        
        print(f"  [{folder_id}] {abs_name}: {num_loadings} 个负载量, "
              f"最高负载={max_loading}, 最高粘度={max_vis:.1f} cP")
        
        for loading, viscosity in vis_data:
            all_data.append({
                'absorbent': abs_name,
                'folder': folder_id,
                'category': category,
                'loading': loading,
                'viscosity': viscosity,
            })
    
    print(f"\n空数据文件夹 ({len(empty_folders)}):")
    for ef in empty_folders:
        print(f"  - {ef}")
    
    print(f"\n总计: {len(set(d['absorbent'] for d in all_data))} 种吸收剂, "
          f"{len(all_data)} 条数据记录")
    
    # ---- 生成 Excel ----
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter
        
        wb = openpyxl.Workbook()
        
        # === Sheet 1: 全部粘度数据（宽表格式） ===
        ws_all = wb.active
        ws_all.title = "粘度总表"
        
        # 收集所有唯一的负载量值
        all_loadings = sorted(set(d['loading'] for d in all_data))
        
        # 按类别分组吸收剂
        categories_order = ["叔胺-仲胺-醚基类", "烷醇胍基类", "硅烷-烷氧基类", "未分类"]
        absorbents_by_cat = defaultdict(list)
        for d in all_data:
            absorbents_by_cat[d['category']].append((d['absorbent'], d['folder']))
        
        # 去重并保持顺序
        seen = set()
        absorbent_list = []
        for cat in categories_order:
            for abs_name, folder_id in absorbents_by_cat.get(cat, []):
                key = (abs_name, folder_id)
                if key not in seen:
                    seen.add(key)
                    absorbent_list.append((cat, abs_name, folder_id))
        
        # 写入表头
        ws_all.cell(row=1, column=1, value="吸收剂").font = Font(bold=True, size=11)
        ws_all.cell(row=1, column=2, value="文件夹").font = Font(bold=True, size=11)
        ws_all.cell(row=1, column=3, value="类别").font = Font(bold=True, size=11)
        
        loading_col_map = {}
        for i, lod in enumerate(all_loadings):
            col = i + 4
            loading_col_map[lod] = col
            ws_all.cell(row=1, column=col, value=f"{lod:.2f}").font = Font(bold=True)
        
        # 建立数据索引
        data_index = {}
        for d in all_data:
            key = (d['absorbent'], d['folder'])
            data_index[(key, d['loading'])] = d['viscosity']
        
        # 写入数据行
        for row_idx, (cat, abs_name, folder_id) in enumerate(absorbent_list, start=2):
            ws_all.cell(row=row_idx, column=1, value=abs_name)
            ws_all.cell(row=row_idx, column=2, value=folder_id)
            ws_all.cell(row=row_idx, column=3, value=cat)
            
            for lod in all_loadings:
                key = ((abs_name, folder_id), lod)
                if key in data_index:
                    vis = data_index[key]
                    cell = ws_all.cell(row=row_idx, column=loading_col_map[lod], value=round(vis, 2))
                    # 高粘度标红/标黄
                    if vis > 100:
                        cell.font = Font(bold=True, color="CC0000")
                    elif vis > 20:
                        cell.font = Font(bold=True, color="CC6600")
        
        # 调整列宽
        ws_all.column_dimensions['A'].width = 18
        ws_all.column_dimensions['B'].width = 14
        ws_all.column_dimensions['C'].width = 20
        for i in range(len(all_loadings)):
            ws_all.column_dimensions[get_column_letter(i + 4)].width = 12
        
        # 冻结首行
        ws_all.freeze_panes = 'A2'
        
        # === Sheet 2: 长表格式（便于筛选和绘图） ===
        ws_long = wb.create_sheet("粘度长表")
        headers = ["吸收剂", "文件夹", "类别", "CO₂负载量 (mol/mol)", "粘度 (cP)", "log₁₀(粘度)"]
        for col, h in enumerate(headers, 1):
            cell = ws_long.cell(row=1, column=col, value=h)
            cell.font = Font(bold=True, size=11)
        
        import math
        row = 2
        for cat, abs_name, folder_id in absorbent_list:
            for lod in all_loadings:
                key = ((abs_name, folder_id), lod)
                if key in data_index:
                    vis = data_index[key]
                    ws_long.cell(row=row, column=1, value=abs_name)
                    ws_long.cell(row=row, column=2, value=folder_id)
                    ws_long.cell(row=row, column=3, value=cat)
                    ws_long.cell(row=row, column=4, value=lod)
                    ws_long.cell(row=row, column=5, value=round(vis, 2))
                    ws_long.cell(row=row, column=6, value=round(math.log10(vis), 4) if vis > 0 else 0)
                    row += 1
        
        ws_long.column_dimensions['A'].width = 18
        ws_long.column_dimensions['B'].width = 14
        ws_long.column_dimensions['C'].width = 20
        ws_long.column_dimensions['D'].width = 20
        ws_long.column_dimensions['E'].width = 14
        ws_long.column_dimensions['F'].width = 14
        ws_long.freeze_panes = 'A2'
        
        # === Sheet 3: 各类别汇总 ===
        ws_cat = wb.create_sheet("按类别汇总")
        ws_cat.cell(row=1, column=1, value="类别").font = Font(bold=True, size=11)
        ws_cat.cell(row=1, column=2, value="吸收剂数量").font = Font(bold=True, size=11)
        ws_cat.cell(row=1, column=3, value="数据条数").font = Font(bold=True, size=11)
        ws_cat.cell(row=1, column=4, value="吸收剂列表").font = Font(bold=True, size=11)
        
        cat_stats = defaultdict(lambda: {'count': set(), 'data_count': 0})
        for d in all_data:
            cat_stats[d['category']]['count'].add(d['absorbent'])
            cat_stats[d['category']]['data_count'] += 1
        
        row = 2
        for cat in categories_order:
            if cat in cat_stats:
                stats = cat_stats[cat]
                ws_cat.cell(row=row, column=1, value=cat)
                ws_cat.cell(row=row, column=2, value=len(stats['count']))
                ws_cat.cell(row=row, column=3, value=stats['data_count'])
                ws_cat.cell(row=row, column=4, value=", ".join(sorted(stats['count'])))
                row += 1
        
        ws_cat.column_dimensions['A'].width = 22
        ws_cat.column_dimensions['B'].width = 14
        ws_cat.column_dimensions['C'].width = 12
        ws_cat.column_dimensions['D'].width = 80
        
        # === Sheet 4: 负载量覆盖矩阵 ===
        ws_matrix = wb.create_sheet("数据覆盖矩阵")
        # 复用表头逻辑
        
        outfile = BASE_DIR / "粘度数据汇总_全部吸收剂.xlsx"
        wb.save(outfile)
        print(f"\n✓ 已保存: {outfile}")
        return outfile
        
    except ImportError:
        print("\nopenpyxl 未安装，改用 CSV 输出...")
        import csv
        
        outfile = BASE_DIR / "粘度数据汇总_全部吸收剂.csv"
        all_loadings = sorted(set(d['loading'] for d in all_data))
        
        with open(outfile, 'w', newline='', encoding='utf-8-sig') as f:
            writer = csv.writer(f)
            writer.writerow(['吸收剂', '文件夹', '类别'] + [f"{l:.2f}" for l in all_loadings])
            
            seen = set()
            for cat in ["叔胺-仲胺-醚基类", "烷醇胍基类", "硅烷-烷氧基类", "未分类"]:
                for d in all_data:
                    key = (d['absorbent'], d['folder'])
                    if d['category'] == cat and key not in seen:
                        seen.add(key)
                        # 构建这一行的数据
                        row_data = {}
                        for dd in all_data:
                            if (dd['absorbent'], dd['folder']) == key:
                                row_data[dd['loading']] = dd['viscosity']
                        row_values = [round(row_data.get(l, ''), 2) if l in row_data else '' for l in all_loadings]
                        writer.writerow([d['absorbent'], d['folder'], cat] + row_values)
        
        print(f"\n✓ 已保存: {outfile}")
        return outfile


if __name__ == "__main__":
    main()
