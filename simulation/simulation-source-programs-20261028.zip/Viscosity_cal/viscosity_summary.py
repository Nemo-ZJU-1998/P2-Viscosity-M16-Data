import argparse
import os
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

def read_viscosity_data(file_path):
    """读取粘度数据文件"""
    try:
        data = np.loadtxt(file_path, skiprows=1)  # 跳过标题行
        loadings = data[:, 0]
        viscosities = data[:, 1]
        return loadings, viscosities
    except Exception as e:
        print(f"Error reading file {file_path}: {e}")
        return None, None

def main():
    # 设置解析器
    parser = argparse.ArgumentParser(description='Plot viscosity vs loading for multiple absorbents with different colors and markers')
    parser.add_argument('directories', nargs='+', help='List of directory names containing viscosity data')
    args = parser.parse_args()
    
    # 创建图表
    plt.figure(figsize=(10, 8))
    ax = plt.gca()
    
    # 设置颜色和标记循环 - 使用不同的颜色和标记组合[1,6,7](@ref)
    colors = plt.cm.tab10(np.linspace(0, 1, len(args.directories)))
    markers = ['o', 's', '^', 'D', 'v', '<', '>', 'p', '*', 'X', 'd', 'h']  # 多种标记样式[6,7](@ref)
    
    # 处理每个目录
    for i, directory in enumerate(args.directories):
        file_path = os.path.join(directory, 'gromacs_results', 'viscosity_results_summary.txt')
        
        if not os.path.exists(file_path):
            print(f"Warning: File not found {file_path}, skipping...")
            continue
        
        # 读取数据
        loadings, viscosities = read_viscosity_data(file_path)
        
        if loadings is None:
            continue
        
        # 选择颜色和标记
        color = colors[i]
        marker = markers[i % len(markers)]  # 循环使用标记列表[7](@ref)
        label = os.path.basename(directory.rstrip('/'))
        
        # 绘制散点图 - 使用不同的颜色和标记[1,6,7](@ref)
        ax.scatter(loadings, viscosities, color=color, marker=marker, 
                  label=label, alpha=0.7, s=80, edgecolors='white', linewidth=0.5)
        
        # 线性拟合（在对数坐标上）
        log_viscosities = np.log(viscosities)
        slope, intercept, r_value, p_value, std_err = stats.linregress(loadings, log_viscosities)
        
        # 生成拟合线
        fit_loadings = np.linspace(min(loadings), max(loadings), 100)
        fit_viscosities = np.exp(slope * fit_loadings + intercept)
        
        # 绘制拟合线 - 使用与散点相同的颜色但不同的线型[5](@ref)
        ax.plot(fit_loadings, fit_viscosities, color=color, linestyle='--', 
                linewidth=2, alpha=0.8, label=f'{label} fit (R²={r_value**2:.3f})')
        
        print(f"{label}: Linear fit equation: ln(η) = {slope:.3f}×loading + {intercept:.3f}, R² = {r_value**2:.3f}")
    
    # 设置坐标轴
    ax.set_xlim(-0.01, 0.42)
    ax.set_ylim(1, 1000)
    ax.set_yscale('log')  # 设置y轴为对数坐标
    
    # 添加标签和标题
    ax.set_xlabel('Loading (mol/mol)', fontsize=12, weight='bold')
    ax.set_ylabel('Viscosity (cP)', fontsize=12, weight='bold')
    ax.set_title('Viscosity vs Loading for Different Absorbents', fontsize=14, weight='bold')
    
    # 添加图例
    ax.legend(loc='best', frameon=True, shadow=True, fontsize=9)
    
    # 添加网格
    ax.grid(True, which='both', linestyle='--', alpha=0.6)
    
    # 保存图像
    plt.savefig('viscosity_summary.png', dpi=300, bbox_inches='tight')
    print("Plot saved as 'viscosity_summary.png'")
    
    # 显示图像
    plt.show()

if __name__ == '__main__':
    main()