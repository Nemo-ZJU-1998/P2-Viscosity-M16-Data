#!/bin/bash
# 脚本用法：./do_structure.sh <序号> [option]
# 如：./do_structure.sh 71 或 ./do_structure.sh 71-82 或 ./do_structure.sh 71 -amine 或 ./do_structure.sh 55,59,61,72 --viscosity
# 功能：从 smiles_summary.xlsx 读取 Amine_SMILE（及 Protonated_SMILE, Carbamate_SMILE 如果适用） → 使用 RDKit 绘制分子结构图 → 保存到 ./structure 文件夹下
# 对于多个序号，还会生成一个拼接的网格图 combined_<sequence>.png
# 如果 option 为 -amine，且只有一个序号，则绘制序号、新鲜胺、质子化铵、氨基甲酸盐，并拼接成一个图（高 DPI）
# 如果 option 为 --viscosity，则为每个序号绘制分子结构，并将其与对应的粘度图（/work/home/xuwenhao/Viscosity_cal/<index>/gromacs_results/viscosity_vs_loading_num<index>_kg_fresh.png）垂直拼接（粘度图在上，结构图在下），保存为 <index>_viscosity.png；如果多个序号，则生成拼接的网格图 combined_<sequence>_viscosity.png
# 假设当前目录包含 smiles_summary.xlsx
# 依赖：pandas, openpyxl, rdkit, pillow (PIL)
# 设置路径
EXCEL_FILE="smiles_summary.xlsx"
STRUCTURE_DIR="./structure"
# 创建 structure 文件夹如果不存在
mkdir -p "$STRUCTURE_DIR"
# 检查 Excel 文件
if [ ! -f "$EXCEL_FILE" ]; then
    echo "错误: 未找到 $EXCEL_FILE" >&2
    exit 1
fi
# 解析输入序号（支持 1,3,5-7 或 71-82）
parse_sequence() {
    local input="$1"
    local result=()
    IFS=',' read -ra parts <<< "$input"
    for part in "${parts[@]}"; do
        if [[ "$part" =~ ^[0-9]+-[0-9]+$ ]]; then
            local start="${part%-*}"
            local end="${part#*-}"
            for ((i=start; i<=end; i++)); do
                result+=("$i")
            done
        elif [[ "$part" =~ ^[0-9]+$ ]]; then
            result+=("$part")
        else
            echo "警告: 忽略无效格式 '$part'" >&2
        fi
    done
    echo "${result[@]}"
}
# 安全读取 SMILES（仅输出 SMILES）
get_smiles() {
    local index="$1"
    local column="$2"
    python3 - << EOF
import pandas as pd
import sys
try:
    df = pd.read_excel("$EXCEL_FILE", engine='openpyxl')
    df.columns = [col.strip() for col in df.columns]
    if '吸收剂序号' in df.columns:
        df['吸收剂序号'] = pd.to_numeric(df['吸收剂序号'], errors='coerce')
    else:
        print("错误: 列 '吸收剂序号' 不存在", file=sys.stderr)
        print("")
        sys.exit(1)
    row = df[df['吸收剂序号'] == $index]
    if not row.empty and pd.notna(row['$column'].iloc[0]):
        smiles = str(row['$column'].iloc[0]).strip()
        print(smiles)
    else:
        print("")
except Exception as e:
    print(f"Python 读取错误: {e}", file=sys.stderr)
    print("")
EOF
}
# ========= 主逻辑 =========
if [ $# -lt 1 ] || [ $# -gt 2 ]; then
    echo "用法: $0 <序号，例如 71 或 1,3 或 71-82> [option，例如 -amine 或 --viscosity]" >&2
    exit 1
fi
sequence="$1"
option="${2:-}"
indices=($(parse_sequence "$sequence"))
if [ ${#indices[@]} -eq 0 ]; then
    echo "错误: 未解析到有效序号！" >&2
    exit 1
fi
echo "开始处理序号: ${indices[@]}"
# 如果 option 是 -amine，且只有一个序号，则特殊处理
if [ "$option" = "-amine" ]; then
    if [ ${#indices[@]} -ne 1 ]; then
        echo "错误: -amine 选项仅支持单个序号！" >&2
        exit 1
    fi
    index="${indices[0]}"
    echo "=== 处理序号 $index ( -amine 模式) ==="
   
    # 读取三种 SMILES
    amine_smile=$(get_smiles "$index" "Amine_SMILE")
    protonated_smile=$(get_smiles "$index" "Protonated_SMILE")
    carbamate_smile=$(get_smiles "$index" "Carbamate_SMILE")
   
    if [ -z "$amine_smile" ] || [ -z "$protonated_smile" ] || [ -z "$carbamate_smile" ]; then
        echo "警告: 序号 $index 在 Excel 中缺少有效的 SMILES，跳过。"
        continue
    fi
   
    # 使用 Python 绘制并拼接（包括序号作为文本）
    python3 - << EOF
from rdkit import Chem
from rdkit.Chem import Draw
from PIL import Image, ImageDraw, ImageFont
import io
try:
    # 绘制分子图像 (高 DPI)
    def draw_mol(smiles):
        mol = Chem.MolFromSmiles(smiles)
        if mol:
            img = Draw.MolToImage(mol, size=(400, 400), dpi=300)
            return img
        return None
   
    amine_img = draw_mol("$amine_smile")
    protonated_img = draw_mol("$protonated_smile")
    carbamate_img = draw_mol("$carbamate_smile")
   
    if not all([amine_img, protonated_img, carbamate_img]):
        print("错误: 无法从 SMILES 创建所有分子，跳过。")
    else:
        # 创建序号文本图像
        text_img = Image.new('RGB', (400, 400), color='white')
        draw = ImageDraw.Draw(text_img)
        font = ImageFont.load_default().font_variant(size=100) # 增大字体
        text = str($index)
        bbox = draw.textbbox((0,0), text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        draw.text(((400 - text_width) / 2, (400 - text_height) / 2), text, fill='black', font=font)
       
        # 拼接成 1x4 网格
        combined = Image.new('RGB', (1600, 400))
        combined.paste(text_img, (0, 0))
        combined.paste(amine_img, (400, 0))
        combined.paste(protonated_img, (800, 0))
        combined.paste(carbamate_img, (1200, 0))
       
        combined.save(f"$STRUCTURE_DIR/${index}_amine_combined.png", dpi=(300,300))
        print(f"拼接分子结构图已保存: $STRUCTURE_DIR/${index}_amine_combined.png")
except Exception as e:
    print(f"绘制错误: {e}")
EOF
   
elif [ "$option" = "--viscosity" ]; then
    # Viscosity 模式：为每个序号绘制结构，并与粘度图垂直拼接；如果多个，则生成网格
    stacked_list=()
    indices_list=()
    for index in "${indices[@]}"; do
        echo "=== 处理序号 $index (--viscosity 模式) ==="
       
        # 读取 Amine_SMILE
        amine_smile=$(get_smiles "$index" "Amine_SMILE")
        if [ -z "$amine_smile" ]; then
            echo "警告: 序号 $index 在 Excel 中无有效 Amine_SMILE，跳过。"
            continue
        fi
       
        # 使用 RDKit 绘制单个分子结构图 (高 DPI)
        python3 - << EOF
from rdkit import Chem
from rdkit.Chem import Draw
try:
    mol = Chem.MolFromSmiles("$amine_smile")
    if mol is not None:
        Draw.MolToFile(mol, f"$STRUCTURE_DIR/$index.png", size=(400, 400), dpi=300)
        print(f"分子结构图已保存: $STRUCTURE_DIR/$index.png")
    else:
        print("错误: 无法从 SMILES 创建分子，跳过。")
except Exception as e:
    print(f"绘制错误: {e}")
EOF
       
        # 检查粘度图路径
        plot_path="/work/home/xuwenhao/Viscosity_cal/${index}/gromacs_results/viscosity_vs_loading_num${index}_kg_fresh.png"
        if [ ! -f "$plot_path" ]; then
            echo "警告: 未找到粘度图 $plot_path，仅保存结构图。"
            continue
        fi
       
        # 使用 PIL 垂直拼接：粘度图在上，结构图在下
        python3 - << EOF
from PIL import Image
try:
    plot_img = Image.open("$plot_path")
    struct_img = Image.open(f"$STRUCTURE_DIR/$index.png")
   
    # 调整粘度图宽度为 400，保持纵横比
    width = 400
    plot_width, plot_height = plot_img.size
    new_height = int((width / plot_width) * plot_height)
    plot_img = plot_img.resize((width, new_height))
   
    # 创建拼接图像
    total_height = new_height + 400
    combined = Image.new('RGB', (width, total_height))
    combined.paste(plot_img, (0, 0))
    combined.paste(struct_img, (0, new_height))
   
    combined.save(f"$STRUCTURE_DIR/${index}_viscosity.png", dpi=(300,300))
    print(f"粘度拼接图已保存: $STRUCTURE_DIR/${index}_viscosity.png")
except Exception as e:
    print(f"拼接错误: {e}")
EOF
       
        # 收集用于网格拼接
        stacked_list+=("${index}_viscosity.png")
        indices_list+=("$index")
    done
   
    # 如果有多个有效图像，生成拼接网格图 (标签在下方)
    if [ ${#stacked_list[@]} -gt 1 ]; then
        # 准备 Python 数组字符串
        images_array=$(printf "'%s'," "${stacked_list[@]}")
        images_array="[${images_array%,}]"
       
        labels_array=$(printf "'%s'," "${indices_list[@]}")
        labels_array="[${labels_array%,}]"
       
        # 规范化 sequence 用于文件名（替换 , 和 - 为 _）
        safe_sequence="${sequence//,/_}"
        safe_sequence="${safe_sequence//-/_}"
       
        python3 - << EOF
from PIL import Image, ImageDraw, ImageFont
try:
    images = [Image.open(f"$STRUCTURE_DIR/{path}") for path in $images_array]
   
    # 计算网格大小
    n = len(images)
    cols = min(5, n)  # 最多 5 列
    rows = (n + cols - 1) // cols
   
    # 找到最大高度
    max_height = max([img.size[1] for img in images])
   
    cell_width = 400
    label_height = 50
    cell_height = max_height + label_height
   
    # 创建网格图像
    grid_width = cols * cell_width
    grid_height = rows * cell_height
    grid_img = Image.new('RGB', (grid_width, grid_height), color='white')
   
    labels = $labels_array
    font = ImageFont.load_default().font_variant(size=30)
   
    for i, img in enumerate(images):
        row_idx = i // cols
        col_idx = i % cols
        x = col_idx * cell_width
        y = row_idx * cell_height
       
        # 垂直居中图像
        offset_y = (max_height - img.size[1]) // 2
        grid_img.paste(img, (x, y + offset_y))
       
        # 绘制标签
        draw = ImageDraw.Draw(grid_img)
        label = labels[i]
        bbox = draw.textbbox((0,0), label, font=font)
        text_width = bbox[2] - bbox[0]
        draw.text((x + (cell_width - text_width) / 2, y + max_height + 10), label, fill='black', font=font)
   
    grid_img.save(f"$STRUCTURE_DIR/combined_${safe_sequence}_viscosity.png", dpi=(300,300))
    print(f"拼接粘度网格图已保存: $STRUCTURE_DIR/combined_${safe_sequence}_viscosity.png")
except Exception as e:
    print(f"网格拼接错误: {e}")
EOF
    elif [ ${#stacked_list[@]} -eq 1 ]; then
        echo "只有一个有效拼接图，无需生成网格图。"
    fi
else
    # 正常模式
    # 收集有效的 SMILES 和 index
    smiles_list=()
    indices_list=()
    for index in "${indices[@]}"; do
        echo "=== 处理序号 $index ==="
       
        # 读取 Amine_SMILE
        amine_smile=$(get_smiles "$index" "Amine_SMILE")
        if [ -z "$amine_smile" ]; then
            echo "警告: 序号 $index 在 Excel 中无有效 Amine_SMILE，跳过。"
            continue
        fi
       
        # 使用 RDKit 绘制单个分子结构图 (高 DPI)
        python3 - << EOF
from rdkit import Chem
from rdkit.Chem import Draw
try:
    mol = Chem.MolFromSmiles("$amine_smile")
    if mol is not None:
        Draw.MolToFile(mol, f"$STRUCTURE_DIR/$index.png", size=(400, 400), dpi=300)
        print(f"分子结构图已保存: $STRUCTURE_DIR/$index.png")
    else:
        print("错误: 无法从 SMILES 创建分子，跳过。")
except Exception as e:
    print(f"绘制错误: {e}")
EOF
       
        # 收集用于拼接
        smiles_list+=("$amine_smile")
        indices_list+=("$index")
    done
   
    # 如果有多个有效分子，生成拼接图 (高 DPI)
    if [ ${#indices_list[@]} -gt 1 ]; then
        # 准备 Python 数组字符串
        smiles_array=$(printf "'%s'," "${smiles_list[@]}")
        smiles_array="[${smiles_array%,}]"
       
        labels_array=$(printf "'%s'," "${indices_list[@]}")
        labels_array="[${labels_array%,}]"
       
        # 规范化 sequence 用于文件名（替换 , 和 - 为 _）
        safe_sequence="${sequence//,/_}"
        safe_sequence="${safe_sequence//-/_}"
       
        python3 - << EOF
from rdkit import Chem
from rdkit.Chem import Draw
try:
    mols = [Chem.MolFromSmiles(s) for s in $smiles_array]
    labels = $labels_array
    # 过滤有效的 mol
    valid_mols = []
    valid_labels = []
    for mol, label in zip(mols, labels):
        if mol is not None:
            valid_mols.append(mol)
            valid_labels.append(label)
   
    if valid_mols:
        # 计算网格大小
        n = len(valid_mols)
        cols = min(5, n) # 最多 5 列
        rows = (n + cols - 1) // cols
        img = Draw.MolsToGridImage(valid_mols, molsPerRow=cols, subImgSize=(400, 400), legends=valid_labels)
        img.save(f"$STRUCTURE_DIR/combined_${safe_sequence}.png", dpi=(300,300))
        print(f"拼接分子结构图已保存: $STRUCTURE_DIR/combined_${safe_sequence}.png")
    else:
        print("错误: 无有效分子可拼接。")
except Exception as e:
    print(f"拼接绘制错误: {e}")
EOF
    elif [ ${#indices_list[@]} -eq 1 ]; then
        echo "只有一个分子，无需生成拼接图。"
    fi
fi