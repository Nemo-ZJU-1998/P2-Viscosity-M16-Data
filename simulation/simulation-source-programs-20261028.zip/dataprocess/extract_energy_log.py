import argparse  

def extract_energy_log(file_path):  
    """  
    提取.log文件中以"gmx_mpi energy -f"开头的行，以及分割线及其上下各一行。  
    """  
    try:  
        with open(file_path, 'r', encoding='utf-8') as f:  
            lines = f.readlines()  
    except FileNotFoundError:  
        print(f"文件 {file_path} 不存在。")  
        return  

    result_lines = []  
    for i, line in enumerate(lines):  
        stripped_line = line.strip()  
        if stripped_line.startswith("gmx_mpi energy -f"):  
            # 处理上下行  
            if i > 0:  
                result_lines.append(lines[i-1])  
            result_lines.append(line)  
            if i < len(lines) - 1:  
                result_lines.append(lines[i+1])  
        elif stripped_line == '-------------------------------------------------------------------------------':  
            if i > 0:  
                result_lines.append(lines[i-1])  
            result_lines.append(line)  
            if i < len(lines) - 1:  
                result_lines.append(lines[i+1])  

    # 生成输出文件名  
    base_name = file_path.split('.')[0]  
    output_file = f"{base_name}_energy.txt"  

    # 写入结果  
    with open(output_file, 'w', encoding='utf-8') as f:  
        f.writelines(result_lines)  

    print(f"提取完成，结果已保存至 {output_file}")  

def main():  
    parser = argparse.ArgumentParser(description='提取.log文件中的能量相关日志')  
    parser.add_argument('file', help='输入的.log文件路径')  
    args = parser.parse_args()  
    extract_energy_log(args.file)  

if __name__ == '__main__':  
    main()  