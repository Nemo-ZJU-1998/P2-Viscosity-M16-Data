import matplotlib.pyplot as plt
import numpy as np
import sys

# 检查命令行参数
if len(sys.argv) != 2:
    print("用法: python em_Potential_plot.py <file>")
    sys.exit(1)

# 获取命令行指定的文件路径
potential_file = sys.argv[1]

# 初始化数据列表
time = []
potential = []

# 读取势能数据
with open(potential_file, 'r') as file:
    for line in file:
        # 跳过注释行（以@或#开头）
        if line.startswith('@') or line.startswith('#'):
            continue
        # 尝试解析数据行
        try:
            # 分割行，提取时间和势能值
            t, pot = map(float, line.strip().split())
            time.append(t)
            potential.append(pot)
        except ValueError:
            # 如果行格式不正确，跳过该行并提示
            print(f"跳过格式不正确的行：{line.strip()}")
            continue

# 转换为 NumPy 数组
time = np.array(time)
potential = np.array(potential)

# 创建图表
plt.figure(figsize=(10, 6))
plt.plot(time, potential,
         marker='o',
         linestyle='-',
         color='blue',
         label='Potential Energy')

# 设置图表标题和标签
plt.xlabel('Time (ps)')
plt.ylabel('Potential Energy (kJ/mol)')
plt.title('Time vs Potential Energy')
plt.grid(True)
plt.legend()

# 保存图表
plt.savefig('result/Time_vs_Potential_Energy.png', dpi=300)

# 显示图表
#plt.show()

# 关闭图表，以释放内存
plt.close()