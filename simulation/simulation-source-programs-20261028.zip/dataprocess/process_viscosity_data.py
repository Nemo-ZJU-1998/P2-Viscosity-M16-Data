import sys
from collections import defaultdict

def main():
    # 检查命令行参数
    if len(sys.argv) != 2:
        print("Usage: python script.py viscosity_summary.txt")
        sys.exit(1)
    
    filename = sys.argv[1]
    
    # 读取文件内容
    with open(filename, 'r') as f:
        lines = f.readlines()
    
    # 分离标题行和数据行
    header = []
    data_lines = []
    
    for line in lines:
        if line.startswith('#'):
            header.append(line)
        else:
            stripped_line = line.strip()
            if stripped_line:  # 忽略空行
                parts = stripped_line.split()
                if len(parts) == 6:
                    data_lines.append(parts)
                else:
                    print(f"Warning: 跳过无效数据行 - {line.strip()}")
    
    # 分组处理重复项
    groups = defaultdict(list)
    for parts in data_lines:
        # 使用后四列作为唯一标识(1/Viscosity, Err.Est., RMSD, Tot-Drift)
        # 注意: 保留原始字符串格式
        key = tuple(parts[2:])
        groups[key].append(parts)
    
    # 选择每组中Acceleration最小的一行
    unique_data = []
    for group_key, group_data in groups.items():
        # 找到该组中Acceleration最小的行
        min_acc_row = min(group_data, key=lambda x: float(x[1]))
        unique_data.append(min_acc_row)
    
    # 保持原始顺序(Temperature和Acceleration排序)
    # 注意: 如果不需要原始顺序，直接使用unique_data即可
    unique_data_sorted = sorted(
        unique_data,
        key=lambda x: (int(x[0]), float(x[1])),
        reverse=False
    )
    
    # 写回文件
    with open(filename, 'w') as f:
        # 写入标题行
        for h in header:
            f.write(h)
        
        # 写入处理后的数据行
        for row in unique_data_sorted:
            f.write(" ".join(row) + '\n')
    
    print(f"处理完成! 保留了{len(unique_data_sorted)}行数据")

if __name__ == "__main__":
    main()