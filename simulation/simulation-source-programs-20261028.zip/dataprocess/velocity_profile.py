import argparse
import sys
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from collections import defaultdict
import math

# Atomic mass table (g/mol)
ATOM_MASS = {
    'C': 12.01, 'H': 1.008, 'O': 16.00,
    'N': 14.01, 'P': 30.97, 'Si': 28.08
}

def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='Calculate velocity profile from GRO file')
    parser.add_argument('-f', '--file', default='traj.gro', help='Input GRO file')
    parser.add_argument('-o', '--output', default='zvx.xvg', help='Output data file')
    parser.add_argument('--mode', choices=['atom', 'com'], default='com',
                      help='Calculation mode: atom=atomic velocities, com=center of mass velocities')
    parser.add_argument('--dz', type=float, default=0.2, 
                      help='Bin width (default 0.2 nm)')
    parser.add_argument('--plot', default='fit_plot.png',
                      help='Output plot filename')
    return parser.parse_args()

def get_box_z(gro_file):
    """Get box size from the first frame of GRO file"""
    with open(gro_file, 'r') as f:
        f.readline()  # Skip title
        natoms_line = f.readline().strip()
        try:
            natoms = int(natoms_line)
        except ValueError:
            sys.stderr.write(f"Error: Cannot read number of atoms: '{natoms_line}'\n")
            sys.exit(1)
            
        # Skip all atom lines
        for _ in range(natoms):
            f.readline()
            
        # Read box line
        box_line = f.readline().split()
        if not box_line:
            sys.stderr.write("Error: Cannot read box information\n")
            sys.exit(1)
            
        if len(box_line) != 3:
            sys.stderr.write(f"Error: Only orthogonal boxes are supported, found {len(box_line)} elements\n")
            sys.exit(1)
            
        try:
            box_z = float(box_line[2])
        except ValueError:
            sys.stderr.write(f"Error: Cannot parse box information: '{box_line}'\n")
            sys.exit(1)
            
    return box_z

def calculate_profile(args, box_z):
    """Main calculation function"""
    dz = args.dz
    z_min = 0.0
    z_max = box_z
    nbins = int(z_max / dz) + 1
    
    bins = [{'sum_vx': 0.0, 'mass_sum': 0.0, 'count': 0}
            for _ in range(nbins)]
    
    total_frames = 0
    with open(args.file, 'r') as f:
        while True:
            # Read frame header
            title = f.readline()
            if not title:
                break  # End of file
                
            # Read number of atoms
            natoms_line = f.readline().strip()
            if not natoms_line:
                break
            try:
                natoms = int(natoms_line)
            except ValueError:
                sys.stderr.write(f"Error: Cannot read number of atoms: '{natoms_line}'\n")
                break
            
            if args.mode == 'atom':
                # Atomic velocity mode
                for _ in range(natoms):
                    line = f.readline()
                    if not line:
                        break
                    
                    atom = line[10:15].strip()
                    mass = ATOM_MASS.get(atom[0], 0.0)
                    if mass == 0.0:
                        continue
                    
                    # Parse coordinates and velocities
                    try:
                        z = float(line[36:44])
                        vx = float(line[44:52])
                    except ValueError:
                        continue
                    
                    # Fold coordinate to [0, box_z)
                    z_folded = z - box_z * math.floor(z / box_z)
                    
                    # Bin data
                    bin_idx = min(int(z_folded / dz), nbins - 1)
                    
                    # Accumulate data
                    bins[bin_idx]['sum_vx'] += mass * vx
                    bins[bin_idx]['mass_sum'] += mass
                    bins[bin_idx]['count'] += 1
            
            else:  # Center of mass mode
                molecules = defaultdict(list)
                for _ in range(natoms):
                    line = f.readline()
                    if not line:
                        break
                        
                    res_id = line[0:5].strip()
                    atom = line[10:15].strip()
                    mass = ATOM_MASS.get(atom[0], 0.0)
                    if mass == 0.0:
                        continue
                    
                    try:
                        z = float(line[36:44])
                        vx = float(line[44:52])
                    except ValueError:
                        continue
                    
                    molecules[res_id].append((mass, z, vx))
                
                # Calculate center of mass for each molecule
                for mol in molecules.values():
                    total_mass = sum(m for m, _, _ in mol)
                    if total_mass == 0.0:
                        continue
                    
                    com_z = sum(m * z for m, z, _ in mol) / total_mass
                    com_vx = sum(m * vx for m, _, vx in mol) / total_mass
                    
                    # Fold coordinate to [0, box_z)
                    com_z_folded = com_z - box_z * math.floor(com_z / box_z)
                    
                    # Bin data
                    bin_idx = min(int(com_z_folded / dz), nbins - 1)
                    
                    # Accumulate data
                    bins[bin_idx]['sum_vx'] += com_vx
                    bins[bin_idx]['count'] += 1
            
            # Read and skip box line
            f.readline()
            total_frames += 1
    
    return bins, (z_min, z_max, dz, box_z), total_frames

def cos_model(z, V, k):
    """Fitting model function: Vx(z) = V*cos(k*z)"""
    return V * np.cos(k * z)

def fit_and_plot(z_data, vx_data, output_plot):
    """Perform nonlinear fitting and plot results"""
    # Filter invalid data
    mask = ~np.isnan(vx_data)
    z_clean = z_data[mask]
    vx_clean = vx_data[mask]
    
    if len(z_clean) < 2:
        print("Error: Insufficient data points for fitting")
        return
    
    # Set initial guess parameters
    V_guess = np.max(np.abs(vx_clean))  # Initial amplitude guess
    k_guess = 2 * np.pi / (np.max(z_clean) - np.min(z_clean))  # Initial wave number guess
    
    try:
        # Perform nonlinear least squares fitting
        params, pcov = curve_fit(cos_model, z_clean, vx_clean, 
                                p0=[V_guess, k_guess],
                                bounds=([0, 0], [np.inf, np.inf]))
        
        V_fit, k_fit = params
        perr = np.sqrt(np.diag(pcov))  # Parameter errors
        
        # Calculate R²
        residuals = vx_clean - cos_model(z_clean, *params)
        ss_res = np.sum(residuals**2)
        ss_tot = np.sum((vx_clean - np.mean(vx_clean))**2)
        r_squared = 1 - (ss_res / ss_tot)
        
    except Exception as e:
        print(f"Fitting failed: {str(e)}")
        return

    # Generate fitted curve
    z_fit = np.linspace(np.min(z_clean), np.max(z_clean), 200)
    vx_fit = cos_model(z_fit, V_fit, k_fit)

    # Create plot
    plt.figure(figsize=(10, 6))
    plt.scatter(z_clean, vx_clean, s=20, alpha=0.7, label='Original data')
    plt.plot(z_fit, vx_fit, 'r-', lw=2, label='Fit curve')
    
    # Add fit results annotation
    textstr = '\n'.join((
        f'$V$ = {V_fit:.4f} ± {perr[0]:.4f} nm/ps',
        f'$k$ = {k_fit:.4f} ± {perr[1]:.4f} nm⁻¹',
        f'$R^2$ = {r_squared:.4f}'))
    plt.gca().text(0.05, 0.95, textstr, transform=plt.gca().transAxes,
                  fontsize=12, verticalalignment='top',
                  bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

    plt.xlabel('Z position (nm)', fontsize=12)
    plt.ylabel('Velocity Vx (nm/ps)', fontsize=12)
    plt.title('Velocity Profile Fitting', fontsize=14)
    plt.legend()
    plt.grid(alpha=0.3)
    
    # Save plot
    plt.savefig(output_plot, dpi=300, bbox_inches='tight')
    print(f"Plot saved to: {output_plot}")
    
def main():
    args = parse_args()
    
    # Get box size
    box_z = get_box_z(args.file)
    print(f"Using box size: box_z = {box_z:.3f} nm")
    
    # Calculate velocity profile
    bins, (z_min, z_max, dz, box_z), total_frames = calculate_profile(args, box_z)
    print(f"Successfully processed {total_frames} frames")
    
    # Prepare data for output
    z_list, vx_list = [], []
    for i in range(len(bins)):
        z_center = (i + 0.5) * dz
        if args.mode == 'atom':
            if bins[i]['mass_sum'] > 0:
                avg_vx = bins[i]['sum_vx'] / bins[i]['mass_sum']
            else:
                continue
        else:  # com mode
            if bins[i]['count'] > 0:
                avg_vx = bins[i]['sum_vx'] / bins[i]['count']
            else:
                continue
        z_list.append(z_center)
        vx_list.append(avg_vx)
    
    # Perform fitting and plot
    fit_and_plot(np.array(z_list), np.array(vx_list), args.plot)
    
    # Save data
    with open(args.output, 'w') as fw:
        fw.write(f"# Mode: {args.mode}  Z-range: [{z_min:.2f}-{z_max:.2f}]  dz={dz:.2f}  Frames: {total_frames}\n")
        for z, vx in zip(z_list, vx_list):
            fw.write(f"{z:.3f}\t{vx:.6f}\n")
    print(f"Data saved to: {args.output}")

if __name__ == '__main__':
    main()