import sys
import numpy as np
import matplotlib.pyplot as plt
import argparse

def convert_xvg_to_txt(xvg_file):
    txt_file = xvg_file.replace('.xvg', '.txt')
    with open(xvg_file, 'r', encoding='utf-8') as f_xvg, open(txt_file, 'w') as f_txt:
        for line in f_xvg:
            if not line.startswith(('#', '@')):
                f_txt.write(line)
    return txt_file

def calculate_rolling_averages(data):
    forward_averages = np.array([np.mean(data[:i + 1]) for i in range(len(data))])
    backward_averages = np.array([np.mean(data[i:]) for i in range(len(data))])
    return forward_averages, backward_averages

def plot_data(time, data, ylabel, title, filename):
    forward_avg, backward_avg = calculate_rolling_averages(data)

    plt.figure()
    plt.plot(time, data, label='Original Data')
    plt.plot(time, forward_avg, label='Forward Average')
    plt.plot(time, backward_avg, label='Backward Average')
    plt.xlabel('Time (ps)')
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend()
    plt.grid(True)

    # 保存图片为 PNG 格式
    plt.savefig(filename, dpi=300)
# 显示图表  
#plt.show()  

# 关闭图表，以释放内存  
plt.close()  
def main():
    parser = argparse.ArgumentParser(description='Plot time vs pressure curves.')
    parser.add_argument('file', type=str, help='Path to the .xvg file')
    parser.add_argument('-b', '--begin', type=float, default=None, help='Start time in ps')
    parser.add_argument('-e', '--end', type=float, default=None, help='End time in ps')

    args = parser.parse_args()

    xvg_file = args.file
    if not xvg_file.endswith('.xvg'):
        print("Please provide a valid .xvg file.")
        sys.exit(1)

    txt_file = convert_xvg_to_txt(xvg_file)

    data = np.loadtxt(txt_file)
    time = data[:, 0]
    pressure = data[:, 1]

    # 筛选指定时间范围内的数据
    if args.begin is not None and args.end is not None:
        mask = (time >= args.begin) & (time <= args.end)
        time = time[mask]
        pressure = pressure[mask]

    # Plot time vs pressure and save the figure
    pressure_filename = xvg_file.replace('.xvg', '_pressure.png')
    plot_data(time, pressure, 'Pressure (bar)', 'Time vs Pressure', pressure_filename)

if __name__ == "__main__":
    main()