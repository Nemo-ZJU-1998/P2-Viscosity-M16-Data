#!/usr/bin/env python3
# linear_regression_analysis.py

import numpy as np
import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
import sys
import os
from itertools import combinations
import argparse

def main(summary_file, output_dir="."):
    """
    Optimized linear regression analysis script: Find the best 5-point combination 
    with highest R² for regression analysis
    
    Parameters:
    summary_file: Input data file path
    output_dir: Output directory path
    """
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Read viscosity summary file
    try:
        df = pd.read_csv(summary_file, sep='\s+', comment='#',
                         names=['Temp', 'Accel', 'InvVisc', 'ErrEst', 'RMSD', 'TotDrift'])
        print(f"Successfully read file {summary_file}, containing {len(df)} data points")
        
        # Fix error calculation formula: Use consistent formula with the first script
        # Calculate viscosity η = 1 / InvVisc * 1000 (unit: cP)
        df['Viscosity'] = 1 / df['InvVisc'] * 1000
        # Correct viscosity error formula: Δη = η * Δ(1/η) / (1/η)
        df['Viscosity_Err'] = df['Viscosity'] * df['ErrEst'] / df['InvVisc']
        
        print("Processed viscosity data:")
        print(df[['Accel', 'Viscosity', 'Viscosity_Err']])
    except Exception as e:
        print(f"Error reading file {summary_file}: {e}")
        return None
    
    # Sort by acceleration amplitude from small to large
    df = df.sort_values(by='Accel').reset_index(drop=True)
    
    # Check if enough data points are available
    if len(df) < 5:
        print(f"Error: Only {len(df)} data points available, regression analysis requires at least 5 points")
        return None
    
    # Find the 5-point combination with maximum R²
    best_r_squared = -float('inf')
    best_combination = None
    best_slope = None
    best_intercept = None
    best_std_err = None
    
    # Generate all possible 5-point combinations
    all_combinations = list(combinations(range(len(df)), 5))
    print(f"Testing {len(all_combinations)} possible 5-point combinations...")
    
    for i, comb in enumerate(all_combinations):
        # Get data for current combination
        comb_df = df.iloc[list(comb)]
        X_comb = comb_df['Accel'].values
        y_comb = comb_df['Viscosity'].values
        
        # Perform linear regression
        slope, intercept, r_value, p_value, std_err = stats.linregress(X_comb, y_comb)
        r_squared = r_value ** 2
        
        # Update best result
        if r_squared > best_r_squared:
            best_r_squared = r_squared
            best_combination = comb
            best_slope = slope
            best_intercept = intercept
            best_std_err = std_err
    
    print(f"Found best R²: {best_r_squared:.6f}")
    print(f"Best combination indices: {best_combination}")
    
    # Use best combination for final regression
    df_regress = df.iloc[list(best_combination)]
    X_best = df_regress['Accel'].values
    y_best = df_regress['Viscosity'].values
    
    # Extract temperature information for filename
    temperature = df['Temp'].iloc[0] if not df.empty else "Unknown"
    
    # Calculate extrapolated viscosity value (η₀ = intercept)
    viscosity_0 = best_intercept  # in cP
    
    # Output regression results
    results = {
        'slope': best_slope,
        'intercept': best_intercept,
        'r_squared': best_r_squared,
        'viscosity_0': viscosity_0,
        'std_err': best_std_err,
        'used_indices': best_combination
    }
    
    # Save results to file
    result_path = os.path.join(output_dir, f'regression_results_T{temperature}K.txt')
    generic_result_path = os.path.join(os.path.dirname(output_dir), "regression_results.txt")  # 上一级目录

    try:
        # 构建结果内容
        result_content = f"Linear Regression Analysis (η = a + b·Λ)\n"
        result_content += f"Number of data points used: {len(df_regress)}\n"
        result_content += f"Used point indices: {best_combination}\n"
        result_content += f"Slope (b): {best_slope:.6f}\n"
        result_content += f"Intercept (a): {best_intercept:.6f}\n"
        result_content += f"R²: {best_r_squared:.6f}\n"
        result_content += f"Extrapolated viscosity η₀: {viscosity_0:.4f} cP\n"
        result_content += f"Standard error: {best_std_err:.6f}\n"
        result_content += f"\nDetails of used data points:\n"
        for idx in best_combination:
            row = df.iloc[idx]
            result_content += f"Index {idx}: Accel={row['Accel']:.4f}, Viscosity={row['Viscosity']:.4f}±{row['Viscosity_Err']:.4f} cP\n"
    
        # 保存带温度信息的文件
        with open(result_path, 'w') as f:
            f.write(result_content)
        print(f"Results saved: {result_path}")
    
        # 同时保存通用名称文件到上一级目录
        with open(generic_result_path, 'w') as f:
            f.write(result_content)
        print(f"Generic results saved: {generic_result_path}")
        
    except Exception as e:
        print(f"Error saving result file: {e}")
        return None
    
    print(f"Regression analysis completed, best R² = {best_r_squared:.4f}")
    print(f"Extrapolated viscosity η₀ = {viscosity_0:.4f} cP")
    
    # Create plot: η vs Λ relationship
    plt.figure(figsize=(12, 8), dpi=300)
    
    # Set global font
    plt.rcParams['font.size'] = 12
    plt.rcParams['font.family'] = 'DejaVu Sans'
    
    # Plot all data points
    plt.errorbar(df['Accel'], df['Viscosity'], yerr=df['Viscosity_Err'], 
                 fmt='s', color='#1f77b4', capsize=4, label=f'All data points (n={len(df)})', 
                 alpha=0.6, markersize=6)
    
    # Highlight points used for best fit
    plt.errorbar(df_regress['Accel'], df_regress['Viscosity'], 
                 yerr=df_regress['Viscosity_Err'], fmt='o', color='red', 
                 capsize=5, label='Points used for best fit', markersize=8, linewidth=2)
    
    # Generate regression line (η = intercept + slope * Λ)
    x_range = np.linspace(0, max(df['Accel'])*1.1, 100)
    y_viscosity = best_intercept + best_slope * x_range
    plt.plot(x_range, y_viscosity, 'r-', linewidth=2.5, 
             label=f'Best linear fit (R²={best_r_squared:.4f})')
    
    # Extrapolation point (Λ=0)
    plt.scatter([0], [viscosity_0], s=150, color='#ff7f0e', marker='*', 
                edgecolors='black', linewidth=1, zorder=10,
                label=f'Extrapolated viscosity η₀ = {viscosity_0:.2f} cP')
    
    # Set plot title and labels
    plt.title(f'Viscosity vs Acceleration Amplitude (Best Combination Fit, T = {temperature} K)', fontsize=16, pad=20)
    plt.xlabel('Acceleration Amplitude Λ (nm/ps²)', fontsize=14, labelpad=10)
    plt.ylabel('Viscosity η (cP)', fontsize=14, labelpad=10)
    
    # Add regression equation text box
    eq_text = f'$η = {best_intercept:.2f} + {best_slope:.2f}Λ$\n$R² = {best_r_squared:.4f}$\n$η_0 = {viscosity_0:.2f}$ cP'
    plt.text(0.95, 0.95, eq_text, transform=plt.gca().transAxes, 
             fontsize=12, verticalalignment='top', horizontalalignment='right',
             bbox=dict(boxstyle='round,pad=0.5', facecolor='white', alpha=0.8))
    
    # Set axis ranges
    x_min = 0
    x_max = max(df['Accel']) * 1.05
    plt.xlim(x_min, x_max)
    
    y_min = 0
    y_max = max(df['Viscosity'] + df['Viscosity_Err']) * 1.1
    y_max = max(y_max, viscosity_0 * 1.15)
    plt.ylim(y_min, y_max)
    
    # Add grid and legend
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend(loc='best', framealpha=0.8)
    
    # Adjust layout and save
    plt.tight_layout()
    
    # Save plot
    plot_path = os.path.join(output_dir, f'acceleration_vs_viscosity_best_fit_T{temperature}K.png')
    plt.savefig(plot_path, dpi=300, bbox_inches='tight')

    print(f"Plot saved: {plot_path}")
    
        
    print(f"Plot saved: {plot_path}")
    # Also save to the parent directory with a generic name
    parent_dir = os.path.dirname(output_dir)
    generic_plot_path = os.path.join(parent_dir, "acceleration_vs_viscosity.png")
    plt.savefig(generic_plot_path, dpi=300, bbox_inches='tight')
    print(f"Plot saved to parent directory: {generic_plot_path}")
    

    plt.close()
    
    return result_path

if __name__ == "__main__":
    # Set up command line argument parsing
    parser = argparse.ArgumentParser(description='Find the best 5-point combination with highest R² for viscosity-acceleration regression analysis')
    parser.add_argument('summary_file', nargs='?', default='viscosity_summary.txt', 
                       help='Viscosity summary file path (default: viscosity_summary.txt)')
    parser.add_argument('output_dir', nargs='?', default='./plots', 
                       help='Output directory path (default: ./plots)')
    
    args = parser.parse_args()
    
    # Execute main function
    result_file = main(args.summary_file, args.output_dir)
    
    # Error handling
    if result_file is None or not os.path.exists(result_file):
        print("\nCritical error: Failed to generate regression result file")
        print("Possible solutions:")
        print("1. Check Python dependencies: numpy, pandas, matplotlib, scipy")
        print("2. Verify input file format: " + args.summary_file)
        print("3. Check directory permissions: " + args.output_dir)
        print("4. Confirm sufficient disk space")
        sys.exit(1)
    else:
        print(f"\nAnalysis completed! Result file: {result_file}")