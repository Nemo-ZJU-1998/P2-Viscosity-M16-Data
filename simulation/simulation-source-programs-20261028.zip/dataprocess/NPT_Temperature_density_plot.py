import matplotlib.pyplot as plt
import pandas as pd
import sys

# 检查是否传递了两个文件名作为参数
if len(sys.argv) != 3:
    print("用法: python NPT_Temperature_density_plot.py <density_file> <temperature_file>")
    sys.exit(1)

# 获取传递的文件名
density_file_path = sys.argv[1]
temperature_file_path = sys.argv[2]
# 生成保存图片的文件名
image_name = temperature_file_path.replace('.xvg', '.png')


# 读取密度数据
density_data = []
with open(density_file_path, 'r') as file:
    for line in file:
        if line.strip().startswith('@') or line.strip() == '':
            continue
        try:
            time, density = map(float, line.strip().split())
            density_data.append([time, density])
        except ValueError:
            continue

# 将密度数据转换为 DataFrame
density_df = pd.DataFrame(density_data, columns=['Time (ps)', 'Density (kg/m^3)'])

# 读取温度数据（假设格式类似）
temperature_data = []
with open(temperature_file_path, 'r') as file:
    for line in file:
        if line.strip().startswith('@') or line.strip() == '':
            continue
        try:
            time, temperature = map(float, line.strip().split())
            temperature_data.append([time, temperature])
        except ValueError:
            continue

# 将温度数据转换为 DataFrame
temperature_df = pd.DataFrame(temperature_data, columns=['Time (ps)', 'Temperature (K)'])

# 绘制图表
plt.figure(figsize=(12, 6))

# 绘制密度图
plt.subplot(2, 1, 1)
plt.plot(density_df['Time (ps)'], density_df['Density (kg/m^3)'], color='blue', label='Density')
plt.title('Density vs Time')
plt.xlabel('Time (ps)')
plt.ylabel('Density (kg/m^3)')
plt.grid(True)
plt.legend()

# 绘制温度图
plt.subplot(2, 1, 2)
plt.plot(temperature_df['Time (ps)'], temperature_df['Temperature (K)'], color='red', label='Temperature')
plt.title('Temperature vs Time')
plt.xlabel('Time (ps)')
plt.ylabel('Temperature (K)')
plt.grid(True)
plt.legend()

# 自动调整布局
plt.tight_layout()

# 保存图表为 PNG 文件
plt.savefig(image_name, dpi=300)

# 显示图表  
#plt.show()  

# 关闭图表，以释放内存  
plt.close()  