#!/usr/bin/env python3
# /work/home/xuwenhao/dataprocess/density_check.py
import re
import sys

def main(log_file, temperature):
    try:
        with open(log_file, 'r') as f:
            content = f.read()
        
        # 优化正则表达式：兼容更多空格格式
        pattern = r'Density\s+(\d+\.\d+|\d+)\s+[\d.]+\s+[\d.]+\s+([\-]?\d+\.\d+|\d+)'
        match = re.search(pattern, content)
        if match:
            avg_density = float(match.group(1))
            tot_drift = float(match.group(2))
            
            # 关键修改：增加绝对值处理
            fluctuation = (abs(tot_drift) / avg_density) * 100
            
            # 增强输出可读性
            print(f"[温度 {temperature}K] 平均密度: {avg_density:.4f} kg/m³ | Tot-Drift: {tot_drift:.4e}")
            print(f"[温度 {temperature}K] 绝对波动率: {fluctuation:.4f}%")
            
            # 判断逻辑（保留原始符号显示）
            status_msg = (f"✅ 满足要求 (<2%波动)" if fluctuation < 2.0 
                          else f"❌ 不满足要求 ({fluctuation:.2f}% >= 2%)")
            print(f"[温度 {temperature}K] 密度稳定性: {status_msg}")
            
            sys.exit(0 if fluctuation < 2.0 else 1)
        else:
            raise ValueError("未找到密度统计行")

    except Exception as e:
        print(f"[温度 {temperature}K] 分析错误: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("用法: density_check.py <日志文件> <温度>", file=sys.stderr)
        sys.exit(1)
    
    main(sys.argv[1], sys.argv[2])