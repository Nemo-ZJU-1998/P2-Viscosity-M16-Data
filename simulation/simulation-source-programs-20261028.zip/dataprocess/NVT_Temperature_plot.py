import matplotlib.pyplot as plt
import numpy as np
import sys

# 检查是否传入了文件参数
if len(sys.argv) != 2:
    print("使用方法: python NVT_Temperature_plot.py <file>")
    sys.exit(1)

# 获取命令行传入的文件名
nvt_file = sys.argv[1]

# 生成保存图片的文件名
image_name = nvt_file.replace('.xvg', '.png')

# 初始化数据列表
time = []
temperature = []

# 读取NVT温度数据
with open(nvt_file, 'r') as file:
    for line in file:
        if line.startswith('@') or line.startswith('#'):
            continue  # 跳过注释行
        try:
            t, temp = map(float, line.strip().split())
            time.append(t)
            temperature.append(temp)
        except ValueError:
            continue  # 跳过格式不正确的行

# 转换为 NumPy 数组
time = np.array(time)
temperature = np.array(temperature)

# 创建图
plt.figure(figsize=(10, 6))
plt.plot(time, temperature, marker='o', linestyle='-', color='blue', label='Temperature')
plt.xlabel('Time (ps)')
plt.ylabel('Temperature (K)')
plt.title('NVT Simulation: Time vs Temperature')
plt.grid(True)
plt.legend()

# 保存图表
plt.savefig(image_name, dpi=300)

# 显示图表  
#plt.show()  

# 关闭图表，以释放内存  
plt.close()