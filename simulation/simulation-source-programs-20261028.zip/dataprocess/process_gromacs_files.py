#!/usr/bin/env python3
import os
import sys
import shutil

def process_gromacs_files(loading):
    # 计算分子数量
    try:
        loading_val = float(loading)
        if loading_val < 0 or loading_val > 0.5:
            raise ValueError(f"担载量 {loading_val} 超出范围 [0, 0.5]")
        
        Y_COUNT = round(2000 * loading_val)
        X_COUNT = 2000 - 2 * Y_COUNT
        if X_COUNT < 0:
            raise ValueError("计算结果导致负分子数量")
    except Exception as e:
        print(f"错误: {str(e)}")
        sys.exit(1)
    
    print(f"担载量: {loading}, 计算得到 X_COUNT={X_COUNT}, Y_COUNT={Y_COUNT}")
    
    # 确保删除旧的mix_{loading}.top文件
    if os.path.exists('mix_{loading}.top'):
        os.remove('mix_{loading}.top')
        print("已删除旧的mix_{loading}.top文件")
    
    # 创建mix_{loading}.top并写入初始内容
    with open('mix_{loading}.top', 'w') as f:
        f.write("""#define _FF_OPLS
#define _FF_OPLSAA

; This force field uses a format that requires Gromacs 3.1.4 or later.
;
; References for the OPLS-AA force field: 

[ defaults ]
; nbfunc     comb-rule    gen-pairs    fudgeLJ    fudgeQQ
1        3        yes        0.5    0.5
[ atomtypes ]
; name   at.num      mass       charge   ptype     sigma (nm)    epsilon (kJ/mol)

""")
    
    # 分子列表定义
    molecules = ["Amine", "AmineCOO", "AmineNH2"]
    molecule_names = {"Amine": "Amine", "AmineCOO": "AmineCOO", "AmineNH2": "AmineNH2"}
    
    # 处理每个分子的ITP文件
    for mol in molecules:
        src = f"./structure/{mol}/{mol}_NEW.itp"
        if not os.path.exists(src):
            print(f"错误: 文件不存在 {src}")
            sys.exit(1)
        
        # 复制到当前目录
        temp_file = f"./{mol}_NEW.itp"
        shutil.copy2(src, temp_file)
        
        # 修改分子名称
        modify_molecule_name(temp_file, molecule_names[mol])
        
        # 提取内容并修改mix_{loading}.top
        with open(temp_file, "r") as f:
            content = f.read()
        
        # 定位关键部分 - 使用更可靠的分隔符查找
        start_marker = "[ atomtypes ]"
        end_marker = "["
        
        start_idx = content.find(start_marker)
        if start_idx == -1:
            print(f"警告: {mol}_NEW.itp 中未找到 [ atomtypes ] 部分")
            # 跳过当前文件继续处理其他文件
            continue
        
        # 将结束位置移动到下一个[之后（如果有的话）
        end_idx = content.find(end_marker, start_idx + len(start_marker))
        if end_idx == -1:
            end_idx = len(content)
        
        # 提取并显示内容（只提取实际内容，不包括标记）
        data_start = content.find("\n", start_idx) + 1
        extracted = content[data_start:end_idx].strip()
        
        # 添加到mix_{loading}.top
        with open("mix_{loading}.top", "a") as top:
            top.write(extracted + "\n\n")
        
        # 删除原文件中的atomtypes部分
        new_content = content[:start_idx] + content[end_idx:]
        with open(temp_file, "w") as f:
            f.write(new_content)
    
    # 添加最终内容
    with open("mix_{loading}.top", "a") as top:
        top.write(f"""
#include "Amine_NEW.itp"
#include "AmineCOO_NEW.itp"
#include "AmineNH2_NEW.itp"

[ system ]
Amine

[ molecules ]
; Molecule      nmols
""")
        if X_COUNT > 0:
            top.write(f"{molecule_names['Amine']}          {X_COUNT}      ; 计算自担载量 {loading}\n")
        if Y_COUNT > 0:
            top.write(f"{molecule_names['AmineCOO']}       {Y_COUNT}      ; 计算自担载量 {loading}\n")
            top.write(f"{molecule_names['AmineNH2']}       {Y_COUNT}      ; 计算自担载量 {loading}\n")

    # 创建目标目录并移动文件
    target_dir = f"./gromacs_results/CO2_loading_{loading}"
    os.makedirs(target_dir, exist_ok=True)
    
    # 移动mix_{loading}.top到目标目录
    shutil.move('mix_{loading}.top', os.path.join(target_dir, 'mix.top'))
    
    # 复制所有修改后的ITP文件到目标目录
    for mol in molecules:
        src_file = f"{mol}_NEW.itp"
        dest_file = os.path.join(target_dir, src_file)
        shutil.copy(src_file, dest_file)
        print(f"已复制 {src_file} 到 {dest_file}")
    
    # 清理临时文件
    for mol in molecules:
        temp_file = f"./{mol}_NEW.itp"
        if os.path.exists(temp_file):
            os.remove(temp_file)

def modify_molecule_name(file_path, new_name):
    """修改ITP文件中的分子名称"""
    with open(file_path, 'r') as f:
        lines = f.readlines()
    
    modified = False
    in_moleculetype = False
    for i in range(len(lines)):
        line = lines[i].strip()
        
        # 检查是否在[moleculetype]部分
        if line == '[ moleculetype ]':
            in_moleculetype = True
            continue
        
        # 在[moleculetype]部分寻找分子名称行
        if in_moleculetype and line and not line.startswith(';') and not line.startswith('['):
            parts = line.split()
            if len(parts) > 1:  # 确保是有效的名称行
                print(f"在 {file_path} 中将 MOL 替换为 {new_name}")
                parts[0] = new_name
                lines[i] = ' '.join(parts) + '\n'
                modified = True
                break
    
    if modified:
        with open(file_path, 'w') as f:
            f.writelines(lines)
    else:
        print(f"警告: 在 {file_path} 中未找到分子名称")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("用法: python process_gromacs_files.py <担载量>")
        print("示例: python process_gromacs_files.py 0.05")
        sys.exit(1)
    
    process_gromacs_files(sys.argv[1])