from PIL import Image, ImageDraw, ImageFont, ImageOps
import os
import glob

def create_flexible_grid():
    # 基础配置
    base_dir = "./gromacs_results"
    image_name = "acceleration_vs_viscosity.png"
    loadings = [f"{i*0.05:.2f}" for i in range(9)]  # 0.00到0.40，步长0.05
    
    # 收集图片路径和尺寸
    valid_images = []
    max_width, max_height = 0, 0
    
    for loading in loadings:
        folder = f"CO2_loading_{loading}"
        path = os.path.join(base_dir, folder, image_name)
        if os.path.exists(path):
            img = Image.open(path)
            valid_images.append((img, loading))
            max_width = max(max_width, img.width)
            max_height = max(max_height, img.height)
        else:
            valid_images.append((None, loading))  # 标记缺失位置
    
    if max_width == 0 or max_height == 0:
        print("错误：未找到任何有效图片")
        return
    
    # 创建空白占位图模板
    placeholder = Image.new('RGB', (max_width, max_height), (240, 240, 240))
    draw_ph = ImageDraw.Draw(placeholder)
    try:
        font = ImageFont.truetype("arial.ttf", 20)
    except:
        font = ImageFont.load_default()
    text = "Image Not Found"
    text_w = draw_ph.textlength(text, font=font)
    draw_ph.text(((max_width - text_w)//2, (max_height - 20)//2), 
                text, fill=(150, 150, 150), font=font)
    placeholder = ImageOps.expand(placeholder, border=2, fill='#e0e0e0')
    
    # 创建九宫格画布
    grid_width = max_width * 3
    grid_height = max_height * 3
    padding_bottom = 40  # 底部标注空间
    canvas = Image.new('RGB', (grid_width, grid_height + padding_bottom), (255, 255, 255))
    draw = ImageDraw.Draw(canvas)
    
    # 排列图片并添加标注
    for idx, (img, loading) in enumerate(valid_images):
        row = idx // 3
        col = idx % 3
        x = col * max_width
        y = row * max_height
        
        # 粘贴图片或占位图
        if img:
            canvas.paste(img, (x, y))
        else:
            canvas.paste(placeholder, (x, y))
        
        # 添加标注（缺失项用红色标注）
        text = f"CO₂ loading: {loading}"
        text_w = draw.textlength(text, font=font)
        text_x = x + (max_width - text_w) // 2
        text_y = grid_height + 10  # 底部统一标注位置
        
        # 设置不同颜色标注
        color = (255, 0, 0) if img is None else (0, 0, 0)
        draw.text((text_x, text_y), text, fill=color, font=font)
    
    # 添加标题
    title = "Acceleration vs Viscosity under Different CO₂ Loadings"
    title_w = draw.textlength(title, font=font)
    draw.text(((grid_width - title_w)//2, grid_height + 30), 
             title, fill=(0, 0, 150), font=font)
    
    # 保存结果
    output_path = os.path.join(base_dir, "combined_flexible_grid.png")
    canvas.save(output_path)
    print(f"九宫格图片已保存至: {output_path}")
    print(f"包含 {sum(1 for item in valid_images if item[0] is not None)} 张有效图片")
    return output_path

if __name__ == "__main__":
    result = create_flexible_grid()
    if result:
        print("操作成功完成！")