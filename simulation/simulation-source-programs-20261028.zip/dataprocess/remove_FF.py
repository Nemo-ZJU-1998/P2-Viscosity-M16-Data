import sys

def remove_defaults_section(filename):
    with open(filename, 'r') as f:
        lines = f.readlines()
    
    new_lines = []
    in_defaults = False
    skip_next = False
    
    for line in lines:
        stripped = line.strip()
        if stripped == '[ defaults ]':
            in_defaults = True
            skip_next = True
            continue
        elif skip_next and (stripped.startswith(';') or stripped == ''):
            skip_next = False
            continue
        elif in_defaults and stripped.startswith('['):
            in_defaults = False
            new_lines.append(line)
        elif not in_defaults:
            new_lines.append(line)
        elif in_defaults and stripped == '':
            in_defaults = False
    
    with open(filename, 'w') as f:
        f.writelines(new_lines)

for file in sys.argv[1:]:
    remove_defaults_section(file)