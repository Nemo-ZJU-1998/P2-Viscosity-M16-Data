#!/usr/bin/env python3
# /work/home/xuwenhao/dataprocess/plot_viscosity_acceleration.py

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
import os
import re
import sys

def main(summary_file, output_dir="."):
    """
    Plot viscosity vs acceleration amplitude and perform regression analysis
    
    Parameters:
    summary_file: Path to viscosity_summary.txt
    output_dir: Output directory
    """
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Read data
    try:
        # 修复缩进问题：统一使用4个空格
        df = pd.read_csv(summary_file, sep='\s+', comment='#',
                         names=['Temp', 'Accel', 'InvVisc', 'ErrEst', 'RMSD', 'TotDrift'])
        print(f"Successfully read {summary_file}, containing {len(df)} data points")
        
        # Convert inverse viscosity to viscosity (η = 1 / (1/η))
        df['Viscosity'] = 1 / df['InvVisc'] * 1000  # Convert to cP
        # Calculate viscosity error (Δη = η * Δ(1/η) / (1/η))
        df['Viscosity_Err'] = df['Viscosity'] * df['ErrEst'] / df['InvVisc']
        
    except Exception as e:
        print(f"Error reading file {summary_file}: {e}")
        return
    
    # Extract temperature
    temperature = df['Temp'].iloc[0] if not df.empty else "Unknown"
    
    # Sort by acceleration amplitude (ascending)
    df = df.sort_values(by='Accel')
    
    # Use only the first 5 points (smallest acceleration values) for regression
    if len(df) > 5:
        print(f"Regression analysis: Using first 5 smallest acceleration points (total {len(df)} points)")
        df_regress = df.head(5).copy()
    else:
        df_regress = df.copy()
        print(f"Regression analysis: Using all {len(df)} points")
    
    # Prepare regression data
    X = df_regress['Accel'].values
    y = df_regress['Viscosity'].values
    
    # Perform linear regression
    if len(X) < 2:
        print("Error: Insufficient data points for regression analysis")
        return
    
    slope, intercept, r_value, p_value, std_err = stats.linregress(X, y)
    r_squared = r_value ** 2
    
    # Calculate extrapolated viscosity at acceleration=0
    viscosity_0 = intercept
    
    # Create plot
    plt.figure(figsize=(12, 8), dpi=300)
    
    # Set global font
    plt.rcParams['font.size'] = 12
    plt.rcParams['font.family'] = 'DejaVu Sans'
    
    # Plot all data points
    plt.scatter(df['Accel'], df['Viscosity'], s=80, color='#1f77b4', 
                edgecolors='black', linewidth=1, zorder=5, 
                label=f'Measured values (n={len(df)})')
    
    # Plot regression line
    x_fit = np.linspace(0, max(X)*1.1, 100)
    y_fit = intercept + slope * x_fit
    plt.plot(x_fit, y_fit, 'r-', linewidth=2.5, 
             label=f'Linear regression (R²={r_squared:.4f})')
    
    # Mark extrapolated point (viscosity at acceleration=0)
    plt.scatter([0], [intercept], s=150, color='#ff7f0e', marker='*', 
                edgecolors='black', linewidth=1, zorder=10,
                label=f'Extrapolated viscosity η₀₀ = {viscosity_0:.2f} cP')
    
    # Mark points not used in regression
    if len(df) > 5:
        unused = df.iloc[5:]
        plt.scatter(unused['Accel'], unused['Viscosity'], s=80, 
                    color='#7f7f7f', alpha=0.7, marker='s',
                    edgecolors='black', linewidth=1,
                    label=f'Points not used in regression (n={len(unused)})')
    
    # Add error bars
    if 'Viscosity_Err' in df.columns:
        plt.errorbar(df['Accel'], df['Viscosity'], yerr=df['Viscosity_Err'], 
                     fmt='none', ecolor='#1f77b4', elinewidth=1.5, capsize=3)
    
    # Set plot titles and labels
    plt.title(f'Viscosity vs Acceleration Amplitude (T = {temperature} K)', fontsize=16, pad=20)
    plt.xlabel('Acceleration Amplitude Λ (nm/ps²)', fontsize=14, labelpad=10)
    plt.ylabel('Viscosity η (cP)', fontsize=14, labelpad=10)
    
    # Add regression equation
    eq_text = f'$η = {intercept:.2f} + {slope:.2f}Λ$\n$R² = {r_squared:.4f}$\n$η_0 = {viscosity_0:.2f}$ cP'
    plt.text(0.95, 0.95, eq_text, transform=plt.gca().transAxes, 
             fontsize=14, verticalalignment='top', horizontalalignment='right',
             bbox=dict(boxstyle='round,pad=0.5', facecolor='white', alpha=0.8))
    
    # Set axis ranges based on data min/max values
    x_min = 0
    x_max = max(df['Accel']) * 1.05  # Add 5% padding
    plt.xlim(x_min, x_max)
    
    # Calculate y range with appropriate padding
    y_min = 0
    y_max = max(df['Viscosity'] + df['Viscosity_Err']) * 1.05 if 'Viscosity_Err' in df.columns else max(df['Viscosity']) * 1.05
    # Ensure y_max is at least 10% higher than the extrapolated value
    y_max = max(y_max, viscosity_0 * 1.1)
    plt.ylim(y_min, y_max)
    
    # Set specific tick values based on the image description
    plt.xticks(np.arange(0, x_max + 0.01, 0.01))
    plt.yticks(np.arange(0, y_max + 0.1, 0.1))
    
    # Add grid and legend
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend(loc='best', framealpha=0.8)
    
    # Adjust layout
    plt.tight_layout()
    
    # Save plot
    output_path = os.path.join(output_dir, f'viscosity_vs_acceleration.png')
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"Saved regression plot: {output_path}")
    
    # Save regression results
    result_path = os.path.join(output_dir, f'regression_results_T{temperature}K.txt')
    try:
        with open(result_path, 'w') as f:
            f.write(f"Regression Results (η = a + b·Λ)\n")
            f.write(f"Number of points used: {len(df_regress)}\n")
            f.write(f"Slope (b): {slope:.6f}\n")
            f.write(f"Intercept (a): {intercept:.6f}\n")
            f.write(f"R²: {r_squared:.6f}\n")
            f.write(f"Extrapolated viscosity η₀₀: {viscosity_0:.4f} cP\n")
            f.write(f"Standard error: {std_err:.6f}\n")
        
        print(f"Saved regression results: {result_path}")
        return result_path
        
    except Exception as e:
        print(f"Error saving regression results: {e}")
        print("Check the following possible issues:")
        print("1. Output directory permissions: " + output_dir)
        print("2. Disk space availability")
        print("3. File system errors")
        return None

if __name__ == "__main__":
    # Handle command line arguments
    if len(sys.argv) < 2:
        print("Usage: python plot_viscosity_acceleration.py <viscosity_summary.txt> [output_dir]")
        print("Example: python plot_viscosity_acceleration.py viscosity_summary.txt ./results")
        sys.exit(1)
    
    summary_file = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else "."
    
    result_file = main(summary_file, output_dir)
    
    # 添加额外的错误处理
    if result_file is None or not os.path.exists(result_file):
        print("\nCRITICAL ERROR: Failed to generate regression results file")
        print("Possible solutions:")
        print("1. Check Python dependencies: numpy, pandas, matplotlib, scipy")
        print("2. Validate input file format: " + summary_file)
        print("3. Check directory permissions: " + output_dir)
        print("4. Verify available disk space")
        sys.exit(1)