import numpy as np  
import matplotlib.pyplot as plt  
from scipy.stats import linregress  
import sys  

def read_data(file_path):  
    try:  
        # 读取数据，假设文件的第一行为标题行，分隔符为空格  
        data = np.genfromtxt(file_path, delimiter=' ', skip_header=1, encoding='utf-8')  
    except UnicodeDecodeError:  
        data = np.genfromtxt(file_path, delimiter=' ', skip_header=1, encoding='utf-8', errors='ignore')  
    return data  

def linear_fit_and_plot(data, output_file):  
    temperatures = np.unique(data[:, 0])  # 提取唯一的温度值  
    fig, ax = plt.subplots()  

    # 创建并打开输出文件用于写入截距和误差  
    with open(output_file, 'w') as f:  
        f.write("Temperature (K), Viscosity(cP), Viscosity Error\n")  # 写入表头  
        
        for temp in temperatures:  
            temp_data = data[data[:, 0] == temp]  
            accelerations = temp_data[:, 1]       # 加速度作为自变量  
            inv_viscosity = temp_data[:, 2]      # 倒粘度（1/Viscosity）  
            inv_viscosity_errors = temp_data[:, 3]  # 倒粘度误差  

            # 计算粘度和误差  
            viscosity = 1.0 / inv_viscosity * 1000.0  # 粘度转换为 cP（毫帕·秒）  
            viscosity_errors = viscosity * inv_viscosity_errors / inv_viscosity  # 计算粘度误差  

            # 进行线性回归分析  
            slope, intercept, r_value, p_value, std_err = linregress(accelerations, viscosity)  
            r2 = r_value ** 2  

            # 绘制数据点和误差棒  
            errorbar = ax.errorbar(accelerations, viscosity, yerr=viscosity_errors, fmt='o', label=f'T={temp}K')  
            color = errorbar.lines[0].get_color()  

            # 绘制拟合直线  
            x_fit = np.linspace(min(accelerations), max(accelerations), 100)  
            y_fit = slope * x_fit + intercept  
            ax.plot(x_fit, y_fit, '-', color=color)  

            # 在拟合线附近添加拟合方程和R²值  
            equation_text = f'T={temp}K: y = {slope:.2f}x + {intercept:.2f}, R²={r2:.2f}'  
            ax.text(0.05, 0.9 - (0.05 * np.where(temperatures == temp)[0][0]),  # 动态计算文本位置  
                    equation_text, transform=ax.transAxes, fontsize=8,  
                    color=color)  

            # 计算截距的误差范围  
            intercept_error = std_err * np.sqrt(np.sum((accelerations - np.mean(accelerations)) ** 2) / len(accelerations))  
            
            # 写入输出文件  
            f.write(f"{temp}, {intercept:.2f}, {intercept_error:.2f}\n")  

    # 设置图表标签和保存图表  
    ax.set_xlabel('Acceleration (m/s²)')  
    ax.set_ylabel('Viscosity (cP)')  
    ax.legend()  
    plt.savefig('acceleration_vs_viscosity.png', dpi=300)  

if __name__ == "__main__":  
    if len(sys.argv) != 2:  
        print("Usage: python script_name.py data.txt")  
        sys.exit(1)  
    
    file_path = sys.argv[1]  
    output_file = 'Temperature_vs_Viscosity.txt'  # 输出文件名  
    data = read_data(file_path)  
    linear_fit_and_plot(data, output_file)  