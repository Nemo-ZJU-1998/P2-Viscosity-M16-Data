#!/bin/bash  

# 定义输出目录  
OUTPUT_DIR="$1"  
TEMP="$2"
shift 2
ACCELERATIONS=("$@")  

# 定义函数以动态获取编号
function get_energy_index {
    local edr_file="$1"      # Energy 文件路径
    local search_key="$2"    # 搜索的参数名称
    local index              # 保存找到的编号
    
    # 使用 gmx energy 的 ? 模式获取编号
    echo -e "0\n" | mpirun -n 1 gmx_mpi energy -f "$edr_file" >> "energy.log" 2>&1
    index=$(grep -i "$search_key" energy.log | awk -v key="$search_key" '{for(i=1; i<=NF; i++) if($i==key) print $(i-1)}')

    # 检查是否找到编号
    if [ -z "$index" ]; then
        echo "未找到参数 $search_key 的编号，请检查 energy 文件和参数名称。" >&2
        exit 1
    fi

    echo "$index"  # 返回找到的编号
}

# 确保 result 目录存在
# mkdir result
rm -f energy.log



# 对不同温度进行模拟  

echo "当前温度: $TEMP K" 


# NPT2 - 动态解析 Density 的编号  
DENSITY_INDEX=$(get_energy_index "md_NPT_${TEMP}.edr" "Density")  
rm -f energy.log
mpirun -n 1 gmx_mpi energy -f md_NPT_${TEMP}.edr -o result/md_NPT_${TEMP}_Density.xvg << EOF  
$DENSITY_INDEX  
EOF
echo "md_NPT 结果已保存 (Density)。"  


# NPT2 - 动态解析 Temperature 的编号  
TEMPERATURE_INDEX=$(get_energy_index "md_NPT_${TEMP}.edr" "Temperature")  
rm -f energy.log
mpirun -n 1 gmx_mpi energy -f md_NPT_${TEMP}.edr -o result/md_NPT_${TEMP}_Temperature.xvg << EOF  
$TEMPERATURE_INDEX  
EOF
echo "md_NPT 结果已保存 (Temperature)。"  
python3 /work/home/xuwenhao/dataprocess/NPT_Temperature_density_plot.py result/md_NPT_${TEMP}_Density.xvg result/md_NPT_${TEMP}_Temperature.xvg

# NVT - 动态解析 Temperature 的编号  
TEMPERATURE_INDEX=$(get_energy_index "NVT_${TEMP}.edr" "Temperature")  
rm -f energy.log
mpirun -n 1 gmx_mpi energy -f NVT_${TEMP}.edr -o result/NVT_${TEMP}_Temperature.xvg << EOF  
$TEMPERATURE_INDEX  
EOF
echo "NVT 结果已保存 (Temperature)。"  
python3 /work/home/xuwenhao/dataprocess/NVT_Temperature_plot.py result/NVT_${TEMP}_Temperature.xvg

# 粘度计算  
for ACC in "${ACCELERATIONS[@]}"; do  
# 动态解析 Viscosity, Pressure, Density  
VISCOSITY_INDEX=$(get_energy_index "vis_${TEMP}_${ACC}.edr" "1/Viscosity")  
rm -f energy.log  
TEMPERATURE_INDEX=$(get_energy_index "vis_${TEMP}_${ACC}.edr" "Temperature")  
rm -f energy.log  
PRESSURE_INDEX=$(get_energy_index "vis_${TEMP}_${ACC}.edr" "Pressure")  
rm -f energy.log  

# 保存粘度  
mpirun -n 1 gmx_mpi energy -f vis_${TEMP}_${ACC}.edr -o result/Viscosity_${TEMP}_${ACC}.xvg -b 200 -e 450 << EOF  
$VISCOSITY_INDEX  
EOF
python3 /work/home/xuwenhao/dataprocess/Vis_plot.py result/Viscosity_${TEMP}_${ACC}.xvg -b 200 -e 450

# 保存温度  
mpirun -n 1 gmx_mpi energy -f vis_${TEMP}_${ACC}.edr -o result/vis_${TEMP}_Temperature_${ACC}.xvg << EOF  
$TEMPERATURE_INDEX  
EOF
python3 /work/home/xuwenhao/dataprocess/NVT_Temperature_plot.py result/vis_${TEMP}_Temperature_${ACC}.xvg

# 保存压力  
mpirun -n 1 gmx_mpi energy -f vis_${TEMP}_${ACC}.edr -o result/vis_${TEMP}_Pressure_${ACC}.xvg << EOF  
$PRESSURE_INDEX  
EOF
python3 /work/home/xuwenhao/dataprocess/Time_Pressure_plot.py result/vis_${TEMP}_Pressure_${ACC}.xvg -b 10 -e 500


echo "粘度、温度、压力结果已保存到 result 文件夹。"  


done  
  

