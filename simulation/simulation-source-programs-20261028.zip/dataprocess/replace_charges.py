import sys

def replace_charges(chg_file, itp_file, output_file):
    # 读取电荷文件 (EEMPA.chg)
    charges = []
    with open(chg_file, 'r') as f:
        for line in f:
            if line.strip() and not line.startswith(';'):  # 跳过空行和注释
                parts = line.split()
                if len(parts) >= 5:  # 确保有至少5列
                    charges.append(parts[4])  # 第五列是电荷
    
    # 处理拓扑文件 (EEMPA.itp)
    in_atoms_section = False
    atom_count = 0
    output_lines = []
    
    print(f"\n{'原子ID':<6}{'原子类型':<10}{'原电荷':<12}{'新电荷':<12}")
    print("-" * 40)
    
    with open(itp_file, 'r') as f:
        for line in f:
            # 检测是否进入[ atoms ]部分
            if line.strip().startswith('[ atoms ]'):
                in_atoms_section = True
                output_lines.append(line)
                continue
                
            # 检测是否离开[ atoms ]部分
            if in_atoms_section and line.strip().startswith('['):
                in_atoms_section = False
                
            # 在[ atoms ]部分处理原子行
            if in_atoms_section:
                # 跳过注释行和空行
                if line.strip().startswith(';') or not line.strip():
                    output_lines.append(line)
                    continue
                    
                # 分割原子行为字段
                parts = line.split()
                
                # 确保是有效的原子行（至少有7列）
                if len(parts) >= 7:
                    original_charge = parts[6]
                    
                    # 替换电荷（第7列）
                    if atom_count < len(charges):
                        new_charge = charges[atom_count]
                        parts[6] = new_charge
                        
                        # 打印替换信息
                        print(f"{parts[0]:<6}{parts[1]:<10}{original_charge:<12}{new_charge:<12}")
                        
                        atom_count += 1
                    else:
                        print("警告：电荷数量少于原子行数量")
                    
                    # 重新组合行（保留原始格式）
                    # 注意：原始格式可能有不同数量的列，我们只修改第7列（索引6），其他保持不变
                    # 使用原始的分隔方式重新组合，但只修改电荷列
                    # 由于原始格式可能有多个空格，我们采用重新对齐的方式
                    # 我们假设前7列是固定的，后面的列（如果有）保持不变
                    new_line = f"{parts[0]:>6s}  {parts[1]:<10s}  {parts[2]:>5s}  {parts[3]:<6s}  {parts[4]:<6s}  {parts[5]:>5s}  {parts[6]:>10s}"
                    
                    # 如果有第8列及以后，添加它们
                    if len(parts) > 7:
                        # 第8列开始，用两个空格分隔（原始格式通常如此）
                        new_line += "  " + "  ".join(parts[7:])
                    new_line += "\n"
                    
                    output_lines.append(new_line)
                    continue
                    
            # 非原子行直接保留
            output_lines.append(line)
    
    # 检查原子数量匹配
    if atom_count != len(charges):
        print(f"警告：替换的原子数量({atom_count})与电荷数量({len(charges)})不匹配")
    
    # 写入输出文件
    with open(output_file, 'w') as f:
        f.writelines(output_lines)
    
    print(f"\n成功替换 {atom_count} 个原子的电荷到 {output_file}")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("用法: python replace_charges.py <chg_file> <itp_file> <output_file>")
        print("示例: python replace_charges.py EEMPA.chg EEMPA.itp modified.itp")
        sys.exit(1)
    
    chg_file = sys.argv[1]
    itp_file = sys.argv[2]
    output_file = sys.argv[3]
    
    replace_charges(chg_file, itp_file, output_file)
    