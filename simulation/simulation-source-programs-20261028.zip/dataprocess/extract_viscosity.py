import sys

def extract_viscosity(file_name, temperature_array, acc_array):  
    temperatures = temperature_array.split()  
    accs = acc_array.split()  
    output_file = "viscosity_summary.txt"  
    with open(output_file, 'w', encoding='utf-8') as out:  
        out.write("# Temperature (K)  Acceleration (m/s²)  1/Viscosity (Average)  Err.Est.  RMSD  Tot-Drift\n")  
        for temp in temperatures:  
            for acc in accs:  
                viscosity_key = f"vis_{temp}_{acc}.edr"  
                found_viscosity = False  
                with open(file_name, 'r', encoding='utf-8') as file:  
                    for line in file:  
                        # 判断当前行是否包含关键字，并且是Viscosity相关的输出  
                        if viscosity_key in line and "Viscosity" in line:  
                            found_viscosity = True  
                        elif found_viscosity and line.startswith("1/Viscosity"):  
                            parts = line.split()  
                            if len(parts) >= 5:  
                                average = parts[1]  
                                err_est = parts[2]  
                                rmsd = parts[3]  
                                tot_drift = parts[4]  
                                out.write(f"{temp} {acc} {average} {err_est} {rmsd} {tot_drift}\n")  
                                found_viscosity = False  # 重置标志，避免重复提取  
                print(f"已处理 {viscosity_key}")  

if __name__ == "__main__":  
    if len(sys.argv) != 4:  
        print("Usage: python extract_viscosity.py <file> \"(Temperature数组)\" \"(acc数组)\"")  
        sys.exit(1)  
    
    file = sys.argv[1]  
    temperature_array = sys.argv[2]  
    acc_array = sys.argv[3]  
    
    extract_viscosity(file, temperature_array, acc_array)  