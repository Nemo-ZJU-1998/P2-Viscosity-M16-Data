from PIL import Image, ImageDraw, ImageFont, ImageOps
import os
import sys

def create_temperature_grid():
    # 获取当前工作目录并提取吸收剂序号
    current_dir = os.getcwd()
    absorbent_id = os.path.basename(current_dir)  # 提取目录名（如32或33）
    
    # 动态设置基础目录
    base_dir = os.path.join(current_dir, "gromacs_results")
    image_name = "md_NPT_313_Temperature.png"
    loadings = [f"{i*0.05:.2f}" for i in range(9)]  # CO2加载量从0.00到0.40
    
    # 收集图片并确定最大尺寸
    valid_images = []
    max_width, max_height = 0, 0
    
    for loading in loadings:
        folder = f"CO2_loading_{loading}"
        path = os.path.join(base_dir, folder, "result", image_name)
        
        if os.path.exists(path):
            img = Image.open(path)
            valid_images.append((img, loading))
            max_width = max(max_width, img.width)
            max_height = max(max_height, img.height)
        else:
            print(f"警告: 图片缺失 - {path}")
            valid_images.append((None, loading))
    
    if max_width == 0 or max_height == 0:
        print("错误：未找到任何有效图片")
        return None
    
    # 创建占位图模板
    placeholder = Image.new('RGB', (max_width, max_height), (240, 240, 240))
    draw_ph = ImageDraw.Draw(placeholder)
    try:
        font = ImageFont.truetype("arial.ttf", 20)
    except:
        font = ImageFont.load_default()
    text = "Image Not Available"
    text_w = draw_ph.textlength(text, font=font)
    draw_ph.text(((max_width - text_w)//2, (max_height - 20)//2), 
                text, fill=(150, 150, 150), font=font)
    placeholder = ImageOps.expand(placeholder, border=2, fill='#e0e0e0')
    
    # 创建九宫格画布
    grid_width = max_width * 3
    grid_height = max_height * 3
    padding_bottom = 50  # 底部标题空间
    canvas = Image.new('RGB', (grid_width, grid_height + padding_bottom), (255, 255, 255))
    draw = ImageDraw.Draw(canvas)
    
    # 排列图片并添加标注
    for idx, (img, loading) in enumerate(valid_images):
        row = idx // 3
        col = idx % 3
        x = col * max_width
        y = row * max_height
        
        if img:
            canvas.paste(img, (x, y))
        else:
            canvas.paste(placeholder, (x, y))
        
        text = f"CO₂: {loading}"
        text_w = draw.textlength(text, font=font)
        text_x = x + (max_width - text_w) // 2
        text_y = grid_height + 10
        
        color = (255, 0, 0) if img is None else (0, 100, 0)
        draw.text((text_x, text_y), text, fill=color, font=font)
    
    # 添加主标题（包含吸收剂序号）
    title_font_size = 24
    try:
        title_font = ImageFont.truetype("arial.ttf", title_font_size)
    except:
        title_font = font
    
    title = f"NPT-313 Temperature Trend under CO₂ Loading (Absorbent {absorbent_id})"
    title_w = draw.textlength(title, font=title_font)
    draw.text(((grid_width - title_w)//2, grid_height + 30), 
             title, fill=(0, 0, 150), font=title_font)
    
    # 保存结果到当前吸收剂目录
    output_path = os.path.join(base_dir, f"combined_temperature_grid_{absorbent_id}.png")
    canvas.save(output_path)
    print(f"九宫格图片已保存至: {output_path}")
    print(f"成功合并: {sum(1 for item in valid_images if item[0] is not None)}/9 张图片")
    return output_path

if __name__ == "__main__":
    result = create_temperature_grid()
    if result:
        print("操作成功完成！")
        print(f"输出文件路径: {result}")